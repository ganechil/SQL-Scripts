SET NOCOUNT ON;
DECLARE @msend_latency BIT = 0,
@EmailFrom varchar(max);

IF OBJECT_ID('master.dbo.Latency') IS NOT NULL
    DROP TABLE master.dbo.Latency;

SELECT
    Latency_fetched_at = CONVERT(VARCHAR, GETDATE(), 22),
    drs.last_commit_time,
    DATEDIFF(MINUTE, drs.last_commit_time, GETDATE()) AS Lag_Mins,
    ar.replica_server_name,
    adc.database_name,
    drs.is_primary_replica,
    drs.synchronization_state_desc,
    drs.secondary_lag_seconds,
    ar.availability_mode_desc,
    drs.synchronization_health_desc
INTO master.dbo.Latency
FROM sys.dm_hadr_database_replica_states AS drs
INNER JOIN sys.availability_databases_cluster AS adc
    ON (drs.group_id = adc.group_id)
    AND (drs.group_database_id = adc.group_database_id)
INNER JOIN sys.availability_groups AS ag
    ON (ag.group_id = drs.group_id)
INNER JOIN sys.availability_replicas AS ar
    ON (drs.group_id = ar.group_id)
    AND (drs.replica_id = ar.replica_id)
WHERE
    (
        (availability_mode_desc = 'SYNCHRONOUS_COMMIT' AND drs.secondary_lag_seconds > 0)
        OR (availability_mode_desc = 'ASYNCHRONOUS_COMMIT' AND drs.secondary_lag_seconds > 0)
        OR (drs.synchronization_state_desc = 'NOT SYNCHRONIZING')
		--OR (DATEDIFF(SECOND, drs.last_commit_time, GETDATE()) > 15) --if difference between 'Latency_fetched_at' & 'last_commit_time' is greate than 15sec )
    )
ORDER BY
    ag.name,
    ar.replica_server_name,
    adc.database_name;
SELECT * FROM master.dbo.Latency


-- Check if latency data exists
IF EXISTS (SELECT * FROM master.dbo.Latency)
BEGIN
    SET @msend_latency = 1;
    PRINT 'Latency';
END
ELSE
BEGIN
    SET @msend_latency = 0;
    PRINT 'Cleared';
END

-- Send email if necessary
IF (@msend_latency = 1)
BEGIN
    DECLARE @subject NVARCHAR(MAX) = 'SQL ALERT : AG Latency On ' + @@SERVERNAME;
    DECLARE @importance VARCHAR(10) = 'High';
    DECLARE @html NVARCHAR(MAX) = '';

    -- Generate HTML table from Latency data
    EXEC master.dbo.SqlTableToHtml 'master.dbo.Latency', @html OUTPUT, '', 'style="border-top:1px #CCCCCC solid;padding:10px"', 'style="padding:7px"';
    
	SET @EmailFrom = @@SERVERNAME + ' <' + REPLACE(@@SERVERNAME,'\','_') + '@smfgindia.com>';


-- Send email
    EXEC msdb.dbo.sp_send_dbmail
       -- @profile_name = 'cloverDBASupport@smfgindia.com',
        @recipients = 'SMFGInfra.Database@smfgindia.com',
        @copy_recipients = 'Ganesh.Chilveri@smfgindia.com; Sandeep.Chaurasia@smfgindia.com; crml2support@smfgindia.com',
        @subject = @subject,
        @importance = @importance,
		@from_address = @EmailFrom,
        @body = @html,
        @body_format = 'HTML';
END



---
USE [master]
GO
/****** Object:  StoredProcedure [dbo].[SqlTableToHtml]    Script Date: 5/14/2024 6:50:46 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create or PROCEDURE [dbo].[SqlTableToHtml] (
@TABLENAME  NVARCHAR(500),
@OUTPUT   NVARCHAR(MAX) OUTPUT,
@TBL_STYLE NVARCHAR(1024) = '',
@TD_STYLE NVARCHAR(1024) = '',
@HDR_STYLE NVARCHAR(1024) = '')
AS

-- Description 
--				Stored Procedure to take an arbitraty temporary table and return 
--				the equivalent HTML string .


-- @exec_str stores the dynamic SQL Query
-- @ParmDefinition stores the parameter definition for the dynamic SQL
DECLARE @exec_str  NVARCHAR(MAX)
DECLARE @ParmDefinition NVARCHAR(500)


--We need to use Dynamic SQL at this point so we can expand the input table name parameter
SET @exec_str= N'
DECLARE @exec_str  NVARCHAR(MAX)
DECLARE @ParmDefinition NVARCHAR(500)

--Make a copy of the original table adding an indexing columnWe need to add an index column to the table to facilitate sorting so we can maintain the
--original table order as we iterate through adding HTML tags to the table fields.
--New column called CustColHTML_ID (unlikely to be used by someone else!)
--

select CustColHTML_ID=0,* INTO #CustomTable2HTML FROM ' + @TABLENAME + ' 

--Now alter the table to add the auto-incrementing index. This will facilitate row finding
DECLARE @COUNTER INT
SET @COUNTER=0
UPDATE #CustomTable2HTML SET @COUNTER = CustColHTML_ID=@COUNTER+1 

-- @HTMLROWS will store all the rows in HTML format
-- @ROW will store each HTML row as fields on each row are iterated through 
-- using dymamic SQL and a cursor
-- @FIELDS will store the header row for the HTML Table

DECLARE @HTMLROWS NVARCHAR(MAX) DECLARE @FIELDS NVARCHAR(MAX) 
SET @HTMLROWS='''' DECLARE @ROW NVARCHAR(MAX) 

-- Create the first HTML row for the table (the table header). Ignore our indexing column!
SET @FIELDS=''<tr>''
SELECT @FIELDS=COALESCE(@FIELDS, '' '','''')+''<th ' + @HDR_STYLE + '>'' + name + ''</th>''
FROM tempdb.sys.Columns
WHERE object_id=object_id(''tempdb..#CustomTable2HTML'')
AND name not like ''CustColHTML_ID''
SET @FIELDS=@FIELDS + ''</tr>''

-- @ColumnName stores the column name as found by the table cursor
-- @maxrows is a count of the rows in the table, and @rownum is for marking the
-- ''current'' row whilst processing

DECLARE @ColumnName  NVARCHAR(500)
DECLARE @maxrows INT
DECLARE @rownum INT

--Find row count of our temporary table
SELECT @maxrows=count(*) FROM  #CustomTable2HTML


--Create a cursor which will look through all the column names specified in the temporary table
--but exclude the index column we added (CustColHTML_ID)
DECLARE col CURSOR FOR
SELECT name FROM tempdb.sys.Columns
WHERE object_id=object_id(''tempdb..#CustomTable2HTML'')
AND name not like ''CustColHTML_ID''
ORDER BY column_id ASC

--For each row, generate dymanic SQL which requests the each column name in turn by 
--iterating through a cursor
SET @rowNum=0
SET @ParmDefinition=N''@ROWOUT NVARCHAR(MAX) OUTPUT,@rowNum_IN INT''

While @rowNum < @maxrows
BEGIN
  SET @HTMLROWS=@HTMLROWS + ''<tr>''

  SET @rowNum=@rowNum +1
  OPEN col
  FETCH NEXT FROM col INTO @ColumnName
  WHILE @@FETCH_STATUS=0
    BEGIN
      --Get nth row from table
      SET @exec_str=''SELECT @ROWOUT=(select COALESCE(['' + @ColumnName + ''], '''''''') AS ['' + @ColumnName + ''] from #CustomTable2HTML where CustColHTML_ID=@rowNum_IN)''

	  EXEC	sp_executesql 
			@exec_str,
			@ParmDefinition,
			@ROWOUT=@ROW OUTPUT,
            @rowNum_IN=@rownum

      SET @HTMLROWS =@HTMLROWS +  ''<td ' + @TD_STYLE + '>'' + @ROW + ''</td>''
      FETCH NEXT FROM col INTO @ColumnName
    END
  CLOSE col
  SET @HTMLROWS=@HTMLROWS + ''</tr>''
END

SET @OUTPUT=''''
IF @maxrows>0
SET @OUTPUT= ''<table ' + @TBL_STYLE + '>'' + @FIELDS + @HTMLROWS + ''</table>''

DEALLOCATE col
'

DECLARE @ParamDefinition nvarchar(max)
SET @ParamDefinition=N'@OUTPUT NVARCHAR(MAX) OUTPUT'

--Execute Dynamic SQL. HTML table is stored in @OUTPUT which is passed back up (as it's
--a parameter to this SP)
EXEC sp_executesql @exec_str,
@ParamDefinition,
@OUTPUT=@OUTPUT OUTPUT

RETURN 1