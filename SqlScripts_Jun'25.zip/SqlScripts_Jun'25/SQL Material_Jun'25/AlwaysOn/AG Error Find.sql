select * from sys.sysmessages
where msglangid=1033 and description like '%Availability%'
and error in (1480,35264,35265)