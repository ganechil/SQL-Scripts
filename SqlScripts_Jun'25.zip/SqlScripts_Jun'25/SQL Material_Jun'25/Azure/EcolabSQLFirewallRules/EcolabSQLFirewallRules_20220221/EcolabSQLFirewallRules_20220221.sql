-- Generated 20220218 based based on SQLFirewallRulesToAdd.csv Dated 02/18/2022 10:59:40
EXECUTE sp_set_firewall_rule @name = N'Ecolab Naperville',
    @start_ip_address = '206.197.60.5',
    @end_ip_address = '206.197.60.5'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Eagan',
    @start_ip_address = '204.69.40.7',
    @end_ip_address = '204.69.40.7'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Sydney',
    @start_ip_address = '119.31.169.119',
    @end_ip_address = '119.31.169.119'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Singapore',
    @start_ip_address = '119.31.167.4',
    @end_ip_address = '119.31.167.4'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Shanghai',
    @start_ip_address = '43.229.50.119',
    @end_ip_address = '43.229.50.119'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Dominican Republic',
    @start_ip_address = '190.167.243.68',
    @end_ip_address = '190.167.243.68'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Amsterdam',
    @start_ip_address = '77.247.0.120',
    @end_ip_address = '77.247.0.121'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Frankfurt',
    @start_ip_address = '77.247.7.17',
    @end_ip_address = '77.247.7.17'
GO

