--Updated 20211006
EXECUTE sp_set_firewall_rule @name = N'Ecolab Naperville',
		@start_ip_address = '206.197.60.5', 
		@end_ip_address = '206.197.60.5'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Eagan',
		@start_ip_address = '204.69.40.7', 
		@end_ip_address = '204.69.40.7'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Sydney',
		@start_ip_address = '119.31.169.119', 
		@end_ip_address = '119.31.169.119'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Singapore',
		@start_ip_address = '119.31.167.4', 
		@end_ip_address = '119.31.167.4'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Shanghai',
		@start_ip_address = '43.229.50.119', 
		@end_ip_address = '43.229.50.119'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Dominican Republic',
		@start_ip_address = '190.167.243.68', 
		@end_ip_address = '190.167.243.68'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Bueno Aires',
		@start_ip_address = '200.55.38.102', 
		@end_ip_address = '200.55.38.102'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Johannesburg',
		@start_ip_address = '41.160.30.74', 
		@end_ip_address = '41.160.30.74'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Dubai',
		@start_ip_address = '91.75.17.147', 
		@end_ip_address = '91.75.17.147'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Amsterdam Primary',
		@start_ip_address = '77.24.0.120', 
		@end_ip_address = '77.24.0.121'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Amsterdam Secondary',
		@start_ip_address = '206.197.58.150', 
		@end_ip_address = '206.197.58.150'
GO

EXECUTE sp_set_firewall_rule @name = N'Ecolab Frankfurt',
		@start_ip_address = '77.247.7.17', 
		@end_ip_address = '77.247.7.17'
GO
