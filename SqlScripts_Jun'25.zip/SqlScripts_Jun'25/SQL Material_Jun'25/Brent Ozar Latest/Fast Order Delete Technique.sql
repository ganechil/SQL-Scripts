SELECT *
	INTO dbo.Users_Staging
	FROM dbo.Users;

select count (*)
from  dbo.Users

select count (*)
from  dbo.Users_Staging

--then reverse the tables
 while 1<200000
insert	INTO dbo.Users_Staging
	(
	-- [Id]
      [AboutMe]
      ,[Age]
      ,[CreationDate]
      ,[DisplayName]
      ,[DownVotes]
      ,[EmailHash]
      ,[LastAccessDate]
      ,[Location]
      ,[Reputation]
      ,[UpVotes]
      ,[Views]
      ,[WebsiteUrl]
      ,[AccountId]
	)
	SELECT  --[Id]
      [AboutMe]
      ,[Age]
      ,[CreationDate]
      ,[DisplayName]
      ,[DownVotes]
      ,[EmailHash]
      ,[LastAccessDate]
      ,[Location]
      ,[Reputation]
      ,[UpVotes]
      ,[Views]
      ,[WebsiteUrl]
      ,[AccountId]	
	FROM dbo.Users;

/* Change some of their data randomly: */
Begin Tran
UPDATE dbo.Users_Staging
	SET 
	Reputation = CASE WHEN Id % 3 = 0 THEN Reputation + 100 ELSE Reputation END,
	LastAccessDate = CASE WHEN Id % 2 = 0 THEN GETDATE() ELSE LastAccessDate END,
	DownVotes = CASE WHEN Id % 9 = 0 THEN 0 ELSE DownVotes END,
	UpVotes = CASE WHEN Id % 12 = 0 THEN 0 ELSE UpVotes END,
	Views = CASE WHEN Id % 3 = 0 THEN Views + 1 ELSE Views END;
GO
Rollback
--DROP INDEX [Id] ON [dbo].[Users_Staging] WITH ( ONLINE = OFF )
--create this index at the end of the demo
--CREATE UNIQUE CLUSTERED INDEX Id ON dbo.Users_Staging(Id);

--Dont update here
Begin Tran
UPDATE u
	SET Age = us.Age, CreationDate = us.CreationDate, DisplayName = us.DisplayName,
	DownVotes = us.DownVotes, EmailHash = us.EmailHash, LastAccessDate = us.LastAccessDate,
	Location = us.Location, Reputation = us.Reputation, UpVotes = us.UpVotes,
	Views = us.Views, WebsiteUrl = us.WebsiteUrl, AccountId = us.AccountId
FROM dbo.Users u
INNER JOIN dbo.Users_Staging us ON u.Id = us.Id
--rollback


--ETL Proc to nibble off changed rows
CREATE OR ALTER PROC dbo.usp_UsersETL_HugeTime
	@RowsAffected INT = NULL OUTPUT AS
BEGIN
BEGIN TRAN;
	WITH RowsToUpdate AS (SELECT TOP 1000 * FROM dbo.Users_Staging ORDER BY Id
	)
	--Instead update here
	UPDATE u
		SET Age = us.Age, CreationDate = us.CreationDate, DisplayName = us.DisplayName,
		DownVotes = us.DownVotes, EmailHash = us.EmailHash, LastAccessDate = us.LastAccessDate,
		Location = us.Location, Reputation = us.Reputation, UpVotes = us.UpVotes,
		Views = us.Views, WebsiteUrl = us.WebsiteUrl, AccountId = us.AccountId
	OUTPUT INSERTED.Id INTO #RowsAffected
	FROM RowsToUpdate us
	INNER JOIN dbo.Users u ON u.Id = us.Id
	PRINT '... ' + RTRIM(@@ROWCOUNT) + ' rows Inserted.';
 
	DELETE dbo.Users_Staging
	WHERE Id IN (SELECT Id FROM #RowsAffected)
	PRINT '... ' + RTRIM(@@ROWCOUNT) + ' rows Deleted.';
 
COMMIT



CREATE OR ALTER PROC dbo.usp_UsersETL
	@RowsAffected INT = NULL OUTPUT AS
BEGIN
CREATE TABLE #RowsAffected (Id INT);
 
BEGIN TRAN;
	WITH RowsToUpdate AS (SELECT TOP 4000 * FROM dbo.Users_Staging ORDER BY Id
	)
	--Instead update here
	UPDATE u
		SET Age = us.Age, CreationDate = us.CreationDate, DisplayName = us.DisplayName,
		DownVotes = us.DownVotes, EmailHash = us.EmailHash, LastAccessDate = us.LastAccessDate,
		Location = us.Location, Reputation = us.Reputation, UpVotes = us.UpVotes,
		Views = us.Views, WebsiteUrl = us.WebsiteUrl, AccountId = us.AccountId
	OUTPUT INSERTED.Id INTO #RowsAffected
	FROM RowsToUpdate us
	INNER JOIN dbo.Users u ON u.Id = us.Id
	PRINT '... ' + RTRIM(@@ROWCOUNT) + ' rows Inserted.';
 
	DELETE dbo.Users_Staging
	WHERE Id IN (SELECT Id FROM #RowsAffected)
	PRINT '... ' + RTRIM(@@ROWCOUNT) + ' rows Deleted.';
 
COMMIT
SELECT @RowsAffected = COUNT(*) FROM #RowsAffected;
END
GO

  SELECT  count(*)
  FROM [StackOverflow2010].[dbo].[Users_Staging]
Begin Tran	Exec usp_UsersETL
	in 2nd session  sp_whoisactive @get_locks=1, @get_plans=1



	 SELECT  count(*)
  FROM [StackOverflow2010].[dbo].[Users_Staging]
	Begin Tran Exec usp_UsersETL
	in 2nd session  sp_whoisactive @get_locks=1, @get_plans=1


	--here change top 4000 to 1000 to see the difference between the locks X & IX
	CREATE TABLE #RowsAffected (Id INT);
BEGIN TRAN;
	WITH RowsToUpdate AS (SELECT TOP 4000 * FROM dbo.Users_Staging ORDER BY Id
	)
	--Instead update here
	UPDATE u
		SET Age = us.Age, CreationDate = us.CreationDate, DisplayName = us.DisplayName,
		DownVotes = us.DownVotes, EmailHash = us.EmailHash, LastAccessDate = us.LastAccessDate,
		Location = us.Location, Reputation = us.Reputation, UpVotes = us.UpVotes,
		Views = us.Views, WebsiteUrl = us.WebsiteUrl, AccountId = us.AccountId
	OUTPUT INSERTED.Id INTO #RowsAffected
	FROM RowsToUpdate us
	INNER JOIN dbo.Users u ON u.Id = us.Id
 
	DELETE dbo.Users_Staging
	WHERE Id IN (SELECT Id FROM #RowsAffected);
