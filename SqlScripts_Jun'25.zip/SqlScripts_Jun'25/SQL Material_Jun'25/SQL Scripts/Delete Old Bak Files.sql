Declare @deldate datetime
set @deldate = convert(nvarchar(20), dateadd(day, -3 , getdate()),120)
EXECUTE master.dbo.xp_delete_file 0,N'C:\Databasebackup\',N'BAK',@DelDate,1
go