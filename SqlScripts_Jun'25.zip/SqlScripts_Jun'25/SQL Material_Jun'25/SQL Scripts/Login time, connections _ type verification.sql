---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
--find out clinet app ip which is connecting to the database
SELECT login_name,Max(client_interface_name) As client_interface_name, Max(program_name) As program_name, Max(host_name) As host_name, 
MAX(login_time) AS [Last Login Time], Max(connect_time) As connect_time, Max(last_request_start_time) As last_request_start_time, Max(last_read) As last_read, Max(last_request_end_time) As last_request_end_time, Max(last_write) As last_write, 
Max(net_transport) As net_transport, Max(protocol_type) As protocol_type, Max(auth_scheme) As auth_scheme,
Max(client_net_address) As client_net_address, Max(client_tcp_port) As client_tcp_port, Max(local_net_address) As local_net_address, Max(local_tcp_port) As local_tcp_port, Max(most_recent_sql_handle) As most_recent_sql_handle
FROM sys.dm_exec_sessions
JOIN sys.dm_exec_connections ON sys.dm_exec_sessions.session_id = sys.dm_exec_connections.session_id
GROUP BY login_name;
--https://serverfault.com/questions/195939/how-can-i-see-who-is-connected-to-my-db
SELECT DB_NAME(dbid) as DBName, COUNT(dbid) as 'Number Of Connections',
    loginame as LoginName
FROM sys.sysprocesses
WHERE dbid > 0
GROUP BY dbid, loginame
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

--https://stackoverflow.com/questions/1248423/how-do-i-see-active-sql-server-connections#:~:text=In%20SQL%20Server%20Management%20Studio,shortcut%20Ctrl%20%2B%20Alt%20%2B%20A%20.&text=Below%20is%20my%20script%20to,an%20option%20to%20kill%20them.
--==============================================================================
-- See who is connected to the database.
-- Analyse what each spid is doing, reads and writes.
-- If safe you can copy and paste the killcommand - last column.
-- Marcelo Miorelli
-- 18-july-2017 - London (UK)
-- Tested on SQL Server 2016.
--==============================================================================
USE master
go
SELECT
     sdes.session_id
    ,sdes.login_time
    ,sdes.last_request_start_time
    ,sdes.last_request_end_time
    ,sdes.is_user_process
    ,sdes.host_name
    ,sdes.program_name
    ,sdes.login_name
    ,sdes.status

    ,sdec.num_reads
    ,sdec.num_writes
    ,sdec.last_read
    ,sdec.last_write
    ,sdes.reads
    ,sdes.logical_reads
    ,sdes.writes

    ,sdest.DatabaseName
    ,sdest.ObjName
    ,sdes.client_interface_name
    ,sdes.nt_domain
    ,sdes.nt_user_name
    ,sdec.client_net_address
    ,sdec.local_net_address
    ,sdest.Query
    ,KillCommand  = 'Kill '+ CAST(sdes.session_id  AS VARCHAR)
FROM sys.dm_exec_sessions AS sdes

INNER JOIN sys.dm_exec_connections AS sdec
        ON sdec.session_id = sdes.session_id

CROSS APPLY (

    SELECT DB_NAME(dbid) AS DatabaseName
        ,OBJECT_NAME(objectid) AS ObjName
        ,COALESCE((
            SELECT TEXT AS [processing-instruction(definition)]
            FROM sys.dm_exec_sql_text(sdec.most_recent_sql_handle)
            FOR XML PATH('')
                ,TYPE
            ), '') AS Query

    FROM sys.dm_exec_sql_text(sdec.most_recent_sql_handle)

) sdest
WHERE sdes.session_id <> @@SPID
  --AND sdest.DatabaseName ='BugTracker'
ORDER BY sdec.client_net_address 






---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

 
 select * from sys.dm_exec_sessions

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

select * from sys.dm_exec_connections

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

select * from sys.syslogins

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

SELECT *
FROM master.sys.sql_logins;
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

sp_helplogins
Go

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

SP_HELPUSER
Go

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

EXEC xp_logininfo 
Go

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------


SELECT name AS Login_Name, type_desc AS Account_Type
FROM sys.server_principals 
WHERE TYPE IN ('U', 'S', 'G')
and name not like '%##%'
ORDER BY name, type_desc

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

 
 select login_name, client_interface_name, program_name, host_name, login_time, last_request_start_time,last_request_end_time,  
 * FROM sys.dm_exec_sessions
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

 SELECT *  FROM sys.dm_exec_connections
ORDER BY session_id, last_write DESC,last_read DESC

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

SELECT login_name, max(login_time) as last_logged_in 
FROM sys.dm_exec_sessions GROUP BY login_name

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

SELECT login_name [Login] , MAX(login_time) AS [Last Login Time]
FROM sys.dm_exec_sessions
GROUP BY login_name;

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
--
SELECT 
    DB_NAME(dbid) as DBName, 
    COUNT(dbid) as NumberOfConnections,
    loginame as LoginName
FROM
    sys.sysprocesses
WHERE 
    dbid > 0
GROUP BY 
    dbid, loginame
;
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------


---Which logins have logged in within the last X hours?
SELECT [Login] = login_name
	,[Last Login Time] = login_time
	,[Host] = HOST_NAME
	,[Program] = PROGRAM_NAME
	,[Client Interface] =  client_interface_name
	,[Database] = DB_NAME(database_id)
FROM sys.dm_exec_sessions
WHERE [login_time] > DATEADD(HH,-4,getdate())--modify date as needed
ORDER BY [login_time] desc

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

---login counts for the last 4 hours
SELECT [Login] = login_name
	,[Last Login Time] = MAX(login_time)
	,[Number Of Logins] = COUNT(*)
FROM sys.dm_exec_sessions
WHERE [login_time] > DATEADD(HH,-4,getdate())--modify date as needed
GROUP BY [login_name]
ORDER BY [Login] desc


---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

--
SELECT conn.session_id, host_name, program_name,
    nt_domain, login_name, connect_time, last_request_end_time 
FROM sys.dm_exec_sessions AS sess
JOIN sys.dm_exec_connections AS conn
   ON sess.session_id = conn.session_id;
   
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------   


---check for logins with sysadmin access
SELECT [Login] = name
	,[Login Type] = type_desc
	,[Disabled] = is_disabled
FROM     master.sys.server_principals 
WHERE    IS_SRVROLEMEMBER ('sysadmin',name) = 1
ORDER BY [Login]

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
---password update check
select updatedate as Update_Date, dbname, loginname as Login_Name, sysadmin as Sys_Admin, 
denylogin, sid, password, * 
from sys.syslogins
Where loginname not like 'NT %' and loginname not like '##MS%'
order by sysadmin desc, updatedate desc
Go
 
 ---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
 
 select * from sys.sql_logins

 ---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
 

sp_helplogins

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

sp_helpuser

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

SELECT name, type_desc, is_disabled
FROM sys.server_principals

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

select sp.name as login,
       sp.type_desc as login_type,
       sl.password_hash,
       sp.create_date,
       sp.modify_date,
       case when sp.is_disabled = 1 then 'Disabled'
            else 'Enabled' end as status
from sys.server_principals sp
left join sys.sql_logins sl
          on sp.principal_id = sl.principal_id
where sp.type not in ('G', 'R')
order by sp.name;
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------








