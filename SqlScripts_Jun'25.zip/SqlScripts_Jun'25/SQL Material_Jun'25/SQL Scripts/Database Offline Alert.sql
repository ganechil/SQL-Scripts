if(select count(*) from sys.databases where state_desc<>'Online')>0
Begin

DECLARE @table  NVARCHAR(MAX) ;

SET @table =
    N'<H1>MS SQL  Databases Offline Report</H1>' +
    N'<table border="1">' +
    N'<tr><th bgcolor="#5D7B9D"><font color="#fff">Database Name</font></th><th bgcolor="#5D7B9D"><font color="#fff">Server Name</font></th><th bgcolor="#5D7B9D"><font color="#fff">Database Status</font></th></tr>' +
    CAST ( ( Select td=name,@@servername, '',td=state_desc from sys.databases where state_desc<>'Online'
              FOR XML PATH('tr'), TYPE
    ) AS NVARCHAR(MAX) )    +
    N'</table>' ;

EXEC msdb.dbo.sp_send_dbmail @profile_name='SQLAlert', --Change to your Profile Name
     @recipients='sqlsupport@ncdex.com', --Put the email address of those who want to receive the e-mail
    @subject = 'MS SQL Databases Offline Alert',
    @body = @table,
    @body_format = 'HTML' ;

END
Else Print 'All Databases are Online'




--https://sqlzealots.com/2020/09/06/when-was-the-database-taken-offline-online-in-sql-server/
DECLARE  @DBNAME nvarchar(100)
  ,@FileName nvarchar(max)
  ,@Status nvarchar(10)
  
SET @DBNAME = 'ServiDA' -- Provide [DBNAME]
SET @Status = 'OFFLINE' --Provide [OFFLINE / ONLINE]
SELECT @FileName=[path] FROM sys.traces WHERE is_default=1

DECLARE @ErrorLogTable table (Logdate datetime, ProcessInfo nvarchar(10), [Text] nvarchar(max))

INSERT INTO @ErrorLogTable
EXEC xp_readerrorlog 0,1, @Status, @DBNAME, NULL, NULL, 'desc'

SELECT Distinct DatabaseID, DatabaseName, HostName, ApplicationName, LoginName, StartTime, B.ProcessInfo, B.Text
FROM sys.fn_trace_gettable( @FileName, DEFAULT ) A
Inner join @ErrorLogTable B on A.SPID = cast(SUBSTRING(B.ProcessInfo,5,5) AS int)
and CAST(StartTime AS nvarchar)=cast(B.Logdate AS nvarchar) 




--http://sqldbanotes.blogspot.com/2017/01/sql-server-when-was-database-taken.html
DECLARE  @DBNAME nvarchar(100)
  ,@FileName nvarchar(max)
  ,@spid int
  ,@LogDate Datetime
  ,@Status nvarchar(10)
  
SET @DBNAME = 'ServiDA' -- Change DB Name
SET @Status = 'OFFLINE' --[OFFLINE or ONLINE]
SELECT @FileName=[path] FROM sys.traces WHERE is_default=1
DECLARE @ErrorLogTable table (Logdate datetime, ProcessInfo nvarchar(10), [Text] nvarchar(max))
INSERT INTO @ErrorLogTable
EXEC xp_readerrorlog 0,1, @Status, @DBNAME, NULL, NULL, 'desc'
SELECT TOP 1 @spid=cast(SUBSTRING(ProcessInfo,5,5) AS int)
   ,@LogDate=cast(Logdate AS nvarchar)
FROM @ErrorLogTable
SELECT DatabaseID, DatabaseName, HostName, ApplicationName, LoginName, StartTime
FROM sys.fn_trace_gettable( @FileName, DEFAULT )
WHERE spid=@spid and DatabaseName=@DBNAME and CAST(StartTime AS nvarchar)=@LogDate


--If you didn't get the result by running above code it means, trace is reset after the database went offline. 
--In this case go run following code and get the path.
--select path FROM sys.traces WHERE is_default=1
--Change file name and run following code. Last row will have the timestamp. 
--SELECT DatabaseID, DatabaseName, HostName, ApplicationName, LoginName, StartTime
--FROM sys.fn_trace_gettable( 'H:\sqlsysdb\MSSQL10\MSSQL\Log\log_228.trc', DEFAULT )
--WHERE DatabaseName='TestDB'


--https://stackoverflow.com/questions/1972412/tsql-to-find-when-was-the-database-taken-offline
DECLARE @FileName VARCHAR(MAX)
SELECT @FileName = SUBSTRING(path, 0, LEN(path)-CHARINDEX('\', REVERSE(path))+1) + '\Log.trc'
FROM sys.traces
WHERE is_default = 1;
SELECT

    gt.EventClass,
    e.name as EventName,
    gt.TextData,
    gt.ObjectID,
    gt.ObjectName,
    gt.DatabaseName,
    gt.SessionLoginName,
    gt.StartTime,
    gt.ApplicationName,
    gt.HostName,
    gt.NTUserName,
    gt.NTDomainName
FROM sys.fn_trace_gettable( @FileName, DEFAULT ) AS gt
JOIN sys.trace_events e 
    ON gt.EventClass = e.trace_event_id
WHERE gt.EventClass = 164  -- Object Altered Event
  AND ObjectType = 16964   -- Database Object