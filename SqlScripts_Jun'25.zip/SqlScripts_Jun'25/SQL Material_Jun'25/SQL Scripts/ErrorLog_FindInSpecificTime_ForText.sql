--Query to list error log and their sizes
EXEC sys.sp_enumerrorlogs;


--https://www.sqlshack.com/read-sql-server-error-logs-using-the-xp_readerrorlog-command/
Exec xp_ReadErrorLog  &lt;LogNumber&gt;, &lt;LogType&gt;, &lt;SearchItem1&gt;, &lt;StartDate&gt;, &lt;EndDate&gt;, &lt;SortOrder&gt;
LogNumber: It is the log number of the error log. You can see the lognumber in the above screenshot. Zero is always referred to as the current log file
LogType: We can use this command to read both SQL Server error logs and agent logs
		 1 – To read the SQL Server error log
	     2- To read SQL Agent logs
SearchItem1: In this parameter, we specify the search keyword
SearchItem2: We can use additional search items. Both conditions ( SearchItem1 and SearchItem2) should be satisfied with the results
StartDate and EndDate: We can filter the error log between StartDate and EndDate
SortOrder: We can specify ASC (Ascending) or DSC (descending) for sorting purposes


----https://www.sqlshack.com/read-sql-server-error-logs-using-the-xp_readerrorlog-command/
EXEC xp_readerrorlog 
    0, --change this number ranging from 0 to 6 one-by-one to check from newest to oldest
    1, --To read the SQL Server error log
--	2, --To read SQL Agent logs
    N'', --SearchItem1: In this parameter, we specify the search keyword
    N'', --SearchItem2: We can use additional search items. Both conditions ( SearchItem1 and SearchItem2) should be satisfied with the results
    N'2025-04-03 00:00:01.000', 
    N'2025-04-05 23:59:58.000',
    N'desc'
	
EXEC xp_ReadErrorLog 0, 1, error, NULL, '20200701', '20200715', 'DESC'	



--https://dbtut.com/index.php/2018/12/17/how-to-filter-sql-server-error-loglike-or-not-like/
CREATE TABLE #read_error_log
(
    logdate      DATETIME,
    processinfo  VARCHAR(200),
    errorlogtext VARCHAR(max)
)

INSERT INTO #read_error_log
EXEC master.dbo.Xp_readerrorlog
    0, -- To read the SQL Server error log
    1, -- To read SQL Agent logs
    N'brnetinterface1',
    N'',
    '20250403',
    '20250405'
	--'2025-04-09 00:00:01.000',
    --'2025-04-19 23:59:58.000'

SELECT DISTINCT errorlogtext, MAX(logdate) AS LatestLogDate
FROM #read_error_log
WHERE errorlogtext NOT LIKE '%Log was backed up.%'
  AND errorlogtext NOT LIKE '%Database differential changes were backed up.%'
  AND errorlogtext NOT LIKE '%BACKUP failed to complete the command BACKUP%'
  AND errorlogtext NOT LIKE '%SSPI handshake failed with error code%'
  AND errorlogtext NOT LIKE '%Login failed. The login is from an untrusted domain and cannot be used with Windows authentication%'
--and errorlogtext not like '%Login failed for user%'
--errorlogtext  like '%There is insufficient system memory in resource pool%'
--or errorlogtext  like '%Failed Virtual Allocate Bytes:%'
--or errorlogtext  like '%Memory constraints resulted reduced backup/restore buffer sizes%'
GROUP BY errorlogtext
order by LatestLogDate desc

TRUNCATE TABLE #read_error_log
DROP TABLE #read_error_log
