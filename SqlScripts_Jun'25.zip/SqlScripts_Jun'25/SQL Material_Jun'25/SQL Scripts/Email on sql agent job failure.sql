﻿1) Step Name: Notify Due To Failure
2) Type: Operating System(CmdExec)
3) Run As: SQL Server Agent Service Account
4) Command: Powershell -command "& {send-mailmessage -To sqlsupport@ncdex.com -From sqlsupport@ncdex.com -subject 'Delete Old Bak Files_Job Failed on 172.30.2.139' -body 'SQL Server Agent Job Failed. Please check & verify job step list.' -SmtpServer 172.30.2.171}"
5) Second Last Step: OnSuccess-Quit the Job Reporting Success & OnFailure-Go To StepName:Notify Due To Failure
6) Last Step: OnSuccess-Quit The Job Reporting Failure & OnFailure-Quit The Job Reporting Failure