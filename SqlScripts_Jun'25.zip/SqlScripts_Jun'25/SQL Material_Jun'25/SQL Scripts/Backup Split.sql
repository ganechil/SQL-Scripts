USE [master]
RESTORE DATABASE [AttachDetachCopy] 
FROM  
DISK = N'F:\SQL\AttachDetach_MultiFile01.bak',  
DISK = N'F:\SQL\SQL14INST\AttachDetach_MultiFile01.bak', 
DISK = N'F:\SQL\SQL14INST\Backup\AttachDetach_MultiFile03.bak'
 WITH  FILE = 1,  
 MOVE N'AttachDetach' TO N'F:\SQL\SQL14INST\MDF\AttachDetachCopy.mdf',  
 MOVE N'AttachDetach_Sec01' TO N'F:\SQL\SQL14INST\NDF\AttachDetachCopy_Sec01.ndf',  
 MOVE N'AttachDetach_Sec02' TO N'F:\SQL\SQL14INST\NDF\AttachDetachCopy_Sec02.ndf',  
 MOVE N'AttachDetach_Sec03' TO N'F:\SQL\SQL14INST\NDF\AttachDetachCopy_Sec03.ndf',  
 MOVE N'AttachDetach_Sec04' TO N'F:\SQL\SQL14INST\NDF\AttachDetachCopy_Sec04.ndf',  
 MOVE N'AttachDetach_log' TO N'F:\SQL\SQL14INST\LDF\AttachDetachCopy_log.ldf',  
 NOUNLOAD,  STATS = 5
GO




backup Log [AttachDetach]
To Disk = 'F:\SQL\AttachDetach_MultiFile01.trn',
Disk = 'F:\SQL\SQL14INST\AttachDetach_MultiFile01.trn',
Disk = 'F:\SQL\SQL14INST\Backup\AttachDetach_MultiFile03.trn'
With Name='AttachDetach_Trn_2019-07-31 01:59:59',
Description='AttachDetach_Trn_2019-07-31 01:59:29',
Compression





Alter Database [AttachDetach]
Modify File
(
Name=AttachDetach,
FileName='F:\SQL\SQL14INST\AttachDetach.mdf'
)

Alter Database [AttachDetach]
Modify File
(
Name=AttachDetach_Sec01,
FileName='F:\SQL\SQL14INST\AttachDetach_sec01.ndf'
)

Alter Database [AttachDetach]
Modify File
(
Name=AttachDetach_Sec02,
FileName='F:\SQL\SQL14INST\AttachDetach_sec02.ndf'
)

Alter Database [AttachDetach]
Modify File
(
Name=AttachDetach_Sec03,
FileName='F:\SQL\SQL14INST\AttachDetach_sec03.ndf'
)

Alter Database [AttachDetach]
Modify File
(
Name=AttachDetach_Sec04,
FileName='F:\SQL\SQL14INST\AttachDetach_sec04.ndf'
)

Alter Database [AttachDetach]
Modify File
(
Name=AttachDetach_log,
FileName='F:\SQL\SQL14INST\AttachDetach_log.ldf'
)
