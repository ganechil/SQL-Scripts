sp_helpdb
order by db_size


CREATE TABLE #test (name varchar(100), db_size varchar(100),owner varchar(100),db_id int,created varchar(100),status varchar(1000),compatibility_level int)
 
INSERT #test 
EXEC sp_helpdb
 
SELECT name,db_size,owner,db_id,created,compatibility_level 
FROM #test
ORDER BY CONVERT(float,REPLACE(db_size,' MB','')) DESC

DROP TABLE #test 