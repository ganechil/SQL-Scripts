SELECT * FROM sys.dm_os_performance_counters
WHERE counter_name LIKE 'buffer%'




SELECT *  FROM Sales.SalesOrderHeader
SELECT *  FROM Sales.SalesOrderHeader




SELECT
    max_logical_reads, total_logical_reads, last_logical_reads,
    max_physical_reads, total_physical_reads, last_physical_reads,
    execution_count, QueryString
FROM sys.dm_exec_query_stats 
CROSS APPLY (SELECT SUBSTRING(text, statement_start_offset/2 + 1,
        (CASE WHEN statement_end_offset = -1 
            THEN LEN(CONVERT(nvarchar(MAX),text)) * 2 
                ELSE statement_end_offset 
            END - statement_start_offset)/2) AS QueryString
     FROM sys.dm_exec_sql_text(sql_handle)
    ) AS query_text
WHERE QueryString LIKE '%MyOrder%'
ORDER BY total_physical_reads DESC