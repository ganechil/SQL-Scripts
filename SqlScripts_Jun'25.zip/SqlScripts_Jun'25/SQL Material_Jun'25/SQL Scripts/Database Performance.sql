------------------Tables & Sizes----------------------
	select * from sys.tables
	Where object_id=734729770


	SELECT
	s.Name AS SchemaName,
	t.Name AS TableName,
	p.rows AS RowCounts,
	CAST(ROUND((SUM(a.used_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS Used_MB,
	CAST(ROUND((SUM(a.total_pages) - SUM(a.used_pages)) / 128.00, 2) AS NUMERIC(36, 2)) AS Unused_MB,
	CAST(ROUND((SUM(a.total_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS Total_MB
	FROM sys.tables t
	INNER JOIN sys.indexes i ON t.OBJECT_ID = i.object_id
	INNER JOIN sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
	INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
	INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
	GROUP BY t.Name, s.Name, p.Rows
	ORDER BY Total_MB desc, TableName asc
	GO


----------------------Indexe & Sizes-----------------

    select * from sys.indexes
	   

		Select * from sys.sysindexes
  		order by rowmodctr desc

			Select RowModCtr from Sys.SysIndexes 
			Where name ='[XroadzDB].[xradm].[hrm_new_user_request_details]'


				SELECT
				OBJECT_SCHEMA_NAME(i.OBJECT_ID) AS SchemaName,
				OBJECT_NAME(i.OBJECT_ID) AS TableName,
				i.name AS IndexName,
				i.index_id AS IndexID,
				8 * SUM(a.used_pages) AS 'Indexsize(KB)'
				FROM sys.indexes AS i
				JOIN sys.partitions AS p ON p.OBJECT_ID = i.OBJECT_ID AND p.index_id = i.index_id
				JOIN sys.allocation_units AS a ON a.container_id = p.partition_id
				GROUP BY i.OBJECT_ID,i.index_id,i.name
				ORDER BY [Indexsize(KB)] desc




			



-----------Fragmentation of INDEXES & Tables--------------



      select * from sys.dm_db_index_physical_stats(null, null, null, null, null)
      where object_id=734729770 and database_id = 19 and avg_fragmentation_in_percent>25
	  order by  avg_fragmentation_in_percent desc



	  
		SELECT  OBJECT_NAME(IDX.OBJECT_ID) AS Table_Name, 
		IDX.name AS Index_Name, 
		IDXPS.index_type_desc AS Index_Type, 
		IDXPS.avg_fragmentation_in_percent  Fragmentation_Percentage
		FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) IDXPS 
		INNER JOIN sys.indexes IDX  ON IDX.object_id = IDXPS.object_id 
		AND IDX.index_id = IDXPS.index_id 		
		ORDER BY Fragmentation_Percentage DESC



      SELECT OBJECT_NAME(ips.OBJECT_ID) AS Table_Name, 
	  i.NAME
	 ,ips.index_id
	 ,index_type_desc
	 ,avg_fragmentation_in_percent
	 ,avg_page_space_used_in_percent
	 ,page_count
	 FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, 'SAMPLED') ips
	 INNER JOIN sys.indexes i ON (ips.object_id = i.object_id)
	 AND (ips.index_id = i.index_id)	
	 ORDER BY avg_fragmentation_in_percent DESC







--------------------Missing Index-------------------------
		SELECT * FROM sys.dm_db_missing_index_details


		-- Missing Index Script
	                     	-- Original Author: Pinal Dave 
		SELECT TOP 200
		dm_mid.database_id AS DatabaseID,
		dm_migs.avg_user_impact*(dm_migs.user_seeks+dm_migs.user_scans) Avg_Estimated_Impact,
		dm_migs.last_user_seek AS Last_User_Seek,
		OBJECT_NAME(dm_mid.OBJECT_ID,dm_mid.database_id) AS [TableName],
		'CREATE INDEX [IX_' + OBJECT_NAME(dm_mid.OBJECT_ID,dm_mid.database_id) + '_'
		+ REPLACE(REPLACE(REPLACE(ISNULL(dm_mid.equality_columns,''),', ','_'),'[',''),']','') 
		+ CASE
		WHEN dm_mid.equality_columns IS NOT NULL
		AND dm_mid.inequality_columns IS NOT NULL THEN '_'
		ELSE ''
		END
		+ REPLACE(REPLACE(REPLACE(ISNULL(dm_mid.inequality_columns,''),', ','_'),'[',''),']','')
		+ ']'
		+ ' ON ' + dm_mid.statement
		+ ' (' + ISNULL (dm_mid.equality_columns,'')
		+ CASE WHEN dm_mid.equality_columns IS NOT NULL AND dm_mid.inequality_columns 
		IS NOT NULL THEN ',' ELSE
		'' END
		+ ISNULL (dm_mid.inequality_columns, '')
		+ ')'
		+ ISNULL (' INCLUDE (' + dm_mid.included_columns + ')', '') AS Create_Statement
		FROM sys.dm_db_missing_index_groups dm_mig
		INNER JOIN sys.dm_db_missing_index_group_stats dm_migs
		ON dm_migs.group_handle = dm_mig.index_group_handle
		INNER JOIN sys.dm_db_missing_index_details dm_mid
		ON dm_mig.index_handle = dm_mid.index_handle
		WHERE dm_mid.database_ID = DB_ID()
		ORDER BY Avg_Estimated_Impact DESC
		GO





----------------------- Unused Index Script-------------------------------
			  			   
			                   	-- Original Author: Pinal Dave
								 
                Select * FROM sys.dm_db_index_usage_stats
				Where index_id<1
				

				SELECT TOP 200
				o.name AS ObjectName
				, i.name AS IndexName
				, i.index_id AS IndexID
				, dm_ius.user_seeks AS UserSeek
				, dm_ius.user_scans AS UserScans
				, dm_ius.user_lookups AS UserLookups
				, dm_ius.user_updates AS UserUpdates
				, p.TableRows
				, 'DROP INDEX ' + QUOTENAME(i.name)
				+ ' ON ' + QUOTENAME(s.name) + '.'
				+ QUOTENAME(OBJECT_NAME(dm_ius.OBJECT_ID)) AS 'drop statement'
				FROM sys.dm_db_index_usage_stats dm_ius
				INNER JOIN sys.indexes i ON i.index_id = dm_ius.index_id 
				AND dm_ius.OBJECT_ID = i.OBJECT_ID
				INNER JOIN sys.objects o ON dm_ius.OBJECT_ID = o.OBJECT_ID
				INNER JOIN sys.schemas s ON o.schema_id = s.schema_id
				INNER JOIN (SELECT SUM(p.rows) TableRows, p.index_id, p.OBJECT_ID
				FROM sys.partitions p GROUP BY p.index_id, p.OBJECT_ID) p
				ON p.index_id = dm_ius.index_id AND dm_ius.OBJECT_ID = p.OBJECT_ID
				WHERE OBJECTPROPERTY(dm_ius.OBJECT_ID,'IsUserTable') = 1
				AND dm_ius.database_id = DB_ID()
				AND i.type_desc = 'nonclustered'
				AND i.is_primary_key = 0
				AND i.is_unique_constraint = 0
				ORDER BY (dm_ius.user_seeks + dm_ius.user_scans + dm_ius.user_lookups) ASC
				GO








---------------USer Seek, Scan, Lookup, Update--------------
		 SELECT OBJECT_NAME(S.[OBJECT_ID]) AS [OBJECT NAME], 
         I.[NAME] AS [INDEX NAME], 
         USER_SEEKS, 
         USER_SCANS, 
         USER_LOOKUPS, 
         USER_UPDATES 
		 FROM SYS.DM_DB_INDEX_USAGE_STATS AS S 
         INNER JOIN SYS.INDEXES AS I 
         ON I.[OBJECT_ID] = S.[OBJECT_ID] 
         AND I.INDEX_ID = S.INDEX_ID 
	     WHERE OBJECTPROPERTY(S.[OBJECT_ID],'IsUserTable') = 1 



-------------------------Leaf Insert, Update, Delete-------------------------
	   SELECT OBJECT_NAME(A.[OBJECT_ID]) AS [OBJECT NAME], 
       I.[NAME] AS [INDEX NAME], 
       A.LEAF_INSERT_COUNT, 
       A.LEAF_UPDATE_COUNT, 
       A.LEAF_DELETE_COUNT 
	   FROM SYS.DM_DB_INDEX_OPERATIONAL_STATS (NULL,NULL,NULL,NULL ) A 
       INNER JOIN SYS.INDEXES AS I 
       ON I.[OBJECT_ID] = A.[OBJECT_ID] 
       AND I.INDEX_ID = A.INDEX_ID 
       WHERE OBJECTPROPERTY(A.[OBJECT_ID],'IsUserTable') = 1







-----------------------STATISTICS---------------------
select * from sys.stats
where object_id='734729770'
order by name


-- Script - Find Details for Statistics of Whole Database
-- (c) Pinal Dave
-- Download Script from - https://blog.sqlauthority.com/contact-me/sign-up/
SELECT DISTINCT
OBJECT_NAME(s.[object_id]) AS TableName,
c.name AS ColumnName,
s.name AS StatName,
STATS_DATE(s.[object_id], s.stats_id) AS LastUpdated,
DATEDIFF(d,STATS_DATE(s.[object_id], s.stats_id),getdate()) DaysOld,
dsp.modification_counter,
s.auto_created,
s.user_created,
s.no_recompute,
s.[object_id],
s.stats_id,
sc.stats_column_id,
sc.column_id
FROM sys.stats s
JOIN sys.stats_columns sc
ON sc.[object_id] = s.[object_id] AND sc.stats_id = s.stats_id
JOIN sys.columns c ON c.[object_id] = sc.[object_id] AND c.column_id = sc.column_id
JOIN sys.partitions par ON par.[object_id] = s.[object_id]
JOIN sys.objects obj ON par.[object_id] = obj.[object_id]
CROSS APPLY sys.dm_db_stats_properties(sc.[object_id], s.stats_id) AS dsp
WHERE OBJECTPROPERTY(s.OBJECT_ID,'IsUserTable') = 1
AND (s.auto_created = 1 OR s.user_created = 1)
ORDER BY DaysOld Desc;





SELECT 
object_name(si.[object_id]) 
AS [TableName]
, CASE 
WHEN si.[index_id] = 0 then 'Heap'
WHEN si.[index_id] = 1 then 'CL'
WHEN si.[index_id] BETWEEN 2 AND 250 THEN 'NC ' + RIGHT('00' + convert(varchar, si.[index_id]), 3)
ELSE ''
 END AS [IndexType]
, si.[name] AS [IndexName]
, si.[index_id]
AS [IndexID]
, CASE
WHEN si.[index_id] BETWEEN 1 AND 250 AND STATS_DATE (si.[object_id], si.[index_id]) < DATEADD(m, -1, getdate()) 
THEN '!! More than a month OLD !!'
WHEN si.[index_id] BETWEEN 1 AND 250 AND STATS_DATE (si.[object_id], si.[index_id]) < DATEADD(wk, -1, getdate()) 
THEN '! Within the past month !'
WHEN si.[index_id] BETWEEN 1 AND 250 THEN 'Stats recent'
ELSE ''
 END AS [Warning]
, STATS_DATE (si.[object_id], si.[index_id]) AS [Last Stats Update]
FROM sys.indexes AS si
WHERE OBJECTPROPERTY(si.[object_id], 'IsUserTable') = 1
ORDER BY [TableName], si.[index_id]
go



--This script is compatible with SQL Server 2005 and above.
SELECT
  id                    AS [Table ID]
, OBJECT_NAME(id)       AS [Table Name]
, name                  AS [Index Name]
, STATS_DATE(id, indid) AS [LastUpdated]
, rowmodctr             AS [Rows Modified]
FROM sys.sysindexes 
WHERE STATS_DATE(id, indid)<=DATEADD(DAY,-1,GETDATE()) 
AND rowmodctr>0 AND (OBJECTPROPERTY(id,'IsUserTable'))=1
GO



SELECT 
object_name(si.[object_id]) 
AS [TableName]
, CASE 
WHEN si.[index_id] = 0 then 'Heap'
WHEN si.[index_id] = 1 then 'CL'
WHEN si.[index_id] BETWEEN 2 AND 250 THEN 'NC ' + RIGHT('00' + convert(varchar, si.[index_id]), 3)
ELSE ''
 END AS [IndexType]
, si.[name] AS [IndexName]
, si.[index_id]
AS [IndexID]
, CASE
WHEN si.[index_id] BETWEEN 1 AND 250 AND STATS_DATE (si.[object_id], si.[index_id]) < DATEADD(m, -1, getdate()) 
THEN '!! More than a month OLD !!'
WHEN si.[index_id] BETWEEN 1 AND 250 AND STATS_DATE (si.[object_id], si.[index_id]) < DATEADD(wk, -1, getdate()) 
THEN '! Within the past month !'
WHEN si.[index_id] BETWEEN 1 AND 250 THEN 'Stats recent'
ELSE ''
 END AS [Warning]
, STATS_DATE (si.[object_id], si.[index_id]) AS [Last Stats Update]
FROM sys.indexes AS si
WHERE OBJECTPROPERTY(si.[object_id], 'IsUserTable') = 1
ORDER BY [TableName], si.[index_id]
go



Use XroadzDB
Go
SELECT 
  st.object_id                          AS [Table ID]
, OBJECT_NAME(st.object_id)             AS [Table Name]
, st.name                               AS [Index Name]
, STATS_DATE(st.object_id, st.stats_id) AS [LastUpdated]
, modification_counter                  AS [Rows Modified]
FROM
sys.stats st 
CROSS APPLY
sys.dm_db_stats_properties(st.object_id, st.stats_id) AS sp 
WHERE
STATS_DATE(st.object_id, st.stats_id)<=DATEADD(DAY,-1,GETDATE())  
AND modification_counter > 0 
AND OBJECTPROPERTY(st.object_id,'IsUserTable')=1
GO






Select OBJECT_NAME(OBJECT_ID) as Table_Name,
name as Stats_Name,
STATS_DATE(object_id, stats_id) as Last_Update
From sys.stats
Where OBJECTPROPERTY(OBJECT_ID, 'IsUserTable') = 1 
Order By Last_Update desc


SELECT name AS index_name,
STATS_DATE(OBJECT_ID, index_id) AS StatsUpdated
FROM sys.indexes
WHERE OBJECT_ID = OBJECT_ID('[xradm].[hrm_new_user_request_details]')
GO


Exec Sp_HelpIndex '[XroadzDB].[xradm].[hrm_new_user_request_details]'



DBCC Show_Statistics('aa', 'ClusteredIndex-20190517-170625')
 

Update Statistics [XroadzDB].[xradm].[hrm_new_user_request_details]

With NoRecompute


SP_UpdateStats




---------------------------------Locks Wait Time-------------------------------


-- SQL Wait Stats and Queies
-- (C) Pinal Dave https://blog.sqlauthority.com/ ) 2016
-- Send query result to pinal@sqlauthority.com for quick feedback
SELECT  wait_type AS Wait_Type, 
wait_time_ms / 1000.0 AS Wait_Time_Seconds,
waiting_tasks_count AS Waiting_Tasks_Count,
-- CAST((wait_time_ms / 1000.0)/waiting_tasks_count AS decimal(10,4)) AS AVG_Waiting_Tasks_Count,
wait_time_ms * 100.0 / SUM(wait_time_ms) OVER() AS Percentage_WaitTime
--,waiting_tasks_count * 100.0 / SUM(waiting_tasks_count) OVER() AS Percentage_Count
FROM sys.dm_os_wait_stats
WHERE wait_type NOT IN
(N'BROKER_EVENTHANDLER',
N'BROKER_RECEIVE_WAITFOR',
N'BROKER_TASK_STOP',
N'BROKER_TO_FLUSH',
N'BROKER_TRANSMITTER',
N'CHECKPOINT_QUEUE',
N'CHKPT',
N'CLR_AUTO_EVENT',
N'CLR_MANUAL_EVENT',
N'CLR_SEMAPHORE',
N'DBMIRROR_DBM_EVENT',
N'DBMIRROR_DBM_MUTEX',
N'DBMIRROR_EVENTS_QUEUE',
N'DBMIRROR_WORKER_QUEUE',
N'DBMIRRORING_CMD',
N'DIRTY_PAGE_POLL',
N'DISPATCHER_QUEUE_SEMAPHORE',
N'EXECSYNC',
N'FSAGENT',
N'FT_IFTS_SCHEDULER_IDLE_WAIT',
N'FT_IFTSHC_MUTEX',
N'HADR_CLUSAPI_CALL',
N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',
N'HADR_LOGCAPTURE_WAIT',
N'HADR_NOTIFICATION_DEQUEUE',
N'HADR_TIMER_TASK',
N'HADR_WORK_QUEUE',
N'LAZYWRITER_SLEEP',
N'LOGMGR_QUEUE',
N'MEMORY_ALLOCATION_EXT',
N'ONDEMAND_TASK_QUEUE',
N'PREEMPTIVE_HADR_LEASE_MECHANISM',
N'PREEMPTIVE_OS_AUTHENTICATIONOPS',
N'PREEMPTIVE_OS_AUTHORIZATIONOPS',
N'PREEMPTIVE_OS_COMOPS',
N'PREEMPTIVE_OS_CREATEFILE',
N'PREEMPTIVE_OS_CRYPTOPS',
N'PREEMPTIVE_OS_DEVICEOPS',
N'PREEMPTIVE_OS_FILEOPS',
N'PREEMPTIVE_OS_GENERICOPS',
N'PREEMPTIVE_OS_LIBRARYOPS',
N'PREEMPTIVE_OS_PIPEOPS',
N'PREEMPTIVE_OS_QUERYREGISTRY',
N'PREEMPTIVE_OS_VERIFYTRUST',
N'PREEMPTIVE_OS_WAITFORSINGLEOBJECT',
N'PREEMPTIVE_OS_WRITEFILEGATHER',
N'PREEMPTIVE_SP_SERVER_DIAGNOSTICS',
N'PREEMPTIVE_XE_GETTARGETSTATE',
N'PWAIT_ALL_COMPONENTS_INITIALIZED',
N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',
N'QDS_ASYNC_QUEUE',
N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',
N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',
N'QDS_SHUTDOWN_QUEUE',
N'REDO_THREAD_PENDING_WORK',
N'REQUEST_FOR_DEADLOCK_SEARCH',
N'RESOURCE_QUEUE',
N'SERVER_IDLE_CHECK',
N'SLEEP_BPOOL_FLUSH',
N'SLEEP_DBSTARTUP', 
N'SLEEP_DCOMSTARTUP',
N'SLEEP_MASTERDBREADY', 
N'SLEEP_MASTERMDREADY',
N'SLEEP_MASTERUPGRADED', 
N'SLEEP_MSDBSTARTUP',
N'SLEEP_SYSTEMTASK', 
N'SLEEP_TASK',
N'SP_SERVER_DIAGNOSTICS_SLEEP',
N'SQLTRACE_BUFFER_FLUSH',
N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
N'SQLTRACE_WAIT_ENTRIES',
N'UCS_SESSION_REGISTRATION',
N'WAIT_FOR_RESULTS',
N'WAIT_XTP_CKPT_CLOSE',
N'WAIT_XTP_HOST_WAIT',
N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG',
N'WAIT_XTP_RECOVERY',
N'WAITFOR',
N'WAITFOR_TASKSHUTDOWN',
N'XE_TIMER_EVENT',
N'XE_DISPATCHER_WAIT'
) AND wait_time_ms >= 1
ORDER BY Wait_Time_Seconds DESC



