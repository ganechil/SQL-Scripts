SELECT * FROM msdb..sysmail_event_log order by log_id DESC


SELECT * FROM dbo.sysmail_mailitems


SELECT * FROM dbo.sysmail_sentitems


USE msdb
SELECT sent_status, *
FROM sysmail_allitems


SELECT is_broker_enabled FROM sys.databases WHERE name = 'msdb';


EXECUTE msdb.dbo.sysmail_help_status_sp