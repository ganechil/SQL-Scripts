--Run this on the restored server/databases--

with app as (SELECT 
bs.server_name as 'SourceDBServer', 
@@servername AS DestinationDBServer,
--rs.user_name as 'LoginId',
bs.database_name as 'SourceDB',
rs.destination_database_name as 'RestoredDB',
CASE bs.type
WHEN 'D' THEN 'FullyLoaded' 
WHEN 'L' THEN 'Log' 
WHEN 'I' THEN 'Differential'
Else 'Other'
END AS RestoredType, 
--[bs].recovery_model, 
bs.backup_finish_date as 'BackupFinishDate_Source',
rs.restore_date as 'RestoreStartedOn_Destin',
--first_lsn,
--last_lsn, 
--checkpoint_lsn,
--database_backup_lsn,
--differential_base_lsn,
bmf.physical_device_name as 'BackupFile_Used4Restore',
--[bs].[backup_set_uuid],
--[bs].[backup_size] /1024 /1024 /1024 as backup_size,
CONVERT(DECIMAL(10,2),compressed_backup_size/1024.0/1024.0/1024.0) AS PhysicalCompressedInGB,
--CAST(DATEDIFF(second, backup_start_date,backup_finish_date) AS VARCHAR(4)) + ' ' + 'Seconds' BackupTimeTaken,
    CAST((DATEDIFF(s, bs.backup_start_date, bs.backup_finish_date) / 3600) AS VARCHAR) + ' hours, ' 
    + CAST((DATEDIFF(s, bs.backup_start_date, bs.backup_finish_date) / 60) % 60 AS VARCHAR) + ' minutes, '
    + CAST((DATEDIFF(s, bs.backup_start_date, bs.backup_finish_date) % 60) AS VARCHAR) + ' seconds' AS [BackupDuration],
rf.destination_phys_name AS [Restored Files]
--CAST(DATEDIFF(MINUTE, backup_start_date,backup_finish_date) AS VARCHAR(4)) + ' ' + 'Minutes' BackupTimeTaken,
--[bs].[backup_start_date]
--[bs].[checkpoint_lsn],
--[bs].[machine_name] as RestoredFrom, 
--[bmf].[media_set_id],
--bs.*
,ROW_NUMBER() over (partition by bs.database_name order by rs.restore_date desc ) 'r' 
FROM msdb..restorehistory rs
INNER JOIN msdb..backupset bs ON [rs].[backup_set_id] = [bs].[backup_set_id]
INNER JOIN msdb.dbo.restorefile rf ON rs.restore_history_id = rf.restore_history_id
INNER JOIN msdb..backupmediafamily bmf ON [bs].[media_set_id] = [bmf].[media_set_id] 
and convert(smalldatetime,restore_date,103) > '2024-01-01' 
--Where [bmf].[physical_device_name] like 'vnbu0%'
--Where [bs].[database_name] in ('%BRNET_' )
and bs.type  = 'd'
) 
select * from app where r<4
ORDER BY RestoreStartedOn_Destin DESC








--https://dba.stackexchange.com/questions/101291/history-of-database-restore-completion-times
--https://sqlnotesfromtheunderground.wordpress.com/2014/10/02/restore-duration-time-for-database/
/*
Query - Restore Duration Time for Database 
Uses MSDB..RestoreHistory table for Start time and ErrorLog for Finish Time
*/ 
-- Name of the Database you want restore name of:
DECLARE @databaseName VARCHAR(50)
SET @databaseName = 'NalcoConfigurator'
 
 
 
DECLARE @TSQL NVARCHAR(2000)
DECLARE @lC INT
DECLARE @ErrorLogStart DATETIME
DECLARE @CurrentLogStart DATETIME
SET @CurrentLogStart = GETDATE()
  
-- Error Message for ErrorLog search
DECLARE @errorLogResult VARCHAR(4000)
SET @errorLogResult = 'Restore is complete on database ''' + @databaseName
    + '''.  The database is now available.'
  
-- Results Table 
CREATE TABLE #Restore
    (
      [database] VARCHAR(50) ,
      StartTime DATETIME ,
      EndTime DATETIME
    )
  
INSERT  INTO #Restore
        ( [database] )
VALUES  ( @databaseName )
  
-- Get start time by looking msdb..restorehistory and selecting the first record with your db
UPDATE  #Restore
SET     StartTime = ( SELECT TOP ( 1 )
                                restore_date
                      FROM      msdb.dbo.restorehistory
                      WHERE     destination_database_name = @databaseName
                    )
WHERE   [database] IS NOT NULL
  
-- Get end time by loading the errorlog into a temp table and filtering to find the restore command @errorLog Result 
 
 
-- SET ErrorLogStart Date to Restore Start Time
SET @ErrorLogStart = ( SELECT   StartTime
                       FROM     #Restore
                       WHERE    [database] = @databaseName
                     )
 
CREATE TABLE #TempLog
    (
      LogDate DATETIME ,
      ProcessInfo NVARCHAR(50) ,
      [Text] NVARCHAR(MAX)
    )
 
CREATE TABLE #logF
    (
      ArchiveNumber INT ,
      LogDate DATETIME ,
      LogSize INT
    )
 
INSERT  INTO #logF
        EXEC sp_enumerrorlogs
SELECT  @lC = MIN(ArchiveNumber)
FROM    #logF
 
WHILE @lC IS NOT NULL
    BEGIN
        IF EXISTS ( SELECT  1
                    FROM    #TempLog )
            BEGIN
                SET @CurrentLogStart = ( SELECT TOP ( 1 )
                                                LogDate
                                         FROM   #TempLog
                                         ORDER BY LogDate
                                       )
            END
        IF ( @CurrentLogStart > @ErrorLogStart )
            BEGIN
                INSERT  INTO #TempLog
                        EXEC sp_readerrorlog @lC
                SELECT  @lC = MIN(ArchiveNumber)
                FROM    #logF
                WHERE   ArchiveNumber > @lC
            END
        ELSE
            BEGIN
                BREAK
            END
    END
 
 
      
UPDATE  #Restore
SET     EndTime = ( SELECT TOP ( 1 )
                            LogDate
                    FROM    #TempLog
                    WHERE   ProcessInfo = 'Backup'
                            AND [Text] LIKE @errorLogResult
                  )
WHERE   [database] IS NOT NULL
  
  
  
-- Return the Restore information
SELECT  [database] ,
        StartTime ,
        EndTime ,
        DATEDIFF(SECOND, StartTime, EndTime) AS 'Restore Duration in Seconds',
		DATEDIFF(MINUTE, StartTime, EndTime) AS 'Restore Duration in Minutes' ,
		DATEDIFF(HOUR, StartTime, EndTime) AS 'Restore Duration in Minutes' 
FROM    #Restore
  
-- Clean up
DROP TABLE #Restore
DROP TABLE #TempLog

--All DBs restoration dates.
--https://dba.stackexchange.com/questions/10364/sql-server-error-log-monitoring#:~:text=You%20should%20use%20the%20system,Server%20log%20files%20using%20TSQL.
--Took some inspiration and scripts from here:
--  Read a single Error Log File: http://www.sqlservercentral.com/blogs/steve_jones/2011/07/28/when-did-that-restore-finish_3F00_/
--  List all Error Log Files:     https://ask.sqlservercentral.com/questions/99484/number-of-error-log-files.html
--  Combine all Error Log Files:  https://blogs.msdn.microsoft.com/askjay/2011/10/10/searching-through-the-sql-server-errorlogs/
--  xp_readererrorlog Parameters: https://sqlserver-help.com/2014/12/10/sql-internals-useful-parameters-for-xp_readerrorlog/
--Works!  Combined Sources found online to append results from all Log Files: - 01/06/2017 - MCR.
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
DECLARE @LogType Int = 1--"1" = ERRORLOG, "2" = SqlAgent.
DECLARE @PrimaryFilter   nVarChar(4000) = 'Restore is complete on database'--NULL--'Database backed up.'  --This is searching ONLY the Message field. - 01/06/2017 - MCR.
DECLARE @SecondaryFilter nVarChar(4000) = NULL  --WARNING: This 2nd Filter is ignored if the 1st Filter is null-or-empty.
DECLARE @StartDate DateTime = NULL--'01/01/1900'--'01/06/2017 00:40'--  --A NULL here will skip BOTH @StartDate and @EndDate Filters.
DECLARE @EndDate   DateTime = NULL--GETDATE()   --'01/06/2017 04:00'--  --A NULL here will skip BOTH @StartDate and @EndDate Filters.
DECLARE @FileList Table
(
    subdirectory nVarChar(450) NOT NULL,--I do not know wha the max length is.
    depth Int NOT NULL,
    [file] Int NOT NULL
)
DECLARE @ErrorLogFileName nVarChar(4000) = CAST(SERVERPROPERTY(N'errorlogfilename') as nVarChar(4000))
DECLARE @ErrorLogPath nVarChar(4000) = SUBSTRING(@ErrorLogFileName, 1, LEN(@ErrorLogFileName) - CHARINDEX(N'\', REVERSE(@ErrorLogFileName))) + N'\'
INSERT INTO @FileList
EXEC xp_dirtree @ErrorLogPath, 0, 1;
DECLARE @NumErrorLogs Int = (SELECT COUNT(*) FROM @FileList as F WHERE F.subdirectory LIKE (CASE @LogType WHEN 1 THEN 'ERRORLOG%' WHEN 2 THEN 'SQLAGENT%' ELSE NULL END) )
DECLARE @ArchiveID Int = 0
DECLARE @ErrorLog Table
(
    LogDate DateTime,
    Process nVarChar(25),  --Longest I've seen is 8.
    Message nVarChar(1000),--Longest I've seen is 578.
    ArchiveID Int NULL
)
WHILE(@ArchiveID < @NumErrorLogs)
BEGIN
    INSERT INTO @ErrorLog(LogDate, Process, Message)
    EXEC xp_readerrorlog @ArchiveID, @LogType, @PrimaryFilter, @SecondaryFilter, @StartDate, @EndDate, 'DESC'
    UPDATE @ErrorLog SET ArchiveID = @ArchiveID WHERE ArchiveID IS NULL
    SET @ArchiveID = @ArchiveID + 1
END
SELECT --SUBSTRING(L.Message, 34, (CHARINDEX ('''', L.Message, 34)-34))[DatabaseName],
       DATENAME(WEEKDAY, L.LogDate)[DayOfWeek], L.*
  FROM @ErrorLog as L
  --Add More advanced Filtering in the Where-Clause here.
 ORDER BY L.LogDate DESC
SET TRANSACTION ISOLATION LEVEL READ COMMITTED

DROP TABLE #logF










--https://www.mssqltips.com/sqlservertip/1601/script-to-retrieve-sql-server-database-backup-history-and-no-backups/
with Backups as (SELECT 
msdb.dbo.backupset.machine_name as SourceServer,
msdb.dbo.backupset.database_name as 'BackupDB', 
--msdb.dbo.backupset.recovery_model,
CASE msdb..backupset.type 
WHEN 'D' THEN 'FullyLoaded' 
WHEN 'L' THEN 'Log' 
WHEN 'I' THEN 'Differential'
Else 'Other'
END AS BackupType,
msdb.dbo.backupset.backup_finish_date as [BackupFinishDate_Source], 
--first_lsn,
--last_lsn, 
--checkpoint_lsn,
--database_backup_lsn,
--differential_base_lsn,
msdb.dbo.backupmediafamily.physical_device_name, 
--msdb.dbo.backupset.backup_start_date,
CONVERT(DECIMAL(10,2),compressed_backup_size/1024.0/1024.0/1024.0) AS CompressedGB,
--physical_block_size as Physical_size, 
--CAST(CAST(msdb.dbo.backupset.backup_size / 1000000 AS INT) AS VARCHAR(14)) + ' ' + 'MB' AS bkSize,
--CAST(DATEDIFF(MINUTE, backup_start_date,backup_finish_date) AS VARCHAR(4)) + ' ' + 'Minutes' TimeTaken,
--CAST(DATEDIFF(Minute, backup_start_date,backup_finish_date) AS VARCHAR(4)) + ' ' + 'Minutes' BackupTimeTaken,
    CAST((DATEDIFF(s, msdb.dbo.backupset.backup_start_date, msdb.dbo.backupset.backup_finish_date) / 3600) AS VARCHAR) + ' hours, ' 
    + CAST((DATEDIFF(s, msdb.dbo.backupset.backup_start_date, msdb.dbo.backupset.backup_finish_date) / 60) % 60 AS VARCHAR) + ' minutes, '
    + CAST((DATEDIFF(s, msdb.dbo.backupset.backup_start_date, msdb.dbo.backupset.backup_finish_date) % 60) AS VARCHAR) + ' seconds' AS [BackupDuration],
msdb.dbo.backupset.description,
msdb.dbo.backupset.user_name As BackupTakenBy,
CONVERT(CHAR(100), SERVERPROPERTY('Servername')) AS Server, 
msdb.dbo.backupmediafamily.logical_device_name, 
msdb.dbo.backupset.name AS backupset_name
,ROW_NUMBER() over (partition by msdb.dbo.backupset.database_name order by msdb.dbo.backupset.backup_finish_date desc ) 'r' 
FROM msdb.dbo.backupmediafamily 
INNER JOIN msdb.dbo.backupset ON msdb.dbo.backupmediafamily.media_set_id = msdb.dbo.backupset.media_set_id 
WHERE (CONVERT(datetime, msdb.dbo.backupset.backup_start_date, 102) >= GETDATE() -120) 
--And msdb.dbo.backupmediafamily.physical_device_name not like 'VNBU%'
--AND msdb.dbo.backupset.database_name   in ('CRM_FULLERTON')
AND msdb.dbo.backupset.database_name  not  in ('Master', 'MSDB', 'Model', 'TempDB')
--and (CONVERT(DECIMAL(10,2),compressed_backup_size/1024.0/1024.0/1024.0)) > '1.0'
and msdb..backupset.type   in ('l') 
--ORDER BY 
----msdb.dbo.backupset.database_name, --msdb.dbo.backupset.database_name
----backup_type,
--msdb.dbo.backupset.backup_finish_date desc
)
select * from backups where r<2
order by BackupDB, BackupFinishDate_Source desc
--order by msdb.dbo.backupset.backup_finish_date desc 