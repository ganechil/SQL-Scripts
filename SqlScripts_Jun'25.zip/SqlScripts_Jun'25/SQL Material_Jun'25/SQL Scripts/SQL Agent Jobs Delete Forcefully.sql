--http://sql-articles.com/articles/troubleshooting/sql-server-maintenance-job-deletion-error/

--Below script first deletes any maintainence plan_logs & maintenance subplans related to the given job name and
--then it deletes the job
USE MSDB
DECLARE @jobname VARCHAR(100)
SELECT @jobname='hj.Subplan_1'
DELETE FROM msdb.dbo.sysmaintplan_log
WHERE plan_id IN(
SELECT plan_id FROM msdb..sysmaintplan_subplans
WHERE job_id IN(
SELECT job_id FROM sysjobs WHERE name =@jobname))
DELETE FROM sysmaintplan_subplans
WHERE job_id IN(
SELECT job_id FROM sysjobs WHERE name =@jobname)

--once maintenance_subplans & maintenance plan_logs are delete then by entering the job name it deletes the sql agent job
USE msdb;
GO
EXEC sp_delete_job
@job_name = N'hj.Subplan_1' ;


--Clears Ony SQL Server Agent Jobs History
use msdb
go
sp_cycle_agent_errorlog


