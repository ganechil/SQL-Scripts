--DBA###############################Checklist##################################
USE master
GO

DECLARE  @TargetDatabase sysname ,
  @Level varchar(10) ,
  @UpdateUsage bit ,
  @Unit char(2)

SET @TargetDatabase = NULL
SET @Level = 'Database'
SET @UpdateUsage = 0
SET @Unit = 'MB'

/**************************************************************************************************
**
**  usage:  list db size AND path w/o SUMmary
**  test code: sp_SDS   --  default behavior
**             sp_SDS 'maAster'
**             sp_SDS NULL, NULL, 0
**             sp_SDS NULL, 'file', 1, 'GB'
**             sp_SDS 'Test_snapshot', 'Database', 1
**             sp_SDS 'Test', 'File', 0, 'kb'
**             sp_SDS 'pfaids', 'Database', 0, 'gb'
**             sp_SDS 'tempdb', NULL, 1, 'kb'
**   
**************************************************************************************************/

SET NOCOUNT ON;

IF @TargetDatabase IS NOT NULL AND DB_ID(@TargetDatabase) IS NULL
  BEGIN
    RAISERROR(15010, -1, -1, @TargetDatabase);
  END

IF OBJECT_ID('tempdb.dbo.##Tbl_CombinedInfo', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_CombinedInfo;
  
IF OBJECT_ID('tempdb.dbo.##Tbl_DbFileStats', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_DbFileStats;
  
IF OBJECT_ID('tempdb.dbo.##Tbl_ValidDbs', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_ValidDbs;
  
IF OBJECT_ID('tempdb.dbo.##Tbl_Logs', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_Logs;
  
CREATE TABLE dbo.##Tbl_CombinedInfo (
  DatabaseName sysname NULL, 
  [type] VARCHAR(10) NULL, 
  LogicalName sysname NULL,
  T dec(10, 2) NULL,
  U dec(10, 2) NULL,
  [U(%)] dec(5, 2) NULL,
  F dec(10, 2) NULL,
  [F(%)] dec(5, 2) NULL,
  PhysicalName sysname NULL );

CREATE TABLE dbo.##Tbl_DbFileStats (
  Id int identity, 
  DatabaseName sysname NULL, 
  FileId int NULL, 
  FileGroup int NULL, 
  TotalExtents bigint NULL, 
  UsedExtents bigint NULL, 
  Name sysname NULL, 
  FileName varchar(255) NULL );
  
CREATE TABLE dbo.##Tbl_ValidDbs (
  Id int identity, 
  Dbname sysname NULL );
  
CREATE TABLE dbo.##Tbl_Logs (
  DatabaseName sysname NULL, 
  LogSize dec (10, 2) NULL, 
  LogSpaceUsedPercent dec (5, 2) NULL,
  Status int NULL );

DECLARE @Ver varchar(10), 
        @DatabaseName sysname, 
        @Ident_last int, 
        @String varchar(2000),
        @BaseString varchar(2000);
        
SELECT @DatabaseName = '', 
       @Ident_last = 0, 
       @String = '', 
       @Ver = CASE WHEN @@VERSION LIKE '%9.0%' THEN 'SQL 2005' 
                   WHEN @@VERSION LIKE '%8.0%' THEN 'SQL 2000' 
                   WHEN @@VERSION LIKE '%10.0%' THEN 'SQL 2008' 
				WHEN @@VERSION LIKE '%10_%' THEN 'SQL 2008R2' 
				WHEN @@VERSION LIKE '%11_%' THEN 'SQL 2012' 
              END;
              
SELECT @BaseString = 
' SELECT DB_NAME(), ' + 
CASE WHEN @Ver = 'SQL 2000' THEN 'CASE WHEN status & 0x40 = 0x40 THEN ''Log''  ELSE ''Data'' END' 
  ELSE ' CASE type WHEN 0 THEN ''Data'' WHEN 1 THEN ''Log'' WHEN 4 THEN ''Full-text'' ELSE ''reserved'' END' END + 
', name, ' + 
CASE WHEN @Ver = 'SQL 2000' THEN 'filename' ELSE 'physical_name' END + 
', size*8.0/1024.0 FROM ' + 
CASE WHEN @Ver = 'SQL 2000' THEN 'sysfiles' ELSE 'sys.database_files' END + 
' WHERE '
+ CASE WHEN @Ver = 'SQL 2000' THEN ' HAS_DBACCESS(DB_NAME()) = 1' ELSE 'state_desc = ''ONLINE''' END + '';

SELECT @String = 'INSERT INTO dbo.##Tbl_ValidDbs SELECT name FROM ' + 
                 CASE WHEN @Ver = 'SQL 2000' THEN 'master.dbo.sysdatabases' 
                      WHEN @Ver IN ('SQL 2005', 'SQL 2008', 'SQL 2008R2','SQL 2012') THEN 'master.sys.databases' 
                 END + ' WHERE HAS_DBACCESS(name) = 1 ORDER BY name ASC';
EXEC (@String);

INSERT INTO dbo.##Tbl_Logs EXEC ('DBCC SQLPERF (LOGSPACE) WITH NO_INFOMSGS');

--  For data part
IF @TargetDatabase IS NOT NULL
  BEGIN
    SELECT @DatabaseName = @TargetDatabase;
    IF @UpdateUsage <> 0 AND DATABASEPROPERTYEX (@DatabaseName,'Status') = 'ONLINE' 
          AND DATABASEPROPERTYEX (@DatabaseName, 'Updateability') <> 'READ_ONLY'
      BEGIN
        SELECT @String = 'USE [' + @DatabaseName + '] DBCC UPDATEUSAGE (0)';
        PRINT '*** ' + @String + ' *** ';
        EXEC (@String);
        PRINT '';
      END
      
    SELECT @String = 'INSERT INTO dbo.##Tbl_CombinedInfo (DatabaseName, type, LogicalName, PhysicalName, T) ' + @BaseString; 

    INSERT INTO dbo.##Tbl_DbFileStats (FileId, FileGroup, TotalExtents, UsedExtents, Name, FileName)
          EXEC ('USE [' + @DatabaseName + '] DBCC SHOWFILESTATS WITH NO_INFOMSGS');
    EXEC ('USE [' + @DatabaseName + '] ' + @String);
        
    UPDATE dbo.##Tbl_DbFileStats SET DatabaseName = @DatabaseName; 
  END
ELSE
  BEGIN
    WHILE 1 = 1
      BEGIN
        SELECT TOP 1 @DatabaseName = Dbname FROM dbo.##Tbl_ValidDbs WHERE Dbname > @DatabaseName ORDER BY Dbname ASC;
        IF @@ROWCOUNT = 0
          BREAK;
        IF @UpdateUsage <> 0 AND DATABASEPROPERTYEX (@DatabaseName, 'Status') = 'ONLINE' 
              AND DATABASEPROPERTYEX (@DatabaseName, 'Updateability') <> 'READ_ONLY'
          BEGIN
            SELECT @String = 'DBCC UPDATEUSAGE (''' + @DatabaseName + ''') ';
            PRINT '*** ' + @String + '*** ';
            EXEC (@String);
            PRINT '';
          END
    
        SELECT @Ident_last = ISNULL(MAX(Id), 0) FROM dbo.##Tbl_DbFileStats;

        SELECT @String = 'INSERT INTO dbo.##Tbl_CombinedInfo (DatabaseName, type, LogicalName, PhysicalName, T) ' + @BaseString; 

        EXEC ('USE [' + @DatabaseName + '] ' + @String);
      
        INSERT INTO dbo.##Tbl_DbFileStats (FileId, FileGroup, TotalExtents, UsedExtents, Name, FileName)
          EXEC ('USE [' + @DatabaseName + '] DBCC SHOWFILESTATS WITH NO_INFOMSGS');

        UPDATE dbo.##Tbl_DbFileStats SET DatabaseName = @DatabaseName WHERE Id BETWEEN @Ident_last + 1 AND @@IDENTITY;
      END
  END

--  set used size for data files, do not change total obtained from sys.database_files as it has for log files
UPDATE dbo.##Tbl_CombinedInfo 
SET U = s.UsedExtents*8*8/1024.0 
FROM dbo.##Tbl_CombinedInfo t JOIN dbo.##Tbl_DbFileStats s 
ON t.LogicalName = s.Name AND s.DatabaseName = t.DatabaseName;

--  set used size and % values for log files:
UPDATE dbo.##Tbl_CombinedInfo 
SET [U(%)] = LogSpaceUsedPercent, 
U = T * LogSpaceUsedPercent/100.0
FROM dbo.##Tbl_CombinedInfo t JOIN dbo.##Tbl_Logs l 
ON l.DatabaseName = t.DatabaseName 
WHERE t.type = 'Log';

UPDATE dbo.##Tbl_CombinedInfo SET F = T - U, [U(%)] = U*100.0/T;

UPDATE dbo.##Tbl_CombinedInfo SET [F(%)] = F*100.0/T;

IF UPPER(ISNULL(@Level, 'DATABASE')) = 'FILE'
  BEGIN
    IF @Unit = 'KB'
      UPDATE dbo.##Tbl_CombinedInfo
      SET T = T * 1024, U = U * 1024, F = F * 1024;
      
    IF @Unit = 'GB'
      UPDATE dbo.##Tbl_CombinedInfo
      SET T = T / 1024, U = U / 1024, F = F / 1024;
      
    SELECT DatabaseName AS 'Database',
      type AS 'Type',
      LogicalName,
      T AS 'Total',
      U AS 'Used',
      [U(%)] AS 'Used (%)',
      F AS 'Free',
      [F(%)] AS 'Free (%)',
      PhysicalName
      FROM dbo.##Tbl_CombinedInfo 
      WHERE DatabaseName LIKE ISNULL(@TargetDatabase, '%') 
      ORDER BY DatabaseName ASC, type ASC;

    SELECT CASE WHEN @Unit = 'GB' THEN 'GB' WHEN @Unit = 'KB' THEN 'KB' ELSE 'MB' END AS 'SUM',
        SUM (T) AS 'TOTAL', SUM (U) AS 'USED', SUM (F) AS 'FREE' FROM dbo.##Tbl_CombinedInfo;
  END

IF UPPER(ISNULL(@Level, 'DATABASE')) = 'DATABASE'
  BEGIN
    DECLARE @Tbl_Final TABLE (
      DatabaseName sysname NULL,
      TOTAL dec (10, 2),
      [=] char(1),
      used dec (10, 2),
      [used (%)] dec (5, 2),
      [+] char(1),
      free dec (10, 2),
      [free (%)] dec (5, 2),
      [==] char(2),
      Data dec (10, 2),
      Data_Used dec (10, 2),
      [Data_Used (%)] dec (5, 2),
      Data_Free dec (10, 2),
      [Data_Free (%)] dec (5, 2),
      [++] char(2),
      Log dec (10, 2),
      Log_Used dec (10, 2),
      [Log_Used (%)] dec (5, 2),
      Log_Free dec (10, 2),
      [Log_Free (%)] dec (5, 2) );

    INSERT INTO @Tbl_Final
      SELECT x.DatabaseName, 
           x.Data + y.Log AS 'TOTAL', 
           '=' AS '=', 
           x.Data_Used + y.Log_Used AS 'U',
           (x.Data_Used + y.Log_Used)*100.0 / (x.Data + y.Log)  AS 'U(%)',
           '+' AS '+',
           x.Data_Free + y.Log_Free AS 'F',
           (x.Data_Free + y.Log_Free)*100.0 / (x.Data + y.Log)  AS 'F(%)',
           '==' AS '==',
           x.Data, 
           x.Data_Used, 
           x.Data_Used*100/x.Data AS 'D_U(%)',
           x.Data_Free, 
           x.Data_Free*100/x.Data AS 'D_F(%)',
           '++' AS '++', 
           y.Log, 
           y.Log_Used, 
           y.Log_Used*100/y.Log AS 'L_U(%)',
           y.Log_Free, 
           y.Log_Free*100/y.Log AS 'L_F(%)'
      FROM 
      ( SELECT d.DatabaseName, 
               SUM(d.T) AS 'Data', 
               SUM(d.U) AS 'Data_Used', 
               SUM(d.F) AS 'Data_Free' 
          FROM dbo.##Tbl_CombinedInfo d WHERE d.type = 'Data' GROUP BY d.DatabaseName ) AS x
      JOIN 
      ( SELECT l.DatabaseName, 
               SUM(l.T) AS 'Log', 
               SUM(l.U) AS 'Log_Used', 
               SUM(l.F) AS 'Log_Free' 
          FROM dbo.##Tbl_CombinedInfo l WHERE l.type = 'Log' GROUP BY l.DatabaseName ) AS y
      ON x.DatabaseName = y.DatabaseName;
    
    IF @Unit = 'KB'
      UPDATE @Tbl_Final SET TOTAL = TOTAL * 1024,
      used = used * 1024,
      free = free * 1024,
      Data = Data * 1024,
      Data_Used = Data_Used * 1024,
      Data_Free = Data_Free * 1024,
      Log = Log * 1024,
      Log_Used = Log_Used * 1024,
      Log_Free = Log_Free * 1024;
      
     IF @Unit = 'GB'
      UPDATE @Tbl_Final SET TOTAL = TOTAL / 1024,
      used = used / 1024,
      free = free / 1024,
      Data = Data / 1024,
      Data_Used = Data_Used / 1024,
      Data_Free = Data_Free / 1024,
      Log = Log / 1024,
      Log_Used = Log_Used / 1024,
      Log_Free = Log_Free / 1024;
      
      DECLARE @GrantTotal dec(11, 2);
      SELECT @GrantTotal = SUM(TOTAL) FROM @Tbl_Final;
/*
      SELECT 
      CONVERT(dec(10, 2), TOTAL*100.0/@GrantTotal) AS 'WEIGHT (%)', 
      DatabaseName AS 'DATABASE',
      CONVERT(VARCHAR(12), used) + '  (' + CONVERT(VARCHAR(12), [used (%)]) + ' %)' AS 'USED  (%)',
      [+],
      CONVERT(VARCHAR(12), free) + '  (' + CONVERT(VARCHAR(12), [free (%)]) + ' %)' AS 'FREE  (%)',
      [=],
      TOTAL, 
      [=],
      CONVERT(VARCHAR(12), Data) + '  (' + CONVERT(VARCHAR(12), Data_Used) + ',  ' + 
      CONVERT(VARCHAR(12), [Data_Used (%)]) + '%)' AS 'DATA  (used,  %)',
      [+],
      CONVERT(VARCHAR(12), Log) + '  (' + CONVERT(VARCHAR(12), Log_Used) + ',  ' + 
      CONVERT(VARCHAR(12), [Log_Used (%)]) + '%)' AS 'LOG  (used,  %)'
        FROM @Tbl_Final 
        WHERE DatabaseName LIKE ISNULL(@TargetDatabase, '%')
        ORDER BY DatabaseName ASC;
*/        

      SELECT 
		D.DatabaseName AS 'DATABASE',
		 IsNull(C.NEW_type, 'No') As 'Backup Status',
		D.TOTAL,       
		D.Data, 
		D.[Log],
		D.[Data_Used (%)],
		D.[Log_Used (%)]
		
        FROM @Tbl_Final D LEFT OUTER JOIN

(
SELECT DISTINCT A.database_name,

CASE Isnull(A.BackupType,0) + IsNull(B.BackupType , 0)
when 1 Then 'Full'
when 2 Then 'Diff'
when 4 Then 'Log'
when 8 Then 'File or filegroup'
when 16 Then 'Differential file'
when 32 Then 'Partial'
when 64 Then 'Differential partial'
when 3 Then 'Full & Diff'
when 7 Then 'Full & Diff & Log'
when 5 Then 'Full & Log'
when 6 Then 'Diff & Log'
when 0 Then 'No'
Else 'Unknown Number : ' + Convert(nvarchar(20), Isnull(A.BackupType,0) + IsNull(B.BackupType , 0))

END As New_Type

FROM (select database_name, 
Max(backup_start_date) as BkpDate, 
case Type when 'D' Then 1
when 'I' Then 2
when 'L' Then 4
when 'F' Then 8
when 'G' Then 16
when 'P' Then 32
when 'Q' Then 64
Else 0 END BackupType
from msdb..backupset 
where convert(varchar(50), backup_start_date, 101) in (convert(varchar(50), getdate(), 101), 
convert(varchar(50), Dateadd(d, -1, getdate()), 101))
Group by database_name, type) A

LEFT OUTER JOIN 

(select database_name, 
Max(backup_start_date) as BkpDate, 
case Type when 'D' Then 1
when 'I' Then 2
when 'L' Then 4
when 'F' Then 8
when 'G' Then 16
when 'P' Then 32
when 'Q' Then 64
Else 0 END BackupType
from msdb..backupset 
where convert(varchar(50), backup_start_date, 101) in (convert(varchar(50), getdate(), 101), 
convert(varchar(50), Dateadd(d, -1, getdate()), 101))
Group by database_name, type) B

ON A.database_name = B.database_name
AND A.BackupType  <> B.BackupType 
) C ON D.databasename = C.database_name

        WHERE D.DatabaseName LIKE ISNULL(@TargetDatabase, '%')
        ORDER BY [DATABASE] ASC;

/*    IF @TargetDatabase IS NULL
      SELECT CASE WHEN @Unit = 'GB' THEN 'GB' WHEN @Unit = 'KB' THEN 'KB' ELSE 'MB' END AS 'SUM', 
      SUM (used) AS 'USED', 
      SUM (free) AS 'FREE', 
      SUM (TOTAL) AS 'TOTAL', 
      SUM (Data) AS 'DATA', 
      SUM (Log) AS 'LOG' 
      FROM @Tbl_Final;
*/

IF OBJECT_ID('tempdb.dbo.##Tbl_CombinedInfo', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_CombinedInfo;
  
IF OBJECT_ID('tempdb.dbo.##Tbl_DbFileStats', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_DbFileStats;
  
IF OBJECT_ID('tempdb.dbo.##Tbl_ValidDbs', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_ValidDbs;
  
IF OBJECT_ID('tempdb.dbo.##Tbl_Logs', 'U') IS NOT NULL
  DROP TABLE dbo.##Tbl_Logs;

  END

GO


--DBA--##############################server reboot--##################################
SELECT [Name] , CrDate as DateServerRebooted from
master.dbo.sysdatabases
WHERE dbid = 2
--from sys.sysdatabases --above 2000


--DBA-##################################Server Description--##################################
declare @version varchar(4)
select @version = substring(@@version,22,4)

IF CONVERT(SMALLINT, @version) >= 2012
EXEC ('SELECT	
		SERVERPROPERTY(''ComputerNamePhysicalNetBios'')  as [Is_Current_Owner],
		SERVERPROPERTY(''InstanceName'') AS [Instance Name],
		cASE WHEN @@ServiceName = 
			Right (@@Servername,len(@@ServiceName)) then @@Servername 
			Else @@servername +'' \ '' + @@Servicename
			End as ''@@ServerName \ ServiceName'', 
		CASE LEFT(CONVERT(VARCHAR, SERVERPROPERTY(''ProductVersion'')),4) 
			WHEN ''11.0'' THEN ''SQL Server 2012''
			WHEN ''12.0'' THEN ''SQL Server 2014''
			WHEN ''13.0'' THEN ''SQL Server 2016''
			WHEN ''14.0'' THEN ''SQL Server 2017''
			WHEN ''15.0'' THEN ''SQL Server 2019''
			ELSE ''Newer than SQL Server 2017''
		END AS [Version Build],
		SERVERPROPERTY (''Edition'') AS [Edition],
		SERVERPROPERTY(''ProductLevel'') AS [Service Pack],
		SERVERPROPERTY(''Productversion'') AS [ProductVersion],		
		CASE SERVERPROPERTY(''IsClustered'') 
			WHEN 0 THEN ''False''
			WHEN 1 THEN ''True''
		END AS [Is Clustered?],
--SERVERPROPERTY(''MachineName'')  as [MachineName],
--SERVERPROPERTY(''Collation'') AS [ SQL Collation], 
		CONNECTIONPROPERTY(''net_transport'') AS net_transport,
		CONNECTIONPROPERTY(''local_tcp_port'') AS local_tcp_port,    
		CONNECTIONPROPERTY(''local_net_address'') AS local_net_address,
		[cpu_count] AS [CPUs],
		--[physical_memory_kb]/1024 AS [RAM (MB)]
		Convert(numeric(18,2), Convert(numeric(18,2), physical_memory_kb)/Convert(numeric(18,2), 1048576)) As RAM_GB,
		sqlserver_start_time,
		CASE SERVERPROPERTY(''IsIntegratedSecurityOnly'') 
			WHEN 0 THEN ''SQL Server and Windows Authentication mode''
			WHEN 1 THEN ''Windows Authentication mode''
		END AS [Server Authentication]
FROM	
[sys].[dm_os_sys_info]')


ELSE IF CONVERT(SMALLINT, @version) >= 2005
EXEC ('SELECT	
		SERVERPROPERTY(''ComputerNamePhysicalNetBios'')  as [Is_Current_Owner],
		SERVERPROPERTY(''InstanceName'') AS [Instance Name],
		cASE WHEN @@ServiceName = 
			Right (@@Servername,len(@@ServiceName)) then @@Servername 
			Else @@servername +'' \ '' + @@Servicename
			End as ''@@ServerName \ ServiceName'', 
		CASE LEFT(CONVERT(VARCHAR, SERVERPROPERTY(''ProductVersion'')),4) 
			WHEN ''9.00'' THEN ''SQL Server 2005''
			WHEN ''10.0'' THEN ''SQL Server 2008''
			WHEN ''10.5'' THEN ''SQL Server 2008 R2''
		END AS [Version Build],
		SERVERPROPERTY (''Edition'') AS [Edition],
		SERVERPROPERTY(''ProductLevel'') AS [Service Pack],
		SERVERPROPERTY(''Productversion'') AS [ProductVersion],		
		CASE SERVERPROPERTY(''IsClustered'') 
			WHEN 0 THEN ''False''
			WHEN 1 THEN ''True''
		END AS [Is Clustered?],
		--SERVERPROPERTY(''Collation'') AS [ SQL Collation],
		CONNECTIONPROPERTY(''net_transport'') AS net_transport,
		CONNECTIONPROPERTY(''local_tcp_port'') AS local_tcp_port,    
		CONNECTIONPROPERTY(''local_net_address'') AS local_net_address,
		[cpu_count] AS [CPUs],
		--[physical_memory_in_bytes]/1048576 AS [RAM (MB)]
		Convert(numeric(18,2), Convert(numeric(18,2), physical_memory_in_bytes)/Convert(numeric(18,2), 1073741824)) As RAM_GB,
		sqlserver_start_time,
		CASE SERVERPROPERTY(''IsIntegratedSecurityOnly'') 
			WHEN 0 THEN ''SQL Server and Windows Authentication mode''
			WHEN 1 THEN ''Windows Authentication mode''
		END AS [Server Authentication]
FROM	
[sys].[dm_os_sys_info]')
ELSE 
SELECT 'This SQL Server instance is running SQL Server 2000 or lower! You will need alternative methods in getting the SQL Server instance level information.'




--DBA--##################################Disk space--##################################
create table #FreeSpace(
 Drive char(1), 
 MB_Free int)

insert into #FreeSpace exec master..xp_fixeddrives

SELECT *, Convert(numeric(18,2), Convert(numeric(18,2), MB_Free)/Convert(numeric(18,2), 1024)) As GB_FRee FROM #FreeSpace

IF OBJECT_ID('tempdb.dbo.#FreeSpace', 'U') IS NOT NULL
  DROP TABLE dbo.#FreeSpace;


--DBA--##########################check the status of all Databases--################################## 
SELECT Name,  
        
       DATABASEPROPERTYEX(name, 'Status') as 'Status'
FROM   master.dbo.sysdatabases 
ORDER BY 1


--DBA--##################################sql services status 28/04/2010 eela--##################################
  CREATE TABLE #ServicesStatus
( 
myid int identity(1,1),
serverName nvarchar(100) default @@serverName,
serviceName varchar(100),
Status varchar(50),
checkdatetime datetime default (getdate())
)
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'MSSQLServer'
update #ServicesStatus set serviceName = 'MSSQLServer' where myid = @@identity
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'SQLServerAGENT'
update #ServicesStatus set serviceName = 'SQLServerAGENT' where myid = @@identity
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'msdtc';
update #ServicesStatus set serviceName = 'msdtc' where myid = @@identity;
INSERT #ServicesStatus (Status)
EXEC xp_servicecontrol N'QUERYSTATE',N'sqlbrowser'
update #ServicesStatus set serviceName = 'sqlbrowser' where myid = @@identity
select * from #ServicesStatus 
--select char(13)
--select char(13)
drop table #ServicesStatus


--##################################backup verifications--##################################
SELECT database_name,
Type = ( 
            CASE type
            when 'D' then 'FULL DB BACKUP'
            when 'I' then 'DIFFERENTIAL Backup'
            when 'L' then 'Log Backup'
	    when 'F' then 'File/filegroup Backup' 
	    when 'G' then 'Differential file Backup' 
	    when 'P' then 'Partial Backup' 
	    when 'Q' then 'Differential partial Backup' 
            END
		),
physical_device_name, backup_finish_date, backup_size/1024/1024/1024 as backup_size_inGB,
CAST((CAST(DATEDIFF(s, bs.backup_start_date, bs.backup_finish_date) AS int))/3600 AS varchar) + ' hours, ' 
+ CAST((CAST(DATEDIFF(s, bs.backup_start_date, bs.backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '
+ CAST((CAST(DATEDIFF(s, bs.backup_start_date, bs.backup_finish_date) AS int))%60 AS varchar)+ ' seconds' AS [Total Time], 

compressed_backup_size/1024/1024/1024 as compressed_backup_inGB,
 backup_start_date, first_lsn,last_lsn, 
checkpoint_lsn, database_backup_lsn,differential_base_lsn,
recovery_model,
user_name
from msdb..backupset bs, msdb..backupmediafamily bm 
where bm.media_set_id=bs.media_set_id 
and backup_start_date > '2020-08-05 21:01:00.000' 
--and device_type=2
--and device_type=7
--and type='i'
and physical_device_name like 'V%'
-- group by database_name
order by backup_finish_date desc--, physical_device_name desc, database_name
