Create Table DiskTable01
(
ID Int Not Null Primary Key NonClustered,
Date_Value DateTime Null
)

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

--First Create Memory Optimized FileGroup & File--
Create Table MemoryTable01
(
ID Int Not Null Primary Key NonClustered Hash With (Bucket_Count=10000000),
Date_Value DateTime Null
)
With (Memory_Optimized=ON, Durability=Schema_And_Data);

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

Begin Tran
Declare @DiskID Int=1
While @DiskID<=500000
Begin
Insert Into DiskTable01 Values
(
@DiskID, GETDATE()
)
Set @DiskID=@DiskID+1
END

Commit Tran

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

Begin Tran
Declare @DiskID Int=1
While @DiskID<=500000
Begin
Insert Into [dbo].[MemoryTable01] Values
(
@DiskID, GETDATE()
)
Set @DiskID=@DiskID+1
END
Commit Tran

------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------

select * from sys.dm_os_loaded_modules

Select Name, Description
From sys.dm_os_loaded_modules
Where description = 'XTP Native DLL'

