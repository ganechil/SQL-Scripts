--https://www.sqlservercentral.com/blogs/database-mirroring-performance-counters

/*
      -----------------------------------------------------------------
      Get all user tables for all online, read-writable user databases
      -----------------------------------------------------------------
    
      For more SQL resources, check out SQLServer365.blogspot.co.uk
      -----------------------------------------------------------------
      You may alter this code for your own purposes.
      You may republish altered code as long as you give due credit.
      You must obtain prior permission before blogging this code.
      THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
    
      -----------------------------------------------------------------
*/
-- Set database context
USE msdb;
GO
-- Declare variables
DECLARE@EmailProfile VARCHAR(255)
DECLARE@EmailRecipient VARCHAR(255)
DECLARE@EmailSubject VARCHAR(255)
DECLARE @Threshold INT
-- Set variables
SET@EmailProfile = 'SQlServer365'
SET@EmailRecipient = 'Chris@SQLServer365.com'
SET@EmailSubject = 'Log Send Queue on ' + @@SERVERNAME + ' is greater than 1GB'
SET @Threshold = 1048576 -- 1GB
-- Check Log Send Queue KB
IF EXISTS ( SELECT  1
            FROM    sys.dm_os_performance_counters
            WHERE   [object_name] ='SQLSERVER:Database Mirroring'
                    ANDcounter_name = 'Log Send Queue KB'
                    ANDInstance_name != '_Total'
                    ANDCntr_Value > @Threshold )
    BEGIN
        DECLARE@tableHTML NVARCHAR(MAX); 
        SET@tableHTML = N'<style type="text/css">'
            + N'.h1 {font-family: Arial, verdana;font-size:16px;border:0px;background-color:white;} '
            + N'.h2 {font-family: Arial, verdana;font-size:12px;border:0px;background-color:white;} '
            + N'body {font-family: Arial, verdana;} '
            + N'table{font-size:12px; border-collapse:collapse;border:1px solid black; padding:3px;} '
            + N'td{background-color:#F1F1F1; border:1px solid black; padding:3px;} '
            + N'th{background-color:#99CCFF; border:1px solid black; padding:3px;}'
            + N'</style>' + N'<table border="1">' + N'<tr>'
            + N'<th>Database Name</th>' + N'<th>Last Backup Taken On</th>'
            + N'</tr>'
            + CAST(( SELECT td =Instance_Name ,
                            '' ,
                            td = cntr_value ,
                            ''
                     FROM    sys.dm_os_performance_counters
            WHERE   [object_name] ='SQLSERVER:Database Mirroring'
                    ANDcounter_name = 'Log Send Queue KB'
                    ANDInstance_name != '_Total'
                    ANDCntr_Value > @Threshold
                   FOR
                     XMLPATH('tr') ,
                         TYPE
                   )AS NVARCHAR(MAX)) + N'</table>'; 
           
            -- Email results 
        EXECmsdb.dbo.sp_send_dbmail @profile_name = @EmailProfile,
            @recipients = @EmailRecipient, @subject = @EmailSubject,
            @body =@tableHTML, @body_format = 'HTML'; 
    END
    GO
/*
      -----------------------------------------------------------------
      Get all user tables for all online, read-writable user databases
      -----------------------------------------------------------------
    
      For more SQL resources, check out SQLServer365.blogspot.com
      -----------------------------------------------------------------
      You may alter this code for your own purposes.
      You may republish altered code as long as you give due credit.
      You must obtain prior permission before blogging this code.
      THIS CODE AND INFORMATION ARE PROVIDED "AS IS"
    
      -----------------------------------------------------------------
*/
-- Set database context
USE msdb;
GO
-- Declare variables
DECLARE@EmailProfile VARCHAR(255)
DECLARE@EmailRecipient VARCHAR(255)
DECLARE@EmailSubject VARCHAR(255)
DECLARE @Threshold INT
-- Set variables
SET@EmailProfile = 'SQlServer365'
SET@EmailRecipient = 'Chris@SQLServer365.com'
SET@EmailSubject = 'Redo Queue on ' + @@SERVERNAME+ ' is greater than 1GB'
SET @Threshold = 1048576 -- 1GB
-- Check Log Send Queue KB
IF EXISTS ( SELECT  1
            FROM    sys.dm_os_performance_counters
            WHERE   [object_name] ='SQLSERVER:Database Mirroring'
                    ANDcounter_name = 'Redo Queue KB'
                    ANDInstance_name != '_Total'
                    ANDCntr_Value > @Threshold )
    BEGIN
        DECLARE@tableHTML NVARCHAR(MAX); 
        SET@tableHTML = N'<style type="text/css">'
            + N'.h1 {font-family: Arial, verdana;font-size:16px;border:0px;background-color:white;} '
            + N'.h2 {font-family: Arial, verdana;font-size:12px;border:0px;background-color:white;} '
            + N'body {font-family: Arial, verdana;} '
            + N'table{font-size:12px; border-collapse:collapse;border:1px solid black; padding:3px;} '
            + N'td{background-color:#F1F1F1; border:1px solid black; padding:3px;} '
            + N'th{background-color:#99CCFF; border:1px solid black; padding:3px;}'
            + N'</style>' + N'<table border="1">' + N'<tr>'
            + N'<th>Database Name</th>' + N'<th>Last Backup Taken On</th>'
            + N'</tr>'
            + CAST(( SELECT td =Instance_Name ,
                            '' ,
                            td = cntr_value ,
                            ''
                     FROM    sys.dm_os_performance_counters
            WHERE   [object_name] ='SQLSERVER:Database Mirroring'
                    ANDcounter_name = 'Redo Queue KB'
                    ANDInstance_name != '_Total'
                    ANDCntr_Value > @Threshold
                   FOR
                     XMLPATH('tr') ,
                         TYPE
                   )AS NVARCHAR(MAX)) + N'</table>'; 
           
            -- Email results 
        EXECmsdb.dbo.sp_send_dbmail @profile_name = @EmailProfile,
            @recipients = @EmailRecipient, @subject = @EmailSubject,
            @body =@tableHTML, @body_format = 'HTML'; 
    END
    GO
	
	
	
	
	
	
--https://www.sqlservercentral.com/blogs/script-to-monitor-sql-server-database-mirroring-status
CREATE TABLE #DBMRESULTS

(

DATABASE_NAME VARCHAR(255),

ROLE INT,

MIRRORING_STATE TINYINT,

WITNESS_STATUS TINYINT,

LOG_GENERAT_RATE INT,

UNSENT_LOG INT,

SENT_RATE INT,

UNRESTORED_LOG INT,

RECOVERY_RATE INT,

TRANSACTION_DELAY INT,

TRANSACTION_PER_SEC INT,

AVERAGE_DELAY INT,

TIME_RECORDED DATETIME,

TIME_BEHIND DATETIME,

LOCAL_TIME DATETIME

)

INSERT INTO #DBMRESULTS

EXEC MSDB.SYS.SP_DBMMONITORRESULTS 'ECOLAB_Operative', 0,1

SELECT DATABASE_NAME,

(CASE ROLE

WHEN 1 THEN 'PRINCIPAL'

WHEN 2 THEN 'MIRROR'

END) ROLE_OFDB_QUERY_FIRED,

(CASE MIRRORING_STATE

WHEN 0 THEN 'SUSPENDED'

WHEN 1 THEN 'DISCONNECTED'

WHEN 2 THEN 'SYNCHRONIZING'

WHEN 3 THEN 'PENDING FAILOVER'

WHEN 4 THEN 'SYNCHRONIZED'

END) MIRRORING_STATE,

(CASE WITNESS_STATUS

WHEN 0 THEN 'UNKNOWN'

WHEN 1 THEN 'CONNECTED'

WHEN 2 THEN 'DISCONNECTED'

END) WITNESS_STATUS,

LOG_GENERAT_RATE,

UNSENT_LOG,

SENT_RATE,

UNRESTORED_LOG,

RECOVERY_RATE,

TRANSACTION_DELAY,

TRANSACTION_PER_SEC,

AVERAGE_DELAY,

TIME_RECORDED,

TIME_BEHIND,

LOCAL_TIME

FROM #DBMRESULTS

DROP TABLE #DBMRESULTS	







--
SELECT 
   SERVERPROPERTY('ServerName') AS Principal,
   m.mirroring_partner_instance AS Mirror,
   DB_NAME(m.database_id) AS DatabaseName,
   SUM(f.size*8/1024) AS DatabaseSize,
   CASE m.mirroring_safety_level
      WHEN 1 THEN 'HIGH PERFORMANCE'
      WHEN 2 THEN 'HIGH SAFETY'
   END AS 'OperatingMode',
   RIGHT(m.mirroring_partner_name, CHARINDEX( ':', REVERSE(m.mirroring_partner_name) + ':' ) - 1 ) AS Port
FROM sys.database_mirroring m
JOIN sys.master_files f ON m.database_id = f.database_id
WHERE m.mirroring_role_desc = 'PRINCIPAL'
GROUP BY m.mirroring_partner_instance, m.database_id, m.mirroring_safety_level, m.mirroring_partner_name

SELECT
   SERVERPROPERTY('ServerName') AS Principal,
   m.mirroring_partner_instance AS DR, 
   DB_NAME(m.database_id) AS [Database],
   m.mirroring_state_desc AS [State], 
   CASE m.mirroring_safety_level_desc WHEN 'OFF' 
   THEN 'High Performance' ELSE 'High Safety' END AS [OperatingMode],
   CAST((pc.cntr_value)/1024/1024 AS DECIMAL(10,3)) AS unsentGB
FROM sys.database_mirroring m
JOIN sys.dm_os_performance_counters pc ON DB_NAME(m.database_id) = pc.instance_name
WHERE m.mirroring_state IS NOT NULL
  AND m.mirroring_state <> 4
  AND pc.object_name LIKE '%Database Mirroring%'
  AND pc.counter_name = 'Log Send Queue KB'

SELECT 
	@@SERVERNAME as Server_Name,
	DB_NAME(database_id) as Database_Name,  
	mirroring_state_desc,
	mirroring_role_desc,
	mirroring_safety_level_desc
FROM 
	sys.database_mirroring
WHERE  
	mirroring_role IS NOT NULL
	
	
	
---------------------------------------------------------
CREATE TABLE #DBMRESULTS

(

DATABASE_NAME VARCHAR(255),

ROLE INT,

MIRRORING_STATE TINYINT,

WITNESS_STATUS TINYINT,

LOG_GENERAT_RATE INT,

UNSENT_LOG INT,

SENT_RATE INT,

UNRESTORED_LOG INT,

RECOVERY_RATE INT,

TRANSACTION_DELAY INT,

TRANSACTION_PER_SEC INT,

AVERAGE_DELAY INT,

TIME_RECORDED DATETIME,

TIME_BEHIND DATETIME,

LOCAL_TIME DATETIME

)

INSERT INTO #DBMRESULTS

EXEC MSDB.SYS.SP_DBMMONITORRESULTS 'ECOLAB_Operative', 0,1

SELECT DATABASE_NAME,

(CASE ROLE

WHEN 1 THEN 'PRINCIPAL'

WHEN 2 THEN 'MIRROR'

END) ROLE_OFDB_QUERY_FIRED,

(CASE MIRRORING_STATE

WHEN 0 THEN 'SUSPENDED'

WHEN 1 THEN 'DISCONNECTED'

WHEN 2 THEN 'SYNCHRONIZING'

WHEN 3 THEN 'PENDING FAILOVER'

WHEN 4 THEN 'SYNCHRONIZED'

END) MIRRORING_STATE,

(CASE WITNESS_STATUS

WHEN 0 THEN 'UNKNOWN'

WHEN 1 THEN 'CONNECTED'

WHEN 2 THEN 'DISCONNECTED'

END) WITNESS_STATUS,

LOG_GENERAT_RATE,

UNSENT_LOG,

SENT_RATE,

UNRESTORED_LOG,

RECOVERY_RATE,

TRANSACTION_DELAY,

TRANSACTION_PER_SEC,

AVERAGE_DELAY,

TIME_RECORDED,

TIME_BEHIND,

LOCAL_TIME

FROM #DBMRESULTS

DROP TABLE #DBMRESULTS





DECLARE @Mirror TABLE
 (database_name SYSNAME,[role] INT,mirroring_state INT
,witness_status INT,log_generation_rate INT,unsent_log INT
,send_rate INT,unrestored_log INT,recovery_rate INT
,transaction_delay INT,transactions_per_sec INT,average_delay INT
,time_recorded DATETIME,time_behind DATETIME,local_time DATETIME)
 
-- @id will increment and pull each mirrored database
DECLARE  @id        INT
 ,@db        VARCHAR(256)
 ,@command    VARCHAR(2000)
SELECT @id = MIN(database_id) FROM sys.database_mirroring
WHERE mirroring_guid IS NOT NULL
 
-- Loop through each database to pull mirror monitor information
WHILE @id IS NOT NULL
BEGIN
  SELECT @db = d.name FROM sys.databases d WHERE d.database_id = @id
  SELECT @command = 'EXEC msdb.dbo.sp_dbmmonitorresults @database_name='+QUOTENAME(@db)+''
  PRINT @command
  INSERT INTO @Mirror
    EXEC (@command)
--Increment @id
  SELECT @id = MIN(database_id) FROM sys.database_mirroring
  WHERE mirroring_guid IS NOT NULL AND database_id > @id
END
-- Your WHERE clause/values will vary
SELECT * FROM @Mirror
WHERE unsent_log > 10	
	