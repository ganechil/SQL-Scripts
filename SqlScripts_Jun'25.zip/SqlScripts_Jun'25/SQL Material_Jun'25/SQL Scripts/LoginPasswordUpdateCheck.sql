select updatedate as Update_Date, dbname, loginname as Login_Name, sysadmin as Sys_Admin, denylogin, sid, password, * from sys.syslogins
Where loginname not like 'NT %' and loginname not like '##MS%'
order by sysadmin desc, updatedate desc
Go




--DBA--##################################--By Chil--##################################
--Find SQL & Windows logins info
SELECT 
		@@servername As ServerName,
		sp.name AS login,
       sp.type_desc AS login_type,
       CASE WHEN sp.is_disabled = 1 THEN 'Disabled'
            ELSE 'Yes' END AS status,
       CASE WHEN SL.is_policy_checked = 0 THEN 'Disabled'
            ELSE 'Yes' END AS IsPolicyChecked,
				   STUFF((SELECT ',' + roles.name 
              FROM sys.server_role_members rm 
              JOIN sys.server_principals roles ON rm.role_principal_id = roles.principal_id 
              WHERE rm.member_principal_id = sp.principal_id 
              FOR XML PATH('')), 1, 1, '') AS ServerRole,
       LOGINPROPERTY(SL.name, 'DaysUntilExpiration') AS DaysUntilExpiration,
	   -- IS_SRVROLEMEMBER ('sysadmin', SL.name) AS SysAdmin,
	   LOGINPROPERTY (SL.name, 'IsExpired') AS IsExpired, 
       LOGINPROPERTY (SL.name, 'IsMustChange') AS IsMustChange, 
       LOGINPROPERTY (SL.name, 'IsLocked') AS IsLocked, 
       --LOGINPROPERTY (SL.name, 'LockoutTime') AS LockoutTime, 
	   LOGINPROPERTY (SL.name, 'PasswordLastSetTime') AS PasswordLastSetTime,        
       --DATEADD(dd, CONVERT(int, LOGINPROPERTY (SL.name, 'DaysUntilExpiration')) ,
       --CONVERT(datetime, LOGINPROPERTY (SL.name, 'PasswordLastSetTime'))) AS PasswordExpiration, 
   --  LOGINPROPERTY (SL.name, 'BadPasswordCount') AS BadPasswordCount, 
   --  LOGINPROPERTY (SL.name, 'BadPasswordTime') AS BadPasswordTime, 
   -- LOGINPROPERTY (SL.name, 'HistoryLength') AS HistoryLength ,
       sp.create_date
     --  sp.modify_date,
      -- IS_SRVROLEMEMBER('sysadmin', SL.name) AS SysAdmin,
    --   dp.name AS database_role
FROM sys.server_principals sp
LEFT JOIN sys.database_principals u ON u.sid = sp.sid
LEFT JOIN sys.sql_logins SL ON sp.principal_id = SL.principal_id
LEFT JOIN sys.database_role_members drm ON sp.principal_id = drm.member_principal_id
LEFT JOIN sys.database_principals dp ON drm.role_principal_id = dp.principal_id
WHERE sp.type NOT IN ('C', 'R')
AND IS_SRVROLEMEMBER('sysadmin', sp.name) = 1
AND sp.name not in ('ARCSQLADMIN', 'dbadmin', 'FIC\PAMWINADMIN', 'FIC\PAMWINRW')
AND SP.name not like ('NT %')
and SP.name not like ('##MS_%')
order by sp.name
;