--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--Query the sys.objects table to find the objects that changed and filter by modify_date and type; --
--U = User table, P = Stored procedure.--
select * 
from sys.objects 
where (type = 'U' or type = 'P')
and modify_date > dateadd(m, -4, getdate()) 
--and modify_date between '2019-07-01' and '2019-10-17' 

--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--The query below lists all tables that was modified in the last 30 days by ALTER statement.--
select schema_name(schema_id) as schema_name,
name as table_name,
create_date,
modify_date
from sys.tables
where modify_date > DATEADD(DAY, -90, CURRENT_TIMESTAMP)
order by modify_date desc;

--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--https://www.sqlservercentral.com/forums/topic/how-to-find-the-sql-server-databse-last-used-by-db-users
--based on the ideas from
--http://sqlblog.com/blogs/aaron_bertrand/archive/2008/05/06/when-was-my-database-table-last-accessed.aspx

;;WITH myCTE AS
(
SELECT
  DB_NAME(database_id) AS TheDatabase,
  last_user_seek,
  last_user_scan,
  last_user_lookup,
  last_user_update
FROM sys.dm_db_index_usage_stats
)
SELECT
  ServerRestartedDate = (SELECT CREATE_DATE FROM sys.databases where name='tempdb'),
  x.TheDatabase,
  MAX(x.last_read) AS  last_read,
  MAX(x.last_write) AS last_write
FROM
(
SELECT TheDatabase,last_user_seek AS last_read, NULL AS last_write FROM myCTE
  UNION ALL
SELECT TheDatabase,last_user_scan, NULL FROM myCTE
  UNION ALL
SELECT TheDatabase,last_user_lookup, NULL FROM myCTE
  UNION ALL
SELECT TheDatabase,NULL, last_user_update FROM myCTE
) AS x
GROUP BY TheDatabase
ORDER BY TheDatabase

--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--https://www.mssqltips.com/sqlservertip/3171/identify-sql-server-databases-that-are-no-longer-in-use/
--if a database has zero user connections over a long period of time, it may be time to look into removing this database
SELECT @@ServerName AS SERVER
 ,NAME
 ,login_time
 ,last_batch
 ,getdate() AS DATE
 ,STATUS
 ,hostname
 ,program_name
 ,nt_username
 ,loginame
FROM sys.databases d
LEFT JOIN sysprocesses sp ON d.database_id = sp.dbid
WHERE database_id NOT BETWEEN 0
  AND 4
 AND loginame IS NOT NULL
 SELECT @@ServerName AS server
 ,NAME AS dbname
 ,COUNT(STATUS) AS number_of_connections
 ,GETDATE() AS timestamp
FROM sys.databases sd
LEFT JOIN sysprocesses sp ON sd.database_id = sp.dbid
WHERE database_id NOT BETWEEN 1 AND 4
GROUP BY NAME


--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--https://www.sqlservercentral.com/forums/topic/last-modified-dates-on-database-tables
--based on the ideas from
--http://sqlblog.com/blogs/aaron_bertrand/archive/2008/05/06/when-was-my-database-table-last-accessed.aspx

;WITH ServerStarted AS
(
SELECT
  MIN(last_user_seek) AS first_seek,
  MIN(last_user_scan) AS first_scan,
  MIN(last_user_lookup) AS first_lookup
FROM sys.dm_db_index_usage_stats
),
ServerFirst AS
(
SELECT
  CASE
    WHEN first_seek <   first_scan AND first_seek <   first_lookup
    THEN first_seek
    WHEN first_scan <   first_seek AND first_scan <   first_lookup
    THEN first_scan
    ELSE first_lookup
  END AS usage_start_date
FROM ServerStarted
),
myCTE AS
(
SELECT
  DB_NAME(database_id) AS TheDatabase,
  OBJECT_NAME(object_id,database_id) As TheTableName,
  last_user_seek,
  last_user_scan,
  last_user_lookup,
  last_user_update
FROM sys.dm_db_index_usage_stats
)
SELECT
  MIN(ServerFirst.usage_start_date) AS usage_start_date,
  x.TheDatabase,
  x.TheTableName,
  MAX(x.last_read) AS  last_read,
  MAX(x.last_write) AS last_write
FROM
(
SELECT TheDatabase,TheTableName,last_user_seek AS last_read, NULL AS last_write FROM myCTE
  UNION ALL
SELECT TheDatabase,TheTableName,last_user_scan, NULL FROM myCTE
  UNION ALL
SELECT TheDatabase,TheTableName,last_user_lookup, NULL FROM myCTE
  UNION ALL
SELECT TheDatabase,TheTableName,NULL, last_user_update FROM myCTE
) AS x
CROSS JOIN ServerFirst
GROUP BY TheDatabase,TheTableName
ORDER BY TheDatabase,TheTableName