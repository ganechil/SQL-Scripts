SELECT 
    [sJOB].[job_id] AS [JobID]
    , [sJOB].[name] AS [JobName]
    , CASE 
        WHEN [sJOBH].[run_date] IS NULL OR [sJOBH].[run_time] IS NULL THEN NULL
        ELSE CAST(
                CAST([sJOBH].[run_date] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBH].[run_time] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [LastRunDateTime]
    , CASE [sJOBH].[run_status]
        WHEN 0 THEN 'Failed'
        WHEN 1 THEN 'Succeeded'
        WHEN 2 THEN 'Retry'
        WHEN 3 THEN 'Canceled'
        WHEN 4 THEN 'Running' -- In Progress
      END AS [LastRunStatus]
    , STUFF(
            STUFF(RIGHT('000000' + CAST([sJOBH].[run_duration] AS VARCHAR(6)),  6)
                , 3, 0, ':')
            , 6, 0, ':') 
        AS [LastRunDuration (HH:MM:SS)]
    , [sJOBH].[message] AS [LastRunStatusMessage]
    , CASE [sJOBSCH].[NextRunDate]
        WHEN 0 THEN NULL
        ELSE CAST(
                CAST([sJOBSCH].[NextRunDate] AS CHAR(8))
                + ' ' 
                + STUFF(
                    STUFF(RIGHT('000000' + CAST([sJOBSCH].[NextRunTime] AS VARCHAR(6)),  6)
                        , 3, 0, ':')
                    , 6, 0, ':')
                AS DATETIME)
      END AS [NextRunDateTime]
FROM 
    [msdb].[dbo].[sysjobs] AS [sJOB]
    LEFT JOIN (
                SELECT
                    [job_id]
                    , MIN([next_run_date]) AS [NextRunDate]
                    , MIN([next_run_time]) AS [NextRunTime]
                FROM [msdb].[dbo].[sysjobschedules]
                GROUP BY [job_id]
            ) AS [sJOBSCH]
        ON [sJOB].[job_id] = [sJOBSCH].[job_id]
    LEFT JOIN (
                SELECT 
                    [job_id]
                    , [run_date]
                    , [run_time]
                    , [run_status]
                    , [run_duration]
                    , [message]
                    , ROW_NUMBER() OVER (
                                            PARTITION BY [job_id] 
                                            ORDER BY [run_date] DESC, [run_time] DESC
                      ) AS RowNumber
                FROM [msdb].[dbo].[sysjobhistory]
                WHERE [step_id] = 0
            ) AS [sJOBH]
        ON [sJOB].[job_id] = [sJOBH].[job_id]
        AND [sJOBH].[RowNumber] = 1
--where [sJOB].[name] = 'PurgeSubscriptionsJob_BizTalkMsgBoxDb'
ORDER BY [JobName]






select name, step_name, description, server, message, sql_message_id,sj.job_id, run_date, run_time,
msdb.dbo.agent_datetime(run_date, run_time)  as 'RunDateTime', 
RIGHT('000000' + CONVERT(varchar(6), run_duration), 6) AS run_duration,
((run_duration/10000*3600 + (run_duration/100)%100*60 + run_duration%100 + 31 ) / 60) 
as 'RunDurationMinutes'
--SUBSTRING(run_duration, 1, 2) + ':' +
--SUBSTRING(run_duration, 3, 2) + ':' +
--SUBSTRING(run_duration, 5, 2) as [Duration]
from msdb.dbo.sysjobs sj
inner join msdb.dbo.sysjobhistory sjh
on sj.job_id=sjh.job_id
where sj.enabled=1
--and j.name = 'TestJob' --Uncomment to search for a single job
--and msdb.dbo.agent_datetime(run_date, run_time) 
--BETWEEN '01/09/2019' and '07/09/2019'  --Uncomment for date range queries
order by Name, RunDateTime desc









USE msdb;  
GO  
EXEC dbo.sp_help_jobhistory 


--https://www.mssqltips.com/sqlservertip/2850/querying-sql-server-agent-job-history-data/
select TOP 500 J.name, JH.step_name, JH.run_status, --JH.run_date, JH.run_time,
 msdb.dbo.agent_datetime(run_date, run_time) as 'RunDateTime',JH.run_duration,
 ((run_duration/10000*3600 + (run_duration/100)%100*60 + run_duration%100 + 31 ) / 60) 
          as 'RunDurationMinutes'
from dbo.sysjobs J inner join dbo.sysjobhistory JH
on J.job_id = JH.job_id
where J.job_id = '9A308DD8-BEE5-4CEA-82A9-A4E9E95677D4' and step_id=1
--and step_name = 'Log shipping restore log job step.'
--  and message = 'Executed as user: FCVMCRMDB01\SYSTEM. The step succeeded.'
order by run_date desc, run_time desc










