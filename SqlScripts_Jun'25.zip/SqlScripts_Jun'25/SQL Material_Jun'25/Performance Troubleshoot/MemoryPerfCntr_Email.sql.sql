--DBA--##################################--##################################
--Send alert if memory goes below threshold GB
DECLARE @EmailProfile VARCHAR(255)
DECLARE @EmailRecipient VARCHAR(255)
DECLARE @EmailSubject VARCHAR(255)
DECLARE @Threshold INT
DECLARE @pg_size INT, @Instancename varchar(50)
SELECT @pg_size = low from master..spt_values where number = 1 and type = 'E'
SET @EmailProfile = 'SQlAlert' 
SET @EmailRecipient = 'sqlsupport@ncdex.com' 
SET @EmailSubject = 'Availabl Memory on ' + @@SERVERNAME + ' is less than 1GB' 
SET @Threshold = 1555000 -- 1GB0.194259643

IF OBJECT_ID('tempdb..perfmon_counters') is not null DROP TABLE perfmon_counters
SELECT * INTO perfmon_counters FROM sys.dm_os_performance_counters;
 
-- Get SQL Server instance name as it require for capturing Buffer Cache hit Ratio
SELECT  @Instancename = LEFT([object_name], (CHARINDEX(':',[object_name]))) 
FROM    perfmon_counters 
WHERE   counter_name = 'Buffer cache hit ratio';

create table MemoryInfo (
	[Total Memory MB] bigint NOT NULL,
	[Available Memory MB] bigint NOT NULL,
	[% Memory Free] decimal(5,2) NOT NULL)

insert into MemoryInfo
SELECT total_physical_memory_kb/1024 as "Total Memory MB",
       available_physical_memory_kb/1024 as "Available Memory MB",
       available_physical_memory_kb/(total_physical_memory_kb*1.0)*100 AS "% Memory Free"
FROM sys.dm_os_sys_memory

declare @memfree float  
select @memfree=[Available Memory MB] from MemoryInfo    
if (@memfree < 500)
 
/**************************************************************/
--Script: Top Performance Counters - Memory
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
--http://udayarumilli.com/script-to-monitor-sql-server-memory-usage/
-- Get size of SQL Server Page in bytes
/*
(1)Total Server Memory: Shows how much memory SQL Server is using. The primary use of SQL Server�s memory is for the buffer pool, but some memory is also used for storing query plans and keeping track of user process information.
(2)Target Server Memory: This value shows how much memory SQL Server attempts to acquire. If you haven�t configured a max server memory value for SQL Server, the target amount of memory will be about 5MB less than the total available system memory.
(3)Connection Memory (GB): The Connection Memory specifies the total amount of dynamic memory the server is using for maintaining connections
(4)Lock Memory (GB): Shows the total amount of memory the server is using for locks
(5)SQL Cache Memory: Total memory reserved for dynamic SQL statements.
(6)Optimizer Memory: Memory reserved for query optimization.
(7)Granted Workspace Memory: Total amount of memory currently granted to executing processes such as hash, sort, bulk copy, and index creation operations.
(8)Cursor memory usage: Memory using for cursors
(9)Free pages: Amount of free space in pages which are commited but not currently using by SQL Server
(10)Reserved Pages: Shows the number of buffer pool reserved pages.
(11)Stolen pages (MB): Memory used by SQL Server but not for Database pages.It is used for sorting or hashing operations, or �as a generic memory store for allocations to store internal data structures such as locks, transaction context, and connection information.
(12)Cache Pages: Number of 8KB pages in cache.
(13)Page life expectancy: Average how long each data page is staying in buffer cache before being flushed out to make room for other pages
(14)Free list stalls / sec: Number of times a request for a �free� page had to wait for one to become available.
(15)Checkpoint Pages/sec: Checkpoint Pages/sec shows the number of pages that are moved from buffer to disk per second during a checkpoint process
(16)Lazy writes / sec: How many times per second lazy writer has to flush dirty pages out of the buffer cache instead of waiting on a checkpoint.
(17)Memory Grants Outstanding: Number of processes that have successfully acquired workspace memory grant.
(18)Memory Grants Pending: Number of processes waiting on a workspace memory grant.
(19)process_physical_memory_low: Process is responding to low physical memory notification
(20)process_virtual_memory_low: Indicates that low virtual memory condition has been detected
(21)Min Server Memory: Minimum amount of memory SQL Server should acquire
(22)Max Server Memory: Maximum memory that SQL Server can acquire from OS
(23)Buffer cache hit ratio: Percentage of pages that were found in the buffer pool without having to incur a read from disk
*/ 
 
BEGIN
        DECLARE @tableHTML NVARCHAR(MAX); 
        SET @tableHTML = N'<style type="text/css">'
            + N'.h1 {font-family: Arial, verdana;font-size:16px;border:0px;background-color:white;} '
            + N'.h2 {font-family: Arial, verdana;font-size:12px;border:0px;background-color:white;} '
            + N'body {font-family: Arial, verdana;} '
            + N'table{font-size:12px; border-collapse:collapse;border:1px solid black; padding:3px;} '
            + N'td{background-color:#F1F1F1; border:1px solid black; padding:3px;} '
            + N'th{background-color:#99CCFF; border:1px solid black; padding:3px;}'
            + N'</style>' + N'<table border="1">' + N'<tr>'
            + N'<th>Counter</th>' + N'<th>Value</th>'
            + N'</tr>'
            + CAST(
			(
			
		SELECT * FROM (

SELECT 'Total Physical Memory (GB): ' as Cntr,
		total_physical_memory_kb/1048576.0 AS Value 
FROM sys.dm_os_sys_memory
UNION ALL
SELECT 'Available Physical Memory (MB): ',
		available_physical_memory_kb/1024.0
FROM sys.dm_os_sys_memory
UNION ALL
SELECT '% Memory Free: ',
		(available_physical_memory_kb/(total_physical_memory_kb*1.0)*100)
FROM sys.dm_os_sys_memory
UNION ALL
SELECT  'Total Server Memory (GB): ',
        (cntr_value/1048576.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Total Server Memory (KB)'
UNION ALL
SELECT  'Target Server Memory (GB): ', 
        (cntr_value/1048576.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Target Server Memory (KB)'
UNION ALL
SELECT  'Connection Memory (MB): ', 
        (cntr_value/1024.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Connection Memory (KB)'
UNION ALL
SELECT  'Lock Memory (MB): ', 
        (cntr_value/1024.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Lock Memory (KB)'
UNION ALL
SELECT  'SQL Cache Memory (MB): ', 
        (cntr_value/1024.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'SQL Cache Memory (KB)'
UNION ALL
SELECT  'Optimizer Memory (MB): ', 
        (cntr_value/1024.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Optimizer Memory (KB) '
UNION ALL
SELECT  'Granted Workspace Memory (MB): ', 
        (cntr_value/1024.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Granted Workspace Memory (KB) '
UNION ALL
SELECT  'Cursor memory usage (MB): ', 
        (cntr_value/1024.0) 
FROM    perfmon_counters 
WHERE   counter_name = 'Cursor memory usage' and instance_name = '_Total'
UNION ALL
SELECT  'Total pages Size (MB): ', 
        (cntr_value*@pg_size)/1048576.0 
FROM    perfmon_counters 
WHERE   object_name= @Instancename+'Buffer Manager' 
        and counter_name = 'Total pages'
UNION ALL
SELECT  'Database pages (MB): ', 
        (cntr_value*@pg_size)/1048576.0 
FROM    perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' and counter_name = 'Database pages'
UNION ALL
SELECT  'Free pages (MB): ', 
        (cntr_value*@pg_size)/1048576.0 
FROM    perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' 
        and counter_name = 'Free pages'
UNION ALL
SELECT  'Reserved pages (MB): ', 
        (cntr_value*@pg_size)/1048576.0 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Reserved pages'
UNION ALL
SELECT  'Stolen pages (MB): ', 
        (cntr_value*@pg_size)/1048576.0 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Stolen pages'
UNION ALL
SELECT  'Cache Pages (MB): ', 
        (cntr_value*@pg_size)/1048576.0 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Plan Cache' 
        and counter_name = 'Cache Pages' and instance_name = '_Total'
UNION ALL
SELECT  'Page Life Expectency in seconds: ',
        cntr_value 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Page life expectancy'
UNION ALL
SELECT  'Free list stalls/sec: ',
        cntr_value 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Free list stalls/sec'
UNION ALL
SELECT  'Checkpoint pages/sec: ',
        cntr_value 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Checkpoint pages/sec'
UNION ALL
SELECT  'Lazy writes/sec: ',
        cntr_value 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Lazy writes/sec'
UNION ALL
SELECT  'Memory Grants Pending: ',
        cntr_value 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Pending'
UNION ALL
SELECT  'Memory Grants Outstanding: ',
        cntr_value 
FROM    perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Outstanding'
UNION ALL
SELECT  'process_physical_memory_low: ',
        process_physical_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'process_virtual_memory_low: ',
        process_virtual_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'Max_Server_Memory (MB): ' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'max server memory (MB)'
UNION ALL
SELECT  'Min_Server_Memory (MB): ' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'min server memory (MB)'
UNION ALL
SELECT  'BufferCacheHitRatio: ',
        (a.cntr_value * 1.0 / b.cntr_value) * 100.0 
FROM    sys.dm_os_performance_counters a
        JOIN (SELECT cntr_value,OBJECT_NAME FROM sys.dm_os_performance_counters
              WHERE counter_name = 'Buffer cache hit ratio base' AND 
                    OBJECT_NAME = @Instancename+'Buffer Manager') b ON 
                    a.OBJECT_NAME = b.OBJECT_NAME WHERE a.counter_name = 'Buffer cache hit ratio' 
                    AND a.OBJECT_NAME = @Instancename+'Buffer Manager'
 
) AS D

		/*	SELECT  'Total Server Memory (GB)' AS 'td','',(cntr_value/1048576.0) AS 'td',''
			FROM perfmon_counters 
			WHERE counter_name = 'Total Server Memory (KB)'  */
		

			FOR XML PATH('tr'),Elements
            )
			AS NVARCHAR(MAX))
		    + N'</table>'; 

           
 EXEC msdb.dbo.sp_send_dbmail 
 @profile_name = @EmailProfile,
 @recipients = @EmailRecipient, 
 @subject = @EmailSubject,
 @body =@tableHTML, @body_format = 'HTML'; 
END
GO

Drop Table perfmon_counters
drop table MemoryInfo





--DBA--##################################--##################################
--Send alert of all perf counters if memory goes below threshold
-- Declare variables
DECLARE @EmailProfile VARCHAR(255)
DECLARE @EmailRecipient VARCHAR(255)
DECLARE @EmailSubject VARCHAR(255)
DECLARE @Threshold INT
--DBA--##################################--##################################
DECLARE @pg_size INT, @Instancename varchar(50)
SELECT @pg_size = low from master..spt_values where number = 1 and type = 'E'
-- Set variables
SET @EmailProfile = 'SQlAlert'
SET @EmailRecipient = 'sqlsupport@ncdex.com'
SET @EmailSubject = 'Availabl Memory on ' + @@SERVERNAME + ' is less than 0.19/1GB'
SET @Threshold = 200000 -- 1GB0.194259643
-- Check Log Send Queue KB
IF OBJECT_ID('tempdb..perfmon_counters') is not null DROP TABLE perfmon_counters
SELECT * INTO perfmon_counters FROM sys.dm_os_performance_counters;
 
SELECT  'Total Server Memory (GB)' as Cntr,
        (cntr_value/1048576.0) AS Value 
FROM    perfmon_counters 
WHERE   counter_name = 'Total Server Memory (KB)'

    BEGIN
        DECLARE @tableHTML NVARCHAR(MAX); 
        SET @tableHTML = N'<style type="text/css">'
            + N'.h1 {font-family: Arial, verdana;font-size:16px;border:0px;background-color:white;} '
            + N'.h2 {font-family: Arial, verdana;font-size:12px;border:0px;background-color:white;} '
            + N'body {font-family: Arial, verdana;} '
            + N'table{font-size:12px; border-collapse:collapse;border:1px solid black; padding:3px;} '
            + N'td{background-color:#F1F1F1; border:1px solid black; padding:3px;} '
            + N'th{background-color:#99CCFF; border:1px solid black; padding:3px;}'
            + N'</style>' + N'<table border="1">' + N'<tr>'
            + N'<th>CNtr</th>' + N'<th>Value</th>'
            + N'</tr>'
            + CAST(( SELECT td =Counter_Name,
                            '' ,
                            td = cntr_value,
                            ''
                     FROM    sys.dm_os_performance_counters
            WHERE   counter_name = 'Total Server Memory (KB)'
			 AND Cntr_Value > @Threshold
                   FOR
                     XML PATH('tr'),
                         Elements
                   )AS NVARCHAR(MAX)) 
				   
				   + N'</table>'; 
           
            -- Email results 
        EXEC msdb.dbo.sp_send_dbmail @profile_name = @EmailProfile,
            @recipients = @EmailRecipient, @subject = @EmailSubject,
            @body =@tableHTML, @body_format = 'HTML'; 
    END
    GO



	
--DBA--##################################--##################################
/**************************************************************/
--Script: Top Performance Counters - Memory
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
--http://udayarumilli.com/script-to-monitor-sql-server-memory-usage/
-- Get size of SQL Server Page in bytes
/*
(1)Total Server Memory: Shows how much memory SQL Server is using. The primary use of SQL Server�s memory is for the buffer pool, but some memory is also used for storing query plans and keeping track of user process information.
(2)Target Server Memory: This value shows how much memory SQL Server attempts to acquire. If you haven�t configured a max server memory value for SQL Server, the target amount of memory will be about 5MB less than the total available system memory.
(3)Connection Memory (GB): The Connection Memory specifies the total amount of dynamic memory the server is using for maintaining connections
(4)Lock Memory (GB): Shows the total amount of memory the server is using for locks
(5)SQL Cache Memory: Total memory reserved for dynamic SQL statements.
(6)Optimizer Memory: Memory reserved for query optimization.
(7)Granted Workspace Memory: Total amount of memory currently granted to executing processes such as hash, sort, bulk copy, and index creation operations.
(8)Cursor memory usage: Memory using for cursors
(9)Free pages: Amount of free space in pages which are commited but not currently using by SQL Server
(10)Reserved Pages: Shows the number of buffer pool reserved pages.
(11)Stolen pages (MB): Memory used by SQL Server but not for Database pages.It is used for sorting or hashing operations, or �as a generic memory store for allocations to store internal data structures such as locks, transaction context, and connection information.
(12)Cache Pages: Number of 8KB pages in cache.
(13)Page life expectancy: Average how long each data page is staying in buffer cache before being flushed out to make room for other pages
(14)Free list stalls / sec: Number of times a request for a �free� page had to wait for one to become available.
(15)Checkpoint Pages/sec: Checkpoint Pages/sec shows the number of pages that are moved from buffer to disk per second during a checkpoint process
(16)Lazy writes / sec: How many times per second lazy writer has to flush dirty pages out of the buffer cache instead of waiting on a checkpoint.
(17)Memory Grants Outstanding: Number of processes that have successfully acquired workspace memory grant.
(18)Memory Grants Pending: Number of processes waiting on a workspace memory grant.
(19)process_physical_memory_low: Process is responding to low physical memory notification
(20)process_virtual_memory_low: Indicates that low virtual memory condition has been detected
(21)Min Server Memory: Minimum amount of memory SQL Server should acquire
(22)Max Server Memory: Maximum memory that SQL Server can acquire from OS
(23)Buffer cache hit ratio: Percentage of pages that were found in the buffer pool without having to incur a read from disk
*/

DECLARE @pg_size INT, @Instancename varchar(50)
SELECT @pg_size = low from master..spt_values where number = 1 and type = 'E'
 
-- Extract perfmon counters to a temporary table
IF OBJECT_ID('tempdb..#perfmon_counters') is not null DROP TABLE #perfmon_counters
SELECT * INTO #perfmon_counters FROM sys.dm_os_performance_counters;
 
-- Get SQL Server instance name as it require for capturing Buffer Cache hit Ratio
SELECT  @Instancename = LEFT([object_name], (CHARINDEX(':',[object_name]))) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Buffer cache hit ratio';
 
 
SELECT * FROM (
SELECT  'Total Server Memory (GB)' as Cntr,
        (cntr_value/1048576.0) AS Value 
FROM    #perfmon_counters 
WHERE   counter_name = 'Total Server Memory (KB)'
UNION ALL
SELECT  'Target Server Memory (GB)', 
        (cntr_value/1048576.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Target Server Memory (KB)'
UNION ALL
SELECT  'Connection Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Connection Memory (KB)'
UNION ALL
SELECT  'Lock Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Lock Memory (KB)'
UNION ALL
SELECT  'SQL Cache Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'SQL Cache Memory (KB)'
UNION ALL
SELECT  'Optimizer Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Optimizer Memory (KB) '
UNION ALL
SELECT  'Granted Workspace Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Granted Workspace Memory (KB) '
UNION ALL
SELECT  'Cursor memory usage (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Cursor memory usage' and instance_name = '_Total'
UNION ALL
SELECT  'Total pages Size (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name= @Instancename+'Buffer Manager' 
        and counter_name = 'Total pages'
UNION ALL
SELECT  'Database pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' and counter_name = 'Database pages'
UNION ALL
SELECT  'Free pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' 
        and counter_name = 'Free pages'
UNION ALL
SELECT  'Reserved pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Reserved pages'
UNION ALL
SELECT  'Stolen pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Stolen pages'
UNION ALL
SELECT  'Cache Pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Plan Cache' 
        and counter_name = 'Cache Pages' and instance_name = '_Total'
UNION ALL
SELECT  'Page Life Expectency in seconds',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Page life expectancy'
UNION ALL
SELECT  'Free list stalls/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Free list stalls/sec'
UNION ALL
SELECT  'Checkpoint pages/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Checkpoint pages/sec'
UNION ALL
SELECT  'Lazy writes/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Lazy writes/sec'
UNION ALL
SELECT  'Memory Grants Pending',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Pending'
UNION ALL
SELECT  'Memory Grants Outstanding',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Outstanding'
UNION ALL
SELECT  'process_physical_memory_low',
        process_physical_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'process_virtual_memory_low',
        process_virtual_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'Max_Server_Memory (MB)' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'max server memory (MB)'
UNION ALL
SELECT  'Min_Server_Memory (MB)' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'min server memory (MB)'
UNION ALL
SELECT  'BufferCacheHitRatio',
        (a.cntr_value * 1.0 / b.cntr_value) * 100.0 
FROM    sys.dm_os_performance_counters a
        JOIN (SELECT cntr_value,OBJECT_NAME FROM sys.dm_os_performance_counters
              WHERE counter_name = 'Buffer cache hit ratio base' AND 
                    OBJECT_NAME = @Instancename+'Buffer Manager') b ON 
                    a.OBJECT_NAME = b.OBJECT_NAME WHERE a.counter_name = 'Buffer cache hit ratio' 
                    AND a.OBJECT_NAME = @Instancename+'Buffer Manager'
 
) AS D;