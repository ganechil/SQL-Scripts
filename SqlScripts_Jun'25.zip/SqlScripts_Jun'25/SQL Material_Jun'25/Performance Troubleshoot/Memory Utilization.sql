

--Script: Database Wise Buffer Usage
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
 
DECLARE @total_buffer INT;
SELECT  @total_buffer = cntr_value 
FROM   sys.dm_os_performance_counters
WHERE  RTRIM([object_name]) LIKE '%Buffer Manager' 
       AND counter_name = 'Database Pages';
 
;WITH DBBuffer AS
(
SELECT  database_id,
        COUNT_BIG(*) AS db_buffer_pages,
        SUM (CAST ([free_space_in_bytes] AS BIGINT)) / (1024 * 1024) AS [MBEmpty]
FROM    sys.dm_os_buffer_descriptors
GROUP BY database_id
)
SELECT
       CASE [database_id] WHEN 32767 THEN 'Resource DB' ELSE DB_NAME([database_id]) END AS 'db_name',
       db_buffer_pages AS 'db_buffer_pages',
       db_buffer_pages / 128 AS 'db_buffer_Used_MB',
       [mbempty] AS 'db_buffer_Free_MB',
       CONVERT(DECIMAL(6,3), db_buffer_pages * 100.0 / @total_buffer) AS 'db_buffer_percent'
FROM   DBBuffer
ORDER BY db_buffer_Used_MB DESC;



------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/


--Script: Object Wise Buffer Usage
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
 
;WITH obj_buffer AS
(
SELECT
       [Object] = o.name,
       [Type] = o.type_desc,
       [Index] = COALESCE(i.name, ''),
       [Index_Type] = i.type_desc,
       p.[object_id],
       p.index_id,
       au.allocation_unit_id
FROM
       sys.partitions AS p
       INNER JOIN sys.allocation_units AS au ON p.hobt_id = au.container_id
       INNER JOIN sys.objects AS o ON p.[object_id] = o.[object_id]
       INNER JOIN sys.indexes AS i ON o.[object_id] = i.[object_id] AND p.index_id = i.index_id
WHERE
       au.[type] IN (1,2,3) AND o.is_ms_shipped = 0
)
SELECT
       obj.[Object],
       obj.[Type],
       obj.[Index],
       obj.Index_Type,
       COUNT_BIG(b.page_id) AS 'buffer_pages',
       COUNT_BIG(b.page_id) / 128 AS 'buffer_mb'
FROM
       obj_buffer obj 
       INNER JOIN sys.dm_os_buffer_descriptors AS b ON obj.allocation_unit_id = b.allocation_unit_id
WHERE
       b.database_id = DB_ID()
GROUP BY
       obj.[Object],
       obj.[Type],
       obj.[Index],
       obj.Index_Type
ORDER BY
       buffer_pages DESC;



------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/



--Ad hoc is latin for "for this purpose". 
--You might call it an "on the fly" query, or a "just so" query. 
--It's the kind of SQL query you just loosely type out where you need it.
--An Ad-Hoc Query is a query that cannot be determined prior to the moment the query is issued. 
--It is created in order to get information when need arises.
--Also want to add that ad hoc query is vulnerable to SQL injection attacks. 
--We should try to avoid using it and use parameterized SQLs instead
•	 ***Adhoc (query) -->Compiled Plan
•	 **Prepared (prepared statement) -->Compiled Plan
•	 **Proc (stored procedure, function)-->Extended Proc & Compiled Plan
•	 Repl Proc (replication filter procedure)
•	 *Trigger -->Compiled Plan
•	 *View -->Parse Tree
•	 *UsrTab (user table) -->Parse Tree
•	 SysTab (system table)
•	 CHECK -->Parse Tree
•	 Rule
•	 Default
*/
select cacheobjtype, objtype, COUNT (*) As entries_count
from sys.dm_exec_cached_plans
group by cacheobjtype, objtype
order by objtype 




--DBA--##################################--##################################
/********************************************************************************************/
------Optimize for Ad-Hoc Workloads-------
--check out the "optimize for ad hoc workloads" system option. This setting
--changes SQL Server behavior and does not store a plan on first usage, only the query text.
--If it matches a second time, the plan is stored.
/*
Now lets consider situation when there are many queries running over SQL Server database. 
Most of these queries are totally different each other and running not too often. 
Anyway SQL Server need to store its compiled execution plan in cache having its running costs and use some piece of memory.
Running costs are not something that SQL Server can’t handle easily, but lets imagine that we have tons of queries, concurrency etc. 
Then we have a lot of running costs for storing execution plans that won’t be used again and 
using bytes in memory that could be used for something beneficial.
*/
--How do I know when I need to turn this on?
--Here's a query I wrote to show you how many Ad-Hoc Plans you currently have cached and how much disk-space they're eating up (results will change throughout the day - so test it during a time of heavy load):
SELECT 
    S.CacheType, S.Avg_Use, S.Avg_Multi_Use,
    S.Total_Plan_3orMore_Use, S.Total_Plan_2_Use, S.Total_Plan_1_Use, S.Total_Plan,
    CAST( (S.Total_Plan_1_Use * 1.0 / S.Total_Plan) as Decimal(18,2) ) AS [Pct_Plan_1_Use],
    S.Total_MB_1_Use, S.Total_MB,
    CAST( (S.Total_MB_1_Use   * 1.0 / S.Total_MB  ) as Decimal(18,2) ) AS [Pct_MB_1_Use]
FROM (
    SELECT 
        CP.objtype AS [CacheType],
        COUNT(*) AS [Total_Plan],
        SUM(CASE WHEN CP.usecounts > 2 THEN 1 ELSE 0 END) AS [Total_Plan_3orMore_Use],
        SUM(CASE WHEN CP.usecounts = 2 THEN 1 ELSE 0 END) AS [Total_Plan_2_Use],
        SUM(CASE WHEN CP.usecounts = 1 THEN 1 ELSE 0 END) AS [Total_Plan_1_Use], 
        CAST((SUM(CP.size_in_bytes * 1.0) / 1024 / 1024) AS Decimal(12,2) )[Total_MB],
        CAST((SUM(CASE WHEN CP.usecounts = 1 THEN (CP.size_in_bytes * 1.0) ELSE 0 END) / 1024 / 1024) AS Decimal(18,2) ) AS [Total_MB_1_Use],
        CAST(AVG(CP.usecounts * 1.0) as Decimal(12,2)) AS [Avg_Use],
        CAST(AVG(CASE WHEN CP.usecounts > 1 THEN (CP.usecounts * 1.0) ELSE NULL END) as Decimal(12,2)) AS [Avg_Multi_Use]
    FROM sys.dm_exec_cached_plans AS CP
    GROUP BY CP.objtype
) AS S
ORDER BY S.CacheType
/*I'm not gonna say, "When you have X MB's" or "If X% of your Ad Hoc are Single-Use" to turn this on.
It doesn't affect Sprocs, Triggers, Views or Parameterized/Prepared SQL - just the Ad-Hoc queries.
My personal recommendation is to just turn in on in your Prod Environment, but consider leaving it off in your Dev Environment.
I say this only for Dev, because if you're optimizing a query that takes a minute or more to run, 
then you don't want to run it 3 times before you may see how fast it will go with with it cached - every single time you edit it to find the best optimization design.
If your job doesn't involve doing this all day, then go nuts and ask your DBA to turn it on everywhere.*/




--DBA--##################################--##################################
/********************************************************************************************/
------how many plans & how many times plans are cached-------
SELECT MAX(CASE WHEN usecounts BETWEEN 10 AND 100 THEN '10-100'
 WHEN usecounts BETWEEN 101 AND 1000 THEN '101-1000'
 WHEN usecounts BETWEEN 1001 AND 5000 THEN '1001-5000'
 WHEN usecounts BETWEEN 5001 AND 10000 THEN '5001-10000'
 ELSE CAST(usecounts AS VARCHAR(100))
 END) AS usecounts ,
 --COUNT(*) AS countInstance
  COUNT(*) AS 'No. Of Diff-Diff Query Plans'
FROM sys.dm_exec_cached_plans
GROUP BY CASE WHEN usecounts BETWEEN 10 AND 100 THEN 50
 WHEN usecounts BETWEEN 101 AND 1000 THEN 500
 WHEN usecounts BETWEEN 1001 AND 5000 THEN 2500
 WHEN usecounts BETWEEN 5001 AND 10000 THEN 7500
 ELSE usecounts
 END
ORDER BY CASE WHEN usecounts BETWEEN 10 AND 100 THEN 50
 WHEN usecounts BETWEEN 101 AND 1000 THEN 500
 WHEN usecounts BETWEEN 1001 AND 5000 THEN 2500
 WHEN usecounts BETWEEN 5001 AND 10000 THEN 7500
 ELSE usecounts
 END DESC ;
 
 
 
  --DBA--##################################--##################################
/******************************************************************************************/
------frequently used plans-------
--Caching several un-parameterized adhoc queries with large plan size and with no reuse will lead to plan cache bloating. 
--This causes the plan cache to be under constant memory pressure and gives suboptimal performance results. 
--It is therefore important to try to parameterize queries.
 SELECT TOP 10000 WITH TIES
 decp.usecounts ,
  decp.refcounts,
 decp.size_in_bytes/1024/1024.0 As size_in_MB, 
 decp.cacheobjtype ,
 decp.objtype ,
 deqp.query_plan ,
 dest.text
FROM sys.dm_exec_cached_plans decp
 CROSS APPLY sys.dm_exec_query_plan(decp.plan_handle) AS deqp
 CROSS APPLY sys.dm_exec_sql_text(decp.plan_handle) AS dest
 --Where dest.text like '%reboot%'
 --ORDER BY usecounts DESC;
 --ORDER BY size_in_bytes/1024/1024.0 DESC ;
  ORDER BY usecounts DESC;
 





--DBA--##################################--##################################
/******************************************************************************************/
------Examining plan reuse for a single procedure-------
SELECT TOP 100 WITH TIES
 decp.usecounts ,
 decp.refcounts,
 decp.size_in_bytes/1024.0 As size_in_KB, 
 decp.cacheobjtype ,
 decp.objtype ,
 deqp.query_plan ,
 dest.text,
  OBJECT_NAME(dest.objectid)
FROM sys.dm_exec_cached_plans decp
 CROSS APPLY sys.dm_exec_query_plan(decp.plan_handle) AS deqp
 CROSS APPLY sys.dm_exec_sql_text(decp.plan_handle) AS dest
 CROSS APPLY sys.dm_exec_query_stats AS deqs
--WHERE dest.objectid = OBJECT_ID('[NCDEXSCM].[USP_GetKeyWordsDesc]')
--WHERE dest.objectid = OBJECT_ID('[dbo].[Alert_Blocking]')
 AND dest.dbid = DB_ID()
ORDER BY usecounts DESC;

 
 
 
 
--DBA--##################################--##################################
/******************************************************************************************/
------VERY USSEFUL INFO--Examining plan reuse for a Single/All object/SP-------
-- OPTION (RECOMPILE) keeps this query from going into the plan cache
-- OPTIon (RECOMPILE) tells SQL Server that this particular plan is a “single-use plan” that should not be reused for subsequent users
-- OPTION (RECOMPILE) to force SQL Server to get a new plan
SELECT  
qs.EXECUTION_COUNT, 
st.text,
query_plan,
sql_handle, 
plan_handle, 
DB_NAME(st.dbid) AS [DatabaseName],
cp.dbid, 
creation_time,
last_execution_time,
--total_rows,
--total_grant_kb,
total_worker_time,
total_logical_reads,
total_physical_reads,
cp.* , 
qs.*
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS cp
--WHERE st.text like '%Alert_Blocking%'  OPTION (RECOMPILE);
--WHERE OBJECT_NAME (st.objectid) LIKE N'Alert_Blocking' OPTION (RECOMPILE); 
GO

 
 
 


--DBA--##################################--##################################
/********************************************************************************************/
------Investigating logical reads performed by cached stored procedures------
-- Top Cached SPs By Total Logical Reads (SQL 2008 only).
-- Logical reads relate to memory pressure
SELECT TOP ( 25 )
 p.name AS [SP Name] ,
 deps.total_logical_reads AS [TotalLogicalReads] ,
 deps.total_logical_reads / deps.execution_count AS [AvgLogicalReads] ,
 deps.execution_count ,
 ISNULL(deps.execution_count / DATEDIFF(Second, deps.cached_time,
 GETDATE()), 0) AS [Calls/Second] ,
 deps.total_elapsed_time ,
 deps.total_elapsed_time / deps.execution_count AS [avg_elapsed_time] ,
 deps.cached_time
FROM sys.procedures AS p
 INNER JOIN sys.dm_exec_procedure_stats
 AS deps ON p.[object_id] = deps.[object_id]
WHERE deps.database_id = DB_ID()
ANd p.name='Alert_Blocking'
ORDER BY deps.total_logical_reads DESC ;



--DBA--##################################--##################################
/********************************************************************************************/
------Grouping by sql_handle to see query stats at the batch level------
--total_logical_reads, last_logical_reads, min_logical_reads, max_logical_reads: total,last,min & max number of reads from the SQL Server cache buffer that never had to go to the physical hard disk system to satisfy the current requst
--num_queries: number of individual queries in batch
SELECT TOP 100
 SUM(total_logical_reads) AS total_logical_reads , 
 COUNT(*) AS num_queries , --number of individual queries in batch
 --not all usages need be equivalent, in the case of looping
 --or branching code
 MAX(execution_count) AS execution_count ,
 MAX(execText.text) AS queryText
FROM sys.dm_exec_query_stats deqs
 CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS execText
GROUP BY deqs.sql_handle
HAVING AVG(total_logical_reads / execution_count) <> SUM(total_logical_reads)
 / SUM(execution_count)
ORDER BY 1 DESC








------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/


--Query to Gather CPU and Memory Information

WITH SQLProcessCPU
AS(
   SELECT TOP(30) SQLProcessUtilization AS 'CPU_Usage', ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS 'row_number'
   FROM ( 
         SELECT 
           record.value('(./Record/@id)[1]', 'int') AS record_id,
           record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS [SystemIdle],
           record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') AS [SQLProcessUtilization], 
           [timestamp] 
         FROM ( 
              SELECT [timestamp], CONVERT(xml, record) AS [record] 
              FROM sys.dm_os_ring_buffers 
              WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' 
              AND record LIKE '%<SystemHealth>%'
              ) AS x 
        ) AS y
) 

SELECT 
   SERVERPROPERTY('SERVERNAME') AS 'Instance',
   (SELECT value_in_use FROM sys.configurations WHERE name like '%max server memory%') AS 'Max Server Memory',
   (SELECT physical_memory_in_use_kb/1024 FROM sys.dm_os_process_memory) AS 'SQL Server Memory Usage (MB)',
   (SELECT total_physical_memory_kb/1024 FROM sys.dm_os_sys_memory) AS 'Physical Memory (MB)',
   (SELECT available_physical_memory_kb/1024 FROM sys.dm_os_sys_memory) AS 'Available Memory (MB)',
   (SELECT system_memory_state_desc FROM sys.dm_os_sys_memory) AS 'System Memory State',
   (SELECT [cntr_value] FROM sys.dm_os_performance_counters WHERE [object_name] LIKE '%Manager%' AND [counter_name] = 'Page life expectancy') AS 'Page Life Expectancy',
   (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 30) AS 'SQLProcessUtilization30',
   (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 15) AS 'SQLProcessUtilization15',
   (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 10) AS 'SQLProcessUtilization10',
   (SELECT AVG(CPU_Usage) FROM SQLProcessCPU WHERE row_number BETWEEN 1 AND 5)  AS 'SQLProcessUtilization5',
   GETDATE() AS 'Data Sample Timestamp'
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/


SET NOCOUNT ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET LOCK_TIMEOUT 10000;

DECLARE @ServiceName nvarchar(100)
SET @ServiceName =
                  CASE
                    WHEN @@SERVICENAME = 'MSSQLSERVER' THEN 'SQLServer:'
                    ELSE 'MSSQL$' + @@SERVICENAME + ':'
                  END

DECLARE @Perf TABLE (
  object_name nvarchar(20),
  counter_name nvarchar(128),
  instance_name nvarchar(128),
  cntr_value bigint,
  formatted_value numeric(20, 2),
  shortname nvarchar(20)
)
INSERT INTO @Perf (object_name, counter_name, instance_name, cntr_value, formatted_value, shortname)
  SELECT
    CASE
      WHEN CHARINDEX('Memory Manager', object_name) > 0 THEN 'Memory Manager'
      WHEN CHARINDEX('Buffer Manager', object_name) > 0 THEN 'Buffer Manager'
      WHEN CHARINDEX('Plan Cache', object_name) > 0 THEN 'Plan Cache'
      WHEN CHARINDEX('Buffer Node', object_name) > 0 THEN 'Buffer Node' -- 2008
      WHEN CHARINDEX('Memory Node', object_name) > 0 THEN 'Memory Node' -- 2012
      WHEN CHARINDEX('Cursor', object_name) > 0 THEN 'Cursor'
      ELSE NULL
    END AS object_name,
    CAST(RTRIM(counter_name) AS nvarchar(100)) AS counter_name,
    RTRIM(instance_name) AS instance_name,
    cntr_value,
    CAST(NULL AS decimal(20, 2)) AS formatted_value,
    SUBSTRING(counter_name, 1, PATINDEX('% %', counter_name)) shortname
  FROM sys.dm_os_performance_counters
  WHERE (object_name LIKE @ServiceName + 'Buffer Node%'     -- LIKE is faster than =. I have no idea why
  OR object_name LIKE @ServiceName + 'Buffer Manager%'
  OR object_name LIKE @ServiceName + 'Memory Node%'
  OR object_name LIKE @ServiceName + 'Plan Cache%')
  AND (counter_name LIKE '%pages %'
  OR counter_name LIKE '%Node Memory (KB)%'
  OR counter_name = 'Page life expectancy'
  )
  OR (object_name = @ServiceName + 'Memory Manager'
  AND counter_name IN ('Granted Workspace Memory (KB)', 'Maximum Workspace Memory (KB)',
  'Memory Grants Outstanding', 'Memory Grants Pending',
  'Target Server Memory (KB)', 'Total Server Memory (KB)',
  'Connection Memory (KB)', 'Lock Memory (KB)',
  'Optimizer Memory (KB)', 'SQL Cache Memory (KB)',
  -- for 2012
  'Free Memory (KB)', 'Reserved Server Memory (KB)',
  'Database Cache Memory (KB)', 'Stolen Server Memory (KB)')
  )
  OR (object_name LIKE @ServiceName + 'Cursor Manager by Type%'
  AND counter_name = 'Cursor memory usage'
  AND instance_name = '_Total'
  )

-- Add unit to 'Cursor memory usage'
UPDATE @Perf
SET counter_name = counter_name + ' (KB)'
WHERE counter_name = 'Cursor memory usage'

-- Convert values from pages and KB to MB and rename counters accordingly
UPDATE @Perf
SET counter_name = REPLACE(REPLACE(REPLACE(counter_name, ' pages', ''), ' (KB)', ''), ' (MB)', ''),
    formatted_value =
                     CASE
                       WHEN counter_name LIKE '%pages' THEN cntr_value / 128.
                       WHEN counter_name LIKE '%(KB)' THEN cntr_value / 1024.
                       ELSE cntr_value
                     END

-- Delete some pre 2012 counters for 2012 in order to remove duplicates
DELETE P2008
  FROM @Perf P2008
  INNER JOIN @Perf P2012
    ON REPLACE(P2008.object_name, 'Buffer', 'Memory') = P2012.object_name
    AND P2008.shortname = P2012.shortname
WHERE P2008.object_name IN ('Buffer Manager', 'Buffer Node')

-- Update counter/object names so they look like in 2012
UPDATE PC
SET object_name = REPLACE(object_name, 'Buffer', 'Memory'),
    counter_name = ISNULL(M.NewName, counter_name)
FROM @Perf PC
LEFT JOIN (SELECT
  'Free' AS OldName,
  'Free Memory' AS NewName
UNION ALL
SELECT
  'Database',
  'Database Cache Memory'
UNION ALL
SELECT
  'Stolen',
  'Stolen Server Memory'
UNION ALL
SELECT
  'Reserved',
  'Reserved Server Memory'
UNION ALL
SELECT
  'Foreign',
  'Foreign Node Memory') M
  ON M.OldName = PC.counter_name
  AND NewName NOT IN (SELECT
    counter_name
  FROM @Perf
  WHERE object_name = 'Memory Manager')
WHERE object_name IN ('Buffer Manager', 'Buffer Node')


-- Build Memory Tree
DECLARE @MemTree TABLE (
  Id int,
  ParentId int,
  counter_name nvarchar(128),
  formatted_value numeric(20, 2),
  shortname nvarchar(20)
)

-- Level 5
INSERT @MemTree (Id, ParentId, counter_name, formatted_value, shortname)
  SELECT
    Id = 1226,
    ParentId = 1225,
    instance_name AS counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Plan Cache'
  AND counter_name IN ('Cache')
  AND instance_name <> '_Total'

-- Level 4
INSERT @MemTree (Id, ParentId, counter_name, formatted_value, shortname)
  SELECT
    Id = 1225,
    ParentId = 1220,
    'Plan ' + counter_name AS counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Plan Cache'
  AND counter_name IN ('Cache')
  AND instance_name = '_Total'

  UNION ALL

  SELECT
    Id = 1222,
    ParentId = 1220,
    counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Cursor'
  OR (object_name = 'Memory Manager'
  AND shortname IN ('Connection', 'Lock', 'Optimizer', 'SQL'))

  UNION ALL

  SELECT
    Id = 1112,
    ParentId = 1110,
    counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Memory Manager'
  AND shortname IN ('Reserved')
  UNION ALL
  SELECT
    Id = P.ParentID + 1,
    ParentID = P.ParentID,
    'Used Workspace Memory' AS counter_name,
    SUM(used_memory_kb) / 1024. AS formatted_value,
    NULL AS shortname
  FROM sys.dm_exec_query_resource_semaphores
  CROSS JOIN (SELECT
    1220 AS ParentID
  UNION ALL
  SELECT
    1110) P
  GROUP BY P.ParentID

-- Level 3
INSERT @MemTree (Id, ParentId, counter_name, formatted_value, shortname)
  SELECT
    Id =
        CASE counter_name
          WHEN 'Granted Workspace Memory' THEN 1110
          WHEN 'Stolen Server Memory' THEN 1220
          ELSE 1210
        END,
    ParentId =
              CASE counter_name
                WHEN 'Granted Workspace Memory' THEN 1100
                ELSE 1200
              END,
    counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Memory Manager'
  AND counter_name IN ('Stolen Server Memory', 'Database Cache Memory', 'Free Memory', 'Granted Workspace Memory')

-- Level 2
INSERT @MemTree (Id, ParentId, counter_name, formatted_value, shortname)
  SELECT
    Id =
        CASE
          WHEN counter_name = 'Maximum Workspace Memory' THEN 1100
          ELSE 1200
        END,
    ParentId = 1000,
    counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Memory Manager'
  AND counter_name IN ('Total Server Memory', 'Maximum Workspace Memory')

-- Level 1
INSERT @MemTree (Id, ParentId, counter_name, formatted_value, shortname)
  SELECT
    Id = 1000,
    ParentId = NULL,
    counter_name,
    formatted_value,
    shortname
  FROM @Perf
  WHERE object_name = 'Memory Manager'
  AND counter_name IN ('Target Server Memory')

-- Level 4 -- 'Other Stolen Server Memory' = 'Stolen Server Memory' - SUM(Children of 'Stolen Server Memory')
INSERT @MemTree (Id, ParentId, counter_name, formatted_value, shortname)
  SELECT
    Id = 1222,
    ParentId = 1220,
    counter_name = '<Other Memory Clerks>',
    formatted_value = (SELECT
      SSM.formatted_value
    FROM @MemTree SSM
    WHERE Id = 1220)
    - SUM(formatted_value),
    shortname = 'Other Stolen'
  FROM @MemTree
  WHERE ParentId = 1220

-- Results:

-- PLE and Memory Grants
SELECT
  [Counter Name] = P.counter_name + ISNULL(' (Node: ' + NULLIF(P.instance_name, '') + ')', ''),
  cntr_value AS Value,
  RecommendedMinimum =
                      CASE
                        WHEN P.counter_name = 'Page life expectancy' AND
                          R.Value <= 300 -- no less than 300
                        THEN 300
                        WHEN P.counter_name = 'Page life expectancy' AND
                          R.Value > 300 THEN R.Value
                        ELSE NULL
                      END
FROM @Perf P
LEFT JOIN -- Recommended PLE calculations
(SELECT
  object_name,
  counter_name,
  instance_name,
  CEILING(formatted_value / 4096. * 5) * 60 AS Value -- 300 per every 4GB of Buffer Pool memory or around 60 seconds (1 minute) per every 819MB
FROM @Perf PD
WHERE counter_name = 'Database Cache Memory') R
  ON R.object_name = P.object_name
  AND R.instance_name = P.instance_name
WHERE (P.object_name = 'Memory Manager'
AND P.counter_name IN ('Memory Grants Outstanding', 'Memory Grants Pending', 'Page life expectancy')
)
OR -- For NUMA
(
P.object_name = 'Memory Node'
AND P.counter_name = 'Page life expectancy'
AND (SELECT
  COUNT(DISTINCT instance_name)
FROM @Perf
WHERE object_name = 'Memory Node')
> 1
)
ORDER BY P.counter_name DESC, P.instance_name

-- Get physical memory
-- You can also extract this information from sys.dm_os_sys_info but the column names have changed starting from 2012
IF OBJECT_ID('tempdb..#msver') IS NOT NULL
  DROP TABLE #msver
CREATE TABLE #msver (
  ID int,
  Name sysname,
  Internal_Value int,
  Value nvarchar(512)
)
INSERT #msver EXEC master.dbo.xp_msver 'PhysicalMemory'

-- Physical memory, config parameters and Target memory
SELECT
  min_server_mb = (SELECT
    CAST(value_in_use AS decimal(20, 2))
  FROM sys.configurations
  WHERE name = 'min server memory (MB)'),
  max_server_mb = (SELECT
    CAST(value_in_use AS decimal(20, 2))
  FROM sys.configurations
  WHERE name = 'max server memory (MB)'),
  target_mb = (SELECT
    formatted_value
  FROM @Perf
  WHERE object_name = 'Memory Manager'
  AND counter_name IN ('Target Server Memory')),
  physical_mb = CAST(Internal_Value AS decimal(20, 2))
FROM #msver

-- Memory tree
;
WITH CTE
AS (SELECT
  0 AS lvl,
  counter_name,
  formatted_value,
  Id,
  NULL AS ParentId,
  shortname,
  formatted_value AS TargetServerMemory,
  CAST(NULL AS decimal(20, 4)) AS Perc,
  CAST(NULL AS decimal(20, 4)) AS PercOfTarget
FROM @MemTree
WHERE ParentId IS NULL
UNION ALL
SELECT
  CTE.lvl + 1,
  CAST(REPLICATE(' ', 6 * (CTE.lvl)) + NCHAR(124) + REPLICATE(NCHAR(183), 3) + MT.counter_name AS nvarchar(128)),
  MT.formatted_value,
  MT.Id,
  MT.ParentId,
  MT.shortname,
  CTE.TargetServerMemory,
  CAST(ISNULL(1.0 * MT.formatted_value / NULLIF(CTE.formatted_value, 0), 0) AS decimal(20, 4)) AS Perc,
  CAST(ISNULL(1.0 * MT.formatted_value / NULLIF(CTE.TargetServerMemory, 0), 0) AS decimal(20, 4)) AS PercOfTarget
FROM @MemTree MT
INNER JOIN CTE
  ON MT.ParentId = CTE.Id)
SELECT
  counter_name AS [Counter Name],
  CASE
    WHEN formatted_value > 0 THEN formatted_value
    ELSE NULL
  END AS [Memory MB],
  Perc AS [% of Parent],
  CASE
    WHEN lvl >= 2 THEN PercOfTarget
    ELSE NULL
  END AS [% of Target]
FROM CTE
ORDER BY ISNULL(Id, 10000), formatted_value DESC;
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/












SELECT  OBJECT_NAME
,counter_name
,CONVERT(VARCHAR(10),cntr_value) AS cntr_value
FROM sys.dm_os_performance_counters
WHERE ((OBJECT_NAME LIKE '%Manager%')
AND(counter_name = 'Memory Grants Pending'
OR counter_name='Memory Grants Outstanding'
OR counter_name = 'Page life expectancy'))
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/





select
(physical_memory_in_use_kb/1024)Phy_Memory_usedby_Sqlserver_MB,
(locked_page_allocations_kb/1024 )Locked_pages_used_Sqlserver_MB,
(virtual_address_space_committed_kb/1024 )Total_Memory_UsedBySQLServer_MB,
process_physical_memory_low,
process_virtual_memory_low
from sys. dm_os_process_memory
--Phy_Memory_usedby_Sqlserver_MB-- Gives total Physical memory used by SQL Server in MB
--Total_Memory_usedBy_SQLServer_MB-- Gives total memory(RAM+Page file) used by SQL Server in MB
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/






--Script: Captures Buffer Pool Usage
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/*********************************************/
 
-- SQL server 2008 / 2008 R2
 
SELECT
     (bpool_committed*8)/1024.0 as BPool_Committed_MB,
     (bpool_commit_target*8)/1024.0 as BPool_Commit_Tgt_MB,
     (bpool_visible*8)/1024.0 as BPool_Visible_MB
FROM sys.dm_os_sys_info;
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/





--Script: Captures System Memory Usage
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/*********************************************************************/
 
select
      total_physical_memory_kb/1024 AS total_physical_memory_mb,
      available_physical_memory_kb/1024 AS available_physical_memory_mb,
      total_page_file_kb/1024 AS total_page_file_mb,
      available_page_file_kb/1024 AS available_page_file_mb,
      100 - (100 * CAST(available_physical_memory_kb AS DECIMAL(18,3))/CAST(total_physical_memory_kb AS DECIMAL(18,3))) 
      AS 'Percentage_Used',
      system_memory_state_desc
from  sys.dm_os_sys_memory;
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/



-- Script: SQL Server Process Memory Usage
-- Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
select
      physical_memory_in_use_kb/1048576.0 AS 'physical_memory_in_use (GB)',
      locked_page_allocations_kb/1048576.0 AS 'locked_page_allocations (GB)',
      virtual_address_space_committed_kb/1048576.0 AS 'virtual_address_space_committed (GB)',
      available_commit_limit_kb/1048576.0 AS 'available_commit_limit (GB)',
      page_fault_count as 'page_fault_count'
from  sys.dm_os_process_memory;
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/


------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/





------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/       
       
       
       
       
       
       
       --Script: Top 25 Costliest Stored Procedures by Logical Reads
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
 
SELECT  TOP(25)
        p.name AS [SP Name],
        qs.total_logical_reads AS [TotalLogicalReads],
        qs.total_logical_reads/qs.execution_count AS [AvgLogicalReads],
        qs.execution_count AS 'execution_count',
        qs.total_elapsed_time AS 'total_elapsed_time',
        qs.total_elapsed_time/qs.execution_count AS 'avg_elapsed_time',
        qs.cached_time AS 'cached_time'
FROM    sys.procedures AS p
        INNER JOIN sys.dm_exec_procedure_stats AS qs 
                   ON p.[object_id] = qs.[object_id]
WHERE
        qs.database_id = DB_ID()
ORDER BY
        qs.total_logical_reads DESC;
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/          
        
        






--Script: Top Performance Counters - Memory
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
 
-- Get size of SQL Server Page in bytes
DECLARE @pg_size INT, @Instancename varchar(50)
SELECT @pg_size = low from master..spt_values where number = 1 and type = 'E'
 
-- Extract perfmon counters to a temporary table
IF OBJECT_ID('tempdb..#perfmon_counters') is not null DROP TABLE #perfmon_counters
SELECT * INTO #perfmon_counters FROM sys.dm_os_performance_counters;
 
-- Get SQL Server instance name as it require for capturing Buffer Cache hit Ratio
SELECT  @Instancename = LEFT([object_name], (CHARINDEX(':',[object_name]))) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Buffer cache hit ratio';
 
 
SELECT * FROM (
SELECT  'Total Server Memory (GB)' as Cntr,
        (cntr_value/1048576.0) AS Value 
FROM    #perfmon_counters 
WHERE   counter_name = 'Total Server Memory (KB)'
UNION ALL
SELECT  'Target Server Memory (GB)', 
        (cntr_value/1048576.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Target Server Memory (KB)'
UNION ALL
SELECT  'Connection Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Connection Memory (KB)'
UNION ALL
SELECT  'Lock Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Lock Memory (KB)'
UNION ALL
SELECT  'SQL Cache Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'SQL Cache Memory (KB)'
UNION ALL
SELECT  'Optimizer Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Optimizer Memory (KB) '
UNION ALL
SELECT  'Granted Workspace Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Granted Workspace Memory (KB) '
UNION ALL
SELECT  'Cursor memory usage (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Cursor memory usage' and instance_name = '_Total'
UNION ALL
SELECT  'Total pages Size (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name= @Instancename+'Buffer Manager' 
        and counter_name = 'Total pages'
UNION ALL
SELECT  'Database pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' and counter_name = 'Database pages'
UNION ALL
SELECT  'Free pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' 
        and counter_name = 'Free pages'
UNION ALL
SELECT  'Reserved pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Reserved pages'
UNION ALL
SELECT  'Stolen pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Stolen pages'
UNION ALL
SELECT  'Cache Pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Plan Cache' 
        and counter_name = 'Cache Pages' and instance_name = '_Total'
UNION ALL
SELECT  'Page Life Expectency in seconds',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Page life expectancy'
UNION ALL
SELECT  'Free list stalls/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Free list stalls/sec'
UNION ALL
SELECT  'Checkpoint pages/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Checkpoint pages/sec'
UNION ALL
SELECT  'Lazy writes/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Lazy writes/sec'
UNION ALL
SELECT  'Memory Grants Pending',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Pending'
UNION ALL
SELECT  'Memory Grants Outstanding',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Outstanding'
UNION ALL
SELECT  'process_physical_memory_low',
        process_physical_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'process_virtual_memory_low',
        process_virtual_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'Max_Server_Memory (MB)' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'max server memory (MB)'
UNION ALL
SELECT  'Min_Server_Memory (MB)' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'min server memory (MB)'
UNION ALL
SELECT  'BufferCacheHitRatio',
        (a.cntr_value * 1.0 / b.cntr_value) * 100.0 
FROM    sys.dm_os_performance_counters a
        JOIN (SELECT cntr_value,OBJECT_NAME FROM sys.dm_os_performance_counters
              WHERE counter_name = 'Buffer cache hit ratio base' AND 
                    OBJECT_NAME = @Instancename+'Buffer Manager') b ON 
                    a.OBJECT_NAME = b.OBJECT_NAME WHERE a.counter_name = 'Buffer cache hit ratio' 
                    AND a.OBJECT_NAME = @Instancename+'Buffer Manager'
 
) AS D;
------------------------------------------------------------------------------*/
------------------------------------------------------------------------------*/  




 
