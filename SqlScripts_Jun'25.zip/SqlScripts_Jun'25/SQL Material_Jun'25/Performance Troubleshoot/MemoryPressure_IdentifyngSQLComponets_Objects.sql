--DBA--##################################--##################################
--Identify SQL Components/Objects Causing Memory Pressure--
---------------https://www.youtube.com/watch?v=07lZ1yKc1F0-------------------
select physical_memory_in_use_kb/1024/1024.0 As physical_memory_in_useGB, 
virtual_address_space_committed_kb/1024/1024.0 As virtual_address_space_committedGB, --total memory that is allocated by process
available_commit_limit_kb/1024/1024.0 As available_commit_limitGB, 
memory_utilization_percentage 
from sys.dm_os_process_memory;



--DBA--##################################--##################################
/**************************************************************/
--Script: Top Performance Counters - Memory
--Works On: 2008, 2008 R2, 2012, 2014, 2016
/**************************************************************/
--http://udayarumilli.com/script-to-monitor-sql-server-memory-usage/
-- Get size of SQL Server Page in bytes
/*
(1)Total Server Memory: Shows how much memory SQL Server is using. The primary use of SQL Server�s memory is for the buffer pool, but some memory is also used for storing query plans and keeping track of user process information.
(2)Target Server Memory: This value shows how much memory SQL Server attempts to acquire. If you haven�t configured a max server memory value for SQL Server, the target amount of memory will be about 5MB less than the total available system memory.
(3)Connection Memory (GB): The Connection Memory specifies the total amount of dynamic memory the server is using for maintaining connections
(4)Lock Memory (GB): Shows the total amount of memory the server is using for locks
(5)SQL Cache Memory: Total memory reserved for dynamic SQL statements.
(6)Optimizer Memory: Memory reserved for query optimization.
(7)Granted Workspace Memory: Total amount of memory currently granted to executing processes such as hash, sort, bulk copy, and index creation operations.
(8)Cursor memory usage: Memory using for cursors
(9)Free pages: Amount of free space in pages which are commited but not currently using by SQL Server
(10)Reserved Pages: Shows the number of buffer pool reserved pages.
(11)Stolen pages (MB): Memory used by SQL Server but not for Database pages.It is used for sorting or hashing operations, or �as a generic memory store for allocations to store internal data structures such as locks, transaction context, and connection information.
(12)Cache Pages: Number of 8KB pages in cache.
(13)Page life expectancy: Average how long each data page is staying in buffer cache before being flushed out to make room for other pages
(14)Free list stalls / sec: Number of times a request for a �free� page had to wait for one to become available.
(15)Checkpoint Pages/sec: Checkpoint Pages/sec shows the number of pages that are moved from buffer to disk per second during a checkpoint process
(16)Lazy writes / sec: How many times per second lazy writer has to flush dirty pages out of the buffer cache instead of waiting on a checkpoint.
(17)Memory Grants Outstanding: Number of processes that have successfully acquired workspace memory grant.
(18)Memory Grants Pending: Number of processes waiting on a workspace memory grant.
(19)process_physical_memory_low: Process is responding to low physical memory notification
(20)process_virtual_memory_low: Indicates that low virtual memory condition has been detected
(21)Min Server Memory: Minimum amount of memory SQL Server should acquire
(22)Max Server Memory: Maximum memory that SQL Server can acquire from OS
(23)Buffer cache hit ratio: Percentage of pages that were found in the buffer pool without having to incur a read from disk
*/

DECLARE @pg_size INT, @Instancename varchar(50)
SELECT @pg_size = low from master..spt_values where number = 1 and type = 'E'
 
-- Extract perfmon counters to a temporary table
IF OBJECT_ID('tempdb..#perfmon_counters') is not null DROP TABLE #perfmon_counters
SELECT * INTO #perfmon_counters FROM sys.dm_os_performance_counters;
 
-- Get SQL Server instance name as it require for capturing Buffer Cache hit Ratio
SELECT  @Instancename = LEFT([object_name], (CHARINDEX(':',[object_name]))) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Buffer cache hit ratio';
 
 
SELECT * FROM (
SELECT  'Total Server Memory (GB)' as Cntr,
        (cntr_value/1048576.0) AS Value 
FROM    #perfmon_counters 
WHERE   counter_name = 'Total Server Memory (KB)'
UNION ALL
SELECT  'Target Server Memory (GB)', 
        (cntr_value/1048576.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Target Server Memory (KB)'
UNION ALL
SELECT  'Connection Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Connection Memory (KB)'
UNION ALL
SELECT  'Lock Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Lock Memory (KB)'
UNION ALL
SELECT  'SQL Cache Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'SQL Cache Memory (KB)'
UNION ALL
SELECT  'Optimizer Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Optimizer Memory (KB) '
UNION ALL
SELECT  'Granted Workspace Memory (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Granted Workspace Memory (KB) '
UNION ALL
SELECT  'Cursor memory usage (MB)', 
        (cntr_value/1024.0) 
FROM    #perfmon_counters 
WHERE   counter_name = 'Cursor memory usage' and instance_name = '_Total'
UNION ALL
SELECT  'Total pages Size (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name= @Instancename+'Buffer Manager' 
        and counter_name = 'Total pages'
UNION ALL
SELECT  'Database pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' and counter_name = 'Database pages'
UNION ALL
SELECT  'Free pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name = @Instancename+'Buffer Manager' 
        and counter_name = 'Free pages'
UNION ALL
SELECT  'Reserved pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Reserved pages'
UNION ALL
SELECT  'Stolen pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Stolen pages'
UNION ALL
SELECT  'Cache Pages (MB)', 
        (cntr_value*@pg_size)/1048576.0 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Plan Cache' 
        and counter_name = 'Cache Pages' and instance_name = '_Total'
UNION ALL
SELECT  'Page Life Expectency in seconds',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Page life expectancy'
UNION ALL
SELECT  'Free list stalls/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Free list stalls/sec'
UNION ALL
SELECT  'Checkpoint pages/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Checkpoint pages/sec'
UNION ALL
SELECT  'Lazy writes/sec',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Buffer Manager' 
        and counter_name = 'Lazy writes/sec'
UNION ALL
SELECT  'Memory Grants Pending',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Pending'
UNION ALL
SELECT  'Memory Grants Outstanding',
        cntr_value 
FROM    #perfmon_counters 
WHERE   object_name=@Instancename+'Memory Manager' 
        and counter_name = 'Memory Grants Outstanding'
UNION ALL
SELECT  'process_physical_memory_low',
        process_physical_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'process_virtual_memory_low',
        process_virtual_memory_low 
FROM    sys.dm_os_process_memory WITH (NOLOCK)
UNION ALL
SELECT  'Max_Server_Memory (MB)' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'max server memory (MB)'
UNION ALL
SELECT  'Min_Server_Memory (MB)' ,
        [value_in_use] 
FROM    sys.configurations 
WHERE   [name] = 'min server memory (MB)'
UNION ALL
SELECT  'BufferCacheHitRatio',
        (a.cntr_value * 1.0 / b.cntr_value) * 100.0 
FROM    sys.dm_os_performance_counters a
        JOIN (SELECT cntr_value,OBJECT_NAME FROM sys.dm_os_performance_counters
              WHERE counter_name = 'Buffer cache hit ratio base' AND 
                    OBJECT_NAME = @Instancename+'Buffer Manager') b ON 
                    a.OBJECT_NAME = b.OBJECT_NAME WHERE a.counter_name = 'Buffer cache hit ratio' 
                    AND a.OBJECT_NAME = @Instancename+'Buffer Manager'
 
) AS D;






--DBA--##################################--##################################
/******************************************************************************************/
------Total Number Of DATA/INDEX Pages Of CLEAN/DIRTY Pges Which Are Opened From Disk In To The Memory ------
Select * from sys.dm_os_buffer_descriptors Option(Recompile)





--DBA--##################################--##################################
/********************************************************************************************/
----- Get Clean & Dirty Pages for a selected DB------
select Page_Status=case when is_modified=1 Then 'Dirty'
Else 'Clean' End,
dbname = case when database_id = 32767 Then 'ReourceDB'
Else DB_NAME(database_id) End,
Pages=COUNT(1)
From sys.dm_os_buffer_descriptors 
Where database_id=DB_ID()
Group By database_id, is_modified
order by 2 desc;





--DBA--##################################--##################################
/********************************************************************************************/
------determine how much memory each database is using in the buffer pool------
select dbname = case when database_id = 32767 Then 'ReourceDB'
Else DB_NAME(database_id) End,
--select DB_NAME(database_id),
Size_MB=Count(1)/28
From sys.dm_os_buffer_descriptors
Group By (database_id)
Order by 2 Desc;
 
 


--DBA--##################################--##################################
/********************************************************************************************/
------Memory allocation in the buffer pool------
--The first query rolls up buffer pool usage by database. 
--It allows you to determine how much memory each database is using in the buffer pool. 
--It could help you to decide how to deploy databases in a consolidation or scale-out effort
-- Get total buffer usage by database
SELECT DB_NAME(database_id) AS [Database Name] ,
 COUNT(*) * 8 / 1024.0 AS [Cached Size (MB)]
FROM sys.dm_os_buffer_descriptors
WHERE database_id > 4 -- exclude system databases
 AND database_id <> 32767 -- exclude ResourceDB
GROUP BY DB_NAME(database_id)
ORDER BY [Cached Size (MB)] DESC ;
-- Breaks down buffers by object (table, index) in the buffer pool
SELECT OBJECT_NAME(p.[object_id]) AS [ObjectName] ,
 p.index_id ,
 COUNT(*) / 128 AS [Buffer size(MB)] ,
 COUNT(*) AS [Buffer_count]
FROM sys.allocation_units AS a
 INNER JOIN sys.dm_os_buffer_descriptors
 AS b ON a.allocation_unit_id = b.allocation_unit_id
 INNER JOIN sys.partitions AS p ON a.container_id = p.hobt_id
WHERE b.database_id = DB_ID()
 AND p.[object_id] > 100 -- exclude system objects
GROUP BY p.[object_id] ,
 p.index_id
ORDER BY buffer_count DESC





--DBA--##################################--##################################
/********************************************************************************************/
------find the size of the plan cache use------
SELECT AdHoc_Plan_MB, Total_Cache_MB,
        AdHoc_Plan_MB*100.0 / Total_Cache_MB AS 'AdHoc %'
FROM (
SELECT SUM(CASE
            WHEN objtype = 'adhoc'
            THEN size_in_bytes
            ELSE 0 END) / 1048576.0 AdHoc_Plan_MB,
        SUM(size_in_bytes) / 1048576.0 Total_Cache_MB
FROM sys.dm_exec_cached_plans) T

select (sum(single_pages_kb) + sum(multi_pages_kb) ) * 8  / (1024.0 * 1024.0) as plan_cache_in_GB
from sys.dm_os_memory_cache_counters
where type = 'CACHESTORE_SQLCP' or type = 'CACHESTORE_OBJCP' or type = 'MEMORYCLERK_SQLBUFFERPOOL'
go

----------/********************************************************************************************/
------------ Total cache Size SQL 2012
----------select sum(pages_kb) /1024/1024.0 TotalUsed_GB
----------from sys.dm_os_memory_clerks

------------ How big is the plan cache SQL 2012
----------select name, sum(pages_kb) /1024/1024.0 Used_GB
----------from sys.dm_os_memory_clerks


------------ How big is the plan cache SQL 2012
----------select name, sum(pages_kb) /1024.0 MBUsed
----------from sys.dm_os_memory_clerks
----------where type = 'CACHESTORE_SQLCP' or type = 'CACHESTORE_OBJCP' or type = 'MEMORYCLERK_SQLBUFFERPOOL'
----------group by name
----------order by MBUsed desc;
------------order by name;




--DBA--##################################--##################################
/********************************************************************************************/
------gathers some statistics on the type of objects ------
/*
--------CACHEOBJTYPE : type of object in the cache. The domain is:
�	 ***Compiled Plan
�	 **Parse Tree
�	 *Extended Proc
�	 CLR Compiled Func
�	 CLR Compiled Proc

--------OBJTYPE : the type of object. The domain is:
--Ad hoc is latin for "for this purpose". 
--You might call it an "on the fly" query, or a "just so" query. 
--It's the kind of SQL query you just loosely type out where you need it.
--An Ad-Hoc Query is a query that cannot be determined prior to the moment the query is issued. 
--It is created in order to get information when need arises.
--Also want to add that ad hoc query is vulnerable to SQL injection attacks. 
--We should try to avoid using it and use parameterized SQLs instead
�	 ***Adhoc (query) -->Compiled Plan
�	 **Prepared (prepared statement) -->Compiled Plan
�	 **Proc (stored procedure, function)-->Extended Proc & Compiled Plan
�	 Repl Proc (replication filter procedure)
�	 *Trigger -->Compiled Plan
�	 *View -->Parse Tree
�	 *UsrTab (user table) -->Parse Tree
�	 SysTab (system table)
�	 CHECK -->Parse Tree
�	 Rule
�	 Default
*/
select cacheobjtype, objtype, COUNT (*) As entries_count
from sys.dm_exec_cached_plans
group by cacheobjtype, objtype
order by objtype 
 


--DBA--##################################--##################################
/*******************************************************************************************/
------estimate the amount of plan cache memory that is being reused use-------
select sum(size_in_bytes)/1000 as total_size_in_KB,
count(size_in_bytes) as number_of_plans,
((sum(size_in_bytes)/1000) / (count(size_in_bytes))) as avg_size_in_KB,
cacheobjtype, usecounts
from sys.dm_exec_cached_plans
group by  usecounts, cacheobjtype
order by usecounts asc
go





--DBA--##################################--##################################
/*
******************************************************************************************
------Memory allocation in the buffer pool------
-- Buffer Pool Usage for instance
--The second query tells you which objects are using the most memory in your buffer pool,and is filtered by the current database.
-- It shows the table or indexed view name, the index ID (which will be zero for a heap table), 
--and the amount of memory used in the buffer pool for that object. 
/*
Typically, you'll see most memory usage associated such memory clerk types as
CACHESTORE_SQLCP (the cached query plan store for ad hoc SQL) or CACHESTORE_
OBJCP (the store for objects such as triggers, stored procedures, functions, and so on). 
*/
--CACHESTORE_SQLCP: cached query plan store for AD HOC SQL Queries
--CACHESTORE_OBJCP: cached query plan store for objects such as triggers, stored procedures, functions,etc.
--CACHESTORE_PHDR : cache query trees for objects that do not maintain query plans, such as views and constraints
--MEMORYCLERK_SQLBUFFERPOOL: Buffer pool is largest consumer & provider for memory in SQL Server.All requests which require memory for pages < 8 KB are satisfies by buffer pool and this clerk tracks the allocation.
--MEMORYCLERK_SOSNODE:
SELECT TOP(25) [type], 
SUM(single_pages_kb/1024.0) AS [SPA Mem, Mb]
--SUM(pages_kb/1024.0) AS [SPA Mem, Mb]
FROM sys.dm_os_memory_clerks
GROUP BY [type]
ORDER BY SUM(single_pages_kb/1024.0) DESC;
--ORDER BY SUM(pages_kb/1024.0) DESC;




--DBA--##################################--##################################
/*******************************************************************************************
------Which queries have requested, or have had to wait for, large memory grants?------
-- Shows the memory required by both running (non-null grant_time)
-- and waiting queries (null grant_time)
/*
Some of the more obscure memory clerks are not well documented, but 
an important one to watch out for when investigating memory issues is MEMORYCLERK_
SQLQERESERVATIONS, which indicates that there may be insufficient memory in the buffer pool for certain queries to execute.
Such issues should be investigated further using an execution-related DMV, namely sys.dm_exec_query_memory_grants
*/
/*
You should periodically run this query multiple times in succession; 
ideally, you would want to see few, if any, rows returned each time. 
If you do see a lot of rows returned each time, this could be an indication of internal memory pressure.
This query would also help you identify queries that are requesting relatively large memory grants, 
perhaps because they are poorly written or because there are missing indexes that make the query more expensive.
*/
SELECT DB_NAME(st.dbid) AS [DatabaseName] ,
 mg.requested_memory_kb ,
 mg.ideal_memory_kb ,
 mg.request_time ,
 mg.grant_time ,
 mg.query_cost ,
 mg.dop ,
 st.[text]
FROM sys.dm_exec_query_memory_grants AS mg
 CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
WHERE mg.request_time < COALESCE(grant_time, '99991231')
ORDER BY mg.requested_memory_kb DESC ;
-- Shows the memory required by both running (non-null grant_time)
-- and waiting queries (null grant_time)
-- SQL Server 2005 version
SELECT DB_NAME(st.dbid) AS [DatabaseName] ,
 mg.requested_memory_kb ,
 mg.request_time ,
 mg.grant_time ,
 mg.query_cost ,
 mg.dop ,
 st.[text]
FROM sys.dm_exec_query_memory_grants AS mg
 CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
WHERE mg.request_time < COALESCE(grant_time, '99991231')
ORDER BY mg.requested_memory_kb DESC ;
*/



--DBA--##################################--##################################
/*
******************************************************************************************
------Which queries have requested, or have had to wait for, large memory grants?------
SELECT name ,
 type ,
 entries_count ,
 entries_in_use_count
FROM sys.dm_os_memory_cache_counters
--WHERE type IN ( 'CACHESTORE_SQLCP', 'CACHESTORE_OBJCP', 'CACHESTORE_PHDR')
 --ad hoc plans and object plans
ORDER BY entries_count desc
*/


--DBA--##################################--##################################
/********************************************************************************************/
------Optimize for Ad-Hoc Workloads-------
--check out the "optimize for ad hoc workloads" system option. This setting
--changes SQL Server behavior and does not store a plan on first usage, only the query text.
--If it matches a second time, the plan is stored.
/*
Now lets consider situation when there are many queries running over SQL Server database. 
Most of these queries are totally different each other and running not too often. 
Anyway SQL Server need to store its compiled execution plan in cache having its running costs and use some piece of memory.
Running costs are not something that SQL Server can�t handle easily, but lets imagine that we have tons of queries, concurrency etc. 
Then we have a lot of running costs for storing execution plans that won�t be used again and 
using bytes in memory that could be used for something beneficial.
*/
--How do I know when I need to turn this on?
--Here's a query I wrote to show you how many Ad-Hoc Plans you currently have cached and how much disk-space they're eating up (results will change throughout the day - so test it during a time of heavy load):
SELECT 
    S.CacheType, S.Avg_Use, S.Avg_Multi_Use,
    S.Total_Plan_3orMore_Use, S.Total_Plan_2_Use, S.Total_Plan_1_Use, S.Total_Plan,
    CAST( (S.Total_Plan_1_Use * 1.0 / S.Total_Plan) as Decimal(18,2) ) AS [Pct_Plan_1_Use],
    S.Total_MB_1_Use, S.Total_MB,
    CAST( (S.Total_MB_1_Use   * 1.0 / S.Total_MB  ) as Decimal(18,2) ) AS [Pct_MB_1_Use]
FROM (
    SELECT 
        CP.objtype AS [CacheType],
        COUNT(*) AS [Total_Plan],
        SUM(CASE WHEN CP.usecounts > 2 THEN 1 ELSE 0 END) AS [Total_Plan_3orMore_Use],
        SUM(CASE WHEN CP.usecounts = 2 THEN 1 ELSE 0 END) AS [Total_Plan_2_Use],
        SUM(CASE WHEN CP.usecounts = 1 THEN 1 ELSE 0 END) AS [Total_Plan_1_Use], 
        CAST((SUM(CP.size_in_bytes * 1.0) / 1024 / 1024) AS Decimal(12,2) )[Total_MB],
        CAST((SUM(CASE WHEN CP.usecounts = 1 THEN (CP.size_in_bytes * 1.0) ELSE 0 END) / 1024 / 1024) AS Decimal(18,2) ) AS [Total_MB_1_Use],
        CAST(AVG(CP.usecounts * 1.0) as Decimal(12,2)) AS [Avg_Use],
        CAST(AVG(CASE WHEN CP.usecounts > 1 THEN (CP.usecounts * 1.0) ELSE NULL END) as Decimal(12,2)) AS [Avg_Multi_Use]
    FROM sys.dm_exec_cached_plans AS CP
    GROUP BY CP.objtype
) AS S
ORDER BY S.CacheType
/*I'm not gonna say, "When you have X MB's" or "If X% of your Ad Hoc are Single-Use" to turn this on.
It doesn't affect Sprocs, Triggers, Views or Parameterized/Prepared SQL - just the Ad-Hoc queries.
My personal recommendation is to just turn in on in your Prod Environment, but consider leaving it off in your Dev Environment.
I say this only for Dev, because if you're optimizing a query that takes a minute or more to run, 
then you don't want to run it 3 times before you may see how fast it will go with with it cached - every single time you edit it to find the best optimization design.
If your job doesn't involve doing this all day, then go nuts and ask your DBA to turn it on everywhere.*/




--DBA--##################################--##################################
/********************************************************************************************/
------how many plans & how many times plans are cached-------
SELECT MAX(CASE WHEN usecounts BETWEEN 10 AND 100 THEN '10-100'
 WHEN usecounts BETWEEN 101 AND 1000 THEN '101-1000'
 WHEN usecounts BETWEEN 1001 AND 5000 THEN '1001-5000'
 WHEN usecounts BETWEEN 5001 AND 10000 THEN '5001-10000'
 ELSE CAST(usecounts AS VARCHAR(100))
 END) AS usecounts ,
 --COUNT(*) AS countInstance
  COUNT(*) AS 'No. Of Diff-Diff Query Plans'
FROM sys.dm_exec_cached_plans
GROUP BY CASE WHEN usecounts BETWEEN 10 AND 100 THEN 50
 WHEN usecounts BETWEEN 101 AND 1000 THEN 500
 WHEN usecounts BETWEEN 1001 AND 5000 THEN 2500
 WHEN usecounts BETWEEN 5001 AND 10000 THEN 7500
 ELSE usecounts
 END
ORDER BY CASE WHEN usecounts BETWEEN 10 AND 100 THEN 50
 WHEN usecounts BETWEEN 101 AND 1000 THEN 500
 WHEN usecounts BETWEEN 1001 AND 5000 THEN 2500
 WHEN usecounts BETWEEN 5001 AND 10000 THEN 7500
 ELSE usecounts
 END DESC ;
 
 

--DBA--##################################--##################################
/*
******************************************************************************************
-----how many clock rounds have been made for each cache store-------
--Each cachestore has an external and internal clock hand that distinguishes external a& internal memory pressure respectively. 
--The column removed_last_round_count indicates the number of entries (plans) removed in the last round, 
--and the removed_all_rounds_count indicates the total number of entries removed
select * from sys.dm_os_memory_cache_clock_hands
where type = 'CACHESTORE_SQLCP' or type = 'CACHESTORE_OBJCP'
go
*/



--DBA--##################################--##################################
/*
******************************************************************************************
------ Find single_time_use ad hoc queries that are bloating/filling the plan cache-------
--Parameterization of queries gives a significant performance benefit. 
--Parameterized queries have objtype 'Prepared'. 
--Prepared queries typically have large usecounts and are greater in size than the corresponding adhoc shell queries 
 SELECT TOP 10000 WITH TIES 
 decp.usecounts ,
  decp.refcounts,
 decp.size_in_bytes/1024/1024.0 As size_in_MB, 
 decp.cacheobjtype , 
 decp.objtype ,
 deqp.query_plan ,
 dest.text
FROM sys.dm_exec_cached_plans decp
 CROSS APPLY sys.dm_exec_query_plan(decp.plan_handle) AS deqp
 CROSS APPLY sys.dm_exec_sql_text(decp.plan_handle) AS dest
 --Where dest.text like '%reboot%'
 Where decp.usecounts = 1
  --AND decp.usecounts = 1
  --AND cp.usecounts = 2
  --AND cp.usecounts = 3
  --AND cp.usecounts = 4
  --AND cp.usecounts = 5
  --AND cp.usecounts = 6
  --AND cp.usecounts = 7
  --AND cp.usecounts = 8
  --AND cp.usecounts = 9
  --AND cp.usecounts = 10
  --AND cp.usecounts = 11
 ORDER BY size_in_bytes/1024/1024.0 DESC ;
 */
 

 
 
 --DBA--##################################--##################################
/******************************************************************************************/
------frequently used plans-------
--Caching several un-parameterized adhoc queries with large plan size and with no reuse will lead to plan cache bloating. 
--This causes the plan cache to be under constant memory pressure and gives suboptimal performance results. 
--It is therefore important to try to parameterize queries.
 SELECT TOP 10000 WITH TIES
 decp.usecounts ,
  decp.refcounts,
 decp.size_in_bytes/1024/1024.0 As size_in_MB, 
 decp.cacheobjtype ,
 decp.objtype ,
 deqp.query_plan ,
 dest.text
FROM sys.dm_exec_cached_plans decp
 CROSS APPLY sys.dm_exec_query_plan(decp.plan_handle) AS deqp
 CROSS APPLY sys.dm_exec_sql_text(decp.plan_handle) AS dest
 --Where dest.text like '%reboot%'
 --ORDER BY usecounts DESC;
 --ORDER BY size_in_bytes/1024/1024.0 DESC ;
  ORDER BY usecounts DESC;
 
 

--DBA--##################################--##################################
/******************************************************************************************/
------Examining plan reuse for a single procedure-------
SELECT TOP 100 WITH TIES
 decp.usecounts ,
 decp.refcounts,
 decp.size_in_bytes/1024.0 As size_in_KB, 
 decp.cacheobjtype ,
 decp.objtype ,
 deqp.query_plan ,
 dest.text,
  OBJECT_NAME(dest.objectid)
FROM sys.dm_exec_cached_plans decp
 CROSS APPLY sys.dm_exec_query_plan(decp.plan_handle) AS deqp
 CROSS APPLY sys.dm_exec_sql_text(decp.plan_handle) AS dest
 CROSS APPLY sys.dm_exec_query_stats AS deqs
--WHERE dest.objectid = OBJECT_ID('[NCDEXSCM].[USP_GetKeyWordsDesc]')
--WHERE dest.objectid = OBJECT_ID('[dbo].[Alert_Blocking]')
 AND dest.dbid = DB_ID()
ORDER BY usecounts DESC;

 
 
 
 
--DBA--##################################--##################################
/******************************************************************************************/
------VERY USSEFUL INFO--Examining plan reuse for a Single/All object/SP-------
-- OPTION (RECOMPILE) keeps this query from going into the plan cache
-- OPTIon (RECOMPILE) tells SQL Server that this particular plan is a �single-use plan� that should not be reused for subsequent users
-- OPTION (RECOMPILE) to force SQL Server to get a new plan
SELECT  
qs.EXECUTION_COUNT, 
st.text,
query_plan,
sql_handle, 
plan_handle, 
DB_NAME(st.dbid) AS [DatabaseName],
cp.dbid, 
creation_time,
last_execution_time,
--total_rows,
--total_grant_kb,
total_worker_time,
total_logical_reads,
total_physical_reads,
cp.* , 
qs.*
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS cp
--WHERE st.text like '%Alert_Blocking%'  OPTION (RECOMPILE);
--WHERE OBJECT_NAME (st.objectid) LIKE N'Alert_Blocking' OPTION (RECOMPILE); 
GO

 
 
 


--DBA--##################################--##################################
/********************************************************************************************/
------Investigating logical reads performed by cached stored procedures------
-- Top Cached SPs By Total Logical Reads (SQL 2008 only).
-- Logical reads relate to memory pressure
SELECT TOP ( 25 )
 p.name AS [SP Name] ,
 deps.total_logical_reads AS [TotalLogicalReads] ,
 deps.total_logical_reads / deps.execution_count AS [AvgLogicalReads] ,
 deps.execution_count ,
 ISNULL(deps.execution_count / DATEDIFF(Second, deps.cached_time,
 GETDATE()), 0) AS [Calls/Second] ,
 deps.total_elapsed_time ,
 deps.total_elapsed_time / deps.execution_count AS [avg_elapsed_time] ,
 deps.cached_time
FROM sys.procedures AS p
 INNER JOIN sys.dm_exec_procedure_stats
 AS deps ON p.[object_id] = deps.[object_id]
WHERE deps.database_id = DB_ID()
ANd p.name='Alert_Blocking'
ORDER BY deps.total_logical_reads DESC ;



--DBA--##################################--##################################
/********************************************************************************************/
------Grouping by sql_handle to see query stats at the batch level------
--total_logical_reads, last_logical_reads, min_logical_reads, max_logical_reads: total,last,min & max number of reads from the SQL Server cache buffer that never had to go to the physical hard disk system to satisfy the current requst
--num_queries: number of individual queries in batch
SELECT TOP 100
 SUM(total_logical_reads) AS total_logical_reads , 
 COUNT(*) AS num_queries , --number of individual queries in batch
 --not all usages need be equivalent, in the case of looping
 --or branching code
 MAX(execution_count) AS execution_count ,
 MAX(execText.text) AS queryText
FROM sys.dm_exec_query_stats deqs
 CROSS APPLY sys.dm_exec_sql_text(deqs.sql_handle) AS execText
GROUP BY deqs.sql_handle
HAVING AVG(total_logical_reads / execution_count) <> SUM(total_logical_reads)
 / SUM(execution_count)
ORDER BY 1 DESC





