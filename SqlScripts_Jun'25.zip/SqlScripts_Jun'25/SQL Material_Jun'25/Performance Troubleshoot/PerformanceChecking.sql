/********************************************************************************************/
------Get a count of SQL connections by IP address ------
SELECT dec.client_net_address ,
 des.program_name ,
 des.host_name ,
 --des.login_name ,
 COUNT(dec.session_id) AS connection_count
FROM sys.dm_exec_sessions AS des
 INNER JOIN sys.dm_exec_connections AS dec
 ON des.session_id = dec.session_id
-- WHERE LEFT(des.host_name, 2) = 'WK'
GROUP BY dec.client_net_address ,
 des.program_name ,
 des.host_name
 -- des.login_name
-- HAVING COUNT(dec.session_id) > 1
ORDER BY des.program_name,
 dec.client_net_address ;
 
 
/********************************************************************************************/
------Who is connected by SSMS?------ 
 SELECT dec.client_net_address ,
 des.program_name ,
 des.host_name ,
 dest.text
FROM sys.dm_exec_sessions des
 INNER JOIN sys.dm_exec_connections dec
 ON des.session_id = dec.session_id
 CROSS APPLY sys.dm_exec_sql_text(dec.most_recent_sql_handle) dest
WHERE des.program_name LIKE 'Microsoft SQL Server Management Studio%'
ORDER BY des.program_name ,
 dec.client_net_address

 
/********************************************************************************************/
------Logins with more than one session------
SELECT login_name ,
 COUNT(session_id) AS session_count
FROM sys.dm_exec_sessions
WHERE is_user_process = 1
GROUP BY login_name
ORDER BY login_name


/********************************************************************************************/
------Identify inactive sessions-------
DECLARE @days_old SMALLINT
SELECT @days_old = 1
SELECT des.session_id ,
 des.login_time ,
 des.last_request_start_time ,
 des.last_request_end_time ,
 des.[status] ,
 des.[program_name] ,
 des.cpu_time ,
 des.total_elapsed_time ,
 des.memory_usage ,
 des.total_scheduled_time ,
 des.total_elapsed_time ,
 des.reads ,
 des.writes ,
 des.logical_reads ,
 des.row_count ,
 des.is_user_process
FROM sys.dm_exec_sessions des
 INNER JOIN sys.dm_tran_session_transactions dtst
 ON des.session_id = dtst.session_id
WHERE des.is_user_process = 1
 AND DATEDIFF(dd, des.last_request_end_time, GETDATE()) > @days_old
 AND des.status != 'Running'
ORDER BY des.last_request_end_time


/********************************************************************************************/
------Identify inactive sessions-------
SELECT des.session_id ,
 des.login_time ,
 des.last_request_start_time ,
 des.last_request_end_time ,
 des.host_name ,
 des.login_name
FROM sys.dm_exec_sessions des
 INNER JOIN sys.dm_tran_session_transactions dtst
 ON des.session_id = dtst.session_id
 LEFT JOIN sys.dm_exec_requests der
 ON dtst.session_id = der.session_id
WHERE der.session_id IS NULL
ORDER BY des.session_id


/********************************************************************************************/
------Get the largest reused plan or Examining plan attributes-------
SELECT CAST(depa.attribute AS VARCHAR(30)) AS attribute ,
 CAST(depa.value AS VARCHAR(30)) AS value ,
 depa.is_cache_key
FROM ( SELECT TOP 1
 *
 FROM sys.dm_exec_cached_plans
 ORDER BY usecounts DESC
 ) decp
 OUTER APPLY sys.dm_exec_plan_attributes(decp.plan_handle) depa
WHERE is_cache_key = 1
ORDER BY usecounts DESC ;


/********************************************************************************************/
------Finding the CPU-intensive queries.------
--total_worker_time, last_worker_time, min_worker_time, max_worker_time: total, last, min and max amount of time spent in CPU utilization to execute the query, based on this plan
--execution_count: number of times the plan has been used to execute a query
SELECT TOP 20
 total_worker_time ,
 execution_count ,
 total_worker_time / execution_count AS [Avg CPU Time] ,
 CASE WHEN deqs.statement_start_offset = 0
 AND deqs.statement_end_offset = -1
 THEN '-- see objectText column--'
 ELSE '-- query --' + CHAR(13) + CHAR(10)
 + SUBSTRING(execText.text, deqs.statement_start_offset / 2,
 ( ( CASE WHEN deqs.statement_end_offset = -1
 THEN DATALENGTH(execText.text)
 ELSE deqs.statement_end_offset
 END ) - deqs.statement_start_offset ) / 2)
 END AS queryText
FROM sys.dm_exec_query_stats deqs
 CROSS APPLY sys.dm_exec_sql_text(deqs.plan_handle) AS execText
ORDER BY deqs.total_worker_time DESC ;



