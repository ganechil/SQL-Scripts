select sr.session_id as spid, 
       CASE 
	     WHEN sw.blocking_session_id IS NULL THEN sr.blocking_session_id
		 WHEN sw.blocking_session_id = sw.session_id THEN sr.blocking_session_id
		 ELSE sw.blocking_session_id
	    END as blkby,
       ss.login_name as login,ss.host_name as hostname,ss.program_name as appname, 
       sr.command,DB_NAME(sr.database_id) as DB,sr.cpu_time as cpu,sr.logical_reads as reads, sr.writes, mg.granted_memory_kb as mem,
	   CONVERT(decimal(20,3),CONVERT(decimal (20,3),sr.total_elapsed_time)/1000) as TimeSec,
	   CASE 
	     WHEN sr.cpu_time > 0 THEN sr.total_elapsed_time/sr.cpu_time
	   END as CpuxTime,
	   isnull(sw.wait_type, sr.wait_type) as WaitType,
	   CONVERT(decimal(20,3),CONVERT(decimal (20,3),sw.wait_duration_ms)/1000) as WaitTime,  
	   isnull(sw.resource_description,sw2.resource_description) as resourceDescription,
	   sr.last_wait_type, sr.reads as PhysicReads, sr.open_transaction_count,ss.login_time,sr.percent_complete,ss.client_interface_name,
	   ss.nt_domain,ss.nt_user_name,sr.start_time, ss.last_request_end_time as end_time,sc.client_net_address,sc.client_tcp_port, 
	   sc.local_net_address,sc.local_tcp_port, sr.status,
	   case sr.transaction_isolation_level
	       when 0 then 'Unspecified'
		   when 1 then 'ReadUncommitted'
		   when 2 then 'ReadCommitted'
		   when 3 then 'Repeatable'
		   when 4 then 'Serializable'
		   when 5 then 'Snapshot'
	   end as transaction_isolation_level,
	   replace (replace (replace(st.text, char(13), ' '), char(10), ' '), char(9),' ') as text,
	   object_name(st.objectid, st.dbid) as obj,
	   qp.query_plan
from sys.dm_exec_connections sc
	inner join sys.dm_exec_requests sr     
		on (sc.session_id = sr.session_id) and
		   (sc.connection_id = sr.connection_id)
    inner join sys.dm_exec_sessions ss
		on (sc.session_id = ss.session_id)
	inner join sys.dm_os_tasks sta
		on (sr.session_id = sta.session_id) and
		   (sr.task_address = sta.task_address)
	left join sys.dm_os_tasks sta2
		on (sta.session_id = sta2.session_id) and
		   --(sta.task_address = sta2.parent_task_address)
		   (sta.task_address = ISNULL(sta2.parent_task_address,sta.task_address))
	left join sys.dm_os_waiting_tasks sw
		on (sta2.session_id = sw.session_id) and
		   (sta2.task_address = sw.waiting_task_address) 
	left join sys.dm_os_waiting_tasks sw2
		on (sta.session_id = sw2.session_id) and
		   (sta.task_address = sw2.waiting_task_address) 
	left join sys.dm_exec_query_memory_grants mg
		on (sr.session_id = mg.session_id) and
		   (sr.request_id = mg.request_id) 
	outer apply
		sys.dm_exec_sql_text(sr.sql_handle) AS st
	outer apply sys.dm_exec_query_plan(sr.plan_handle) qp
WHERE sc.session_id != @@SPID 
UNION ALL
select sc.session_id as spid,NULL,ss.login_name as login ,ss.host_name as hostname ,ss.program_name as appname, NULL,
       DB_NAME(ss.database_id) as DB, -- se for SQL 2008, colocar NULL aqui
       NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, NULL,NULL,NULL, NULL,ss.login_time,NULL,ss.client_interface_name,ss.nt_domain,ss.nt_user_name,
	   ss.last_request_start_time,ss.last_request_end_time,sc.client_net_address, sc.client_tcp_port, sc.local_net_address, sc.local_tcp_port,
	   NULL,NULL,replace (replace (replace(st.text, char(13), ' '), char(10), ' '), char(9),' ') as text,object_name(st.objectid, st.dbid) as obj,qp.query_plan  
from sys.dm_exec_connections sc
	left join sys.dm_exec_sessions ss
		on (sc.session_id = ss.session_id) 
	outer apply
		sys.dm_exec_sql_text(sc.most_recent_sql_handle) AS st
	outer apply 
		sys.dm_exec_query_plan(sc.most_recent_sql_handle) qp
WHERE sc.session_id in (select blocking_session_id from sys.dm_exec_requests) AND
      sc.session_id not in (select session_id from sys.dm_exec_requests)
order by blkby desc, spid desc




--=======================sem a sr.plan_handle em caso de schema modification lock ou lentidao no ambiente =======================



/*

select sr.session_id as spid, 
       CASE 
	     WHEN sw.blocking_session_id IS NULL THEN sr.blocking_session_id
		 WHEN sw.blocking_session_id = sw.session_id THEN sr.blocking_session_id
		 ELSE sw.blocking_session_id
	    END as blkby,
	   ss.login_name as login,ss.host_name as hostname,ss.program_name as appname, 
       sr.command,DB_NAME(sr.database_id) as DB,sr.cpu_time as cpu,sr.logical_reads as reads, sr.writes, mg.granted_memory_kb as mem,
	   CONVERT(decimal(20,3),CONVERT(decimal (20,3),sr.total_elapsed_time)/1000) as TimeSec,
	   CASE 
	     WHEN sr.cpu_time > 0 THEN sr.total_elapsed_time/sr.cpu_time
	   END as CpuxTime,
	   isnull(sw.wait_type, sr.wait_type) as WaitType,
	   CONVERT(decimal(20,3),CONVERT(decimal (20,3),sw.wait_duration_ms)/1000) as WaitTime, 
	   isnull(sw.resource_description,sw2.resource_description) as resourceDescription,
	   sr.last_wait_type, sr.reads as PhysicReads,sr.open_transaction_count,ss.login_time,sr.percent_complete,ss.client_interface_name,
	   ss.nt_domain,ss.nt_user_name,sr.start_time,ss.last_request_end_time as end_time,sc.client_net_address,sc.client_tcp_port, 
	   sc.local_net_address,sc.local_tcp_port, sr.status,
	   case sr.transaction_isolation_level
	       when 0 then 'Unspecified'
		   when 1 then 'ReadUncommitted'
		   when 2 then 'ReadCommitted'
		   when 3 then 'Repeatable'
		   when 4 then 'Serializable'
		   when 5 then 'Snapshot'
	   end as transaction_isolation_level,
	   replace (replace (replace(st.text, char(13), ' '), char(10), ' '), char(9),' ') as text,
	   object_name(st.objectid, st.dbid) as obj
from sys.dm_exec_connections sc
	inner join sys.dm_exec_requests sr     
		on (sc.session_id = sr.session_id) and
		   (sc.connection_id = sr.connection_id)
    inner join sys.dm_exec_sessions ss
		on (sc.session_id = ss.session_id)
	inner join sys.dm_os_tasks sta
		on (sr.session_id = sta.session_id) and
		   (sr.task_address = sta.task_address)
	left join sys.dm_os_tasks sta2
		on (sta.session_id = sta2.session_id) and
		   (sta.task_address = ISNULL(sta2.parent_task_address,sta.task_address))
		   --(sta.task_address = sta2.parent_task_address)
	left join sys.dm_os_waiting_tasks sw
		on (sta2.session_id = sw.session_id) and
		   (sta2.task_address = sw.waiting_task_address) 
	left join sys.dm_os_waiting_tasks sw2
		on (sta.session_id = sw2.session_id) and
		   (sta.task_address = sw2.waiting_task_address) 
	left join sys.dm_exec_query_memory_grants mg
		on (sr.session_id = mg.session_id) and
		   (sr.request_id = mg.request_id) 
	outer apply
		sys.dm_exec_sql_text(sr.sql_handle) AS st
WHERE sc.session_id != @@SPID 
UNION ALL
select sc.session_id as spid,NULL,ss.login_name as login ,ss.host_name as hostname ,ss.program_name as appname, NULL,DB_NAME(ss.database_id) as DB,NULL,
       NULL,NULL,NULL,NULL,NULL,NULL,NULL, NULL,NULL,NULL, NULL,ss.login_time,NULL,ss.client_interface_name,ss.nt_domain,ss.nt_user_name,
	   ss.last_request_start_time,ss.last_request_end_time,sc.client_net_address, sc.client_tcp_port, sc.local_net_address, sc.local_tcp_port,
	   NULL,NULL,replace (replace (replace(st.text, char(13), ' '), char(10), ' '), char(9),' ') as text,object_name(st.objectid, st.dbid) as obj
from sys.dm_exec_connections sc
	left join sys.dm_exec_sessions ss
		on (sc.session_id = ss.session_id) 
	outer apply
		sys.dm_exec_sql_text(sc.most_recent_sql_handle) AS st
	
WHERE sc.session_id in (select blocking_session_id from sys.dm_exec_requests) AND
      sc.session_id not in (select session_id from sys.dm_exec_requests)
order by blkby desc, spid desc



*/




