-- 6 different ways to clear the plan cache

*****************************************************************************************************
*****************************************************************************************************
--1) PRACTICALLY: SQLCP,  OBJCP, PHDR & decreases LOGICAL READS
DBCC FREEPROCCACHE;
Go

--2) Flush the ad hoc and prepared plan cache for the entire instance
--MARK_IN_USE_FOR_REMOVAL clause releases entries from all current caches once the entries become unused.
DBCC FREESYSTEMCACHE ('ALL') WITH MARK_IN_USE_FOR_REMOVAL;
Go

--3) Decreases LOGICAL READS
Use Master; 
Declare @dbid int = db_ID() 
--Flush the plan cache for one database only
DBCC FLUSHPROCINDB (@dbId);
Go

--4) Flushes the distributed query connection cache used by distributed queries against an instance of SQL Server
DBCC FREESESSIONCACHE;
GO

--5) Clear Dirty Pages
Checkpoint
Go

--6) Clear Clean Pages
DBCC DropCleanBuffers()
Go
*****************************************************************************************************
*****************************************************************************************************








-- Example 1 ***********************
-- Remove all elements from the plan cache for the entire instance 
-- PRACTICALLY: SQLCP,  OBJCP, PHDR & decreases LOGICAL READS
DBCC FREEPROCCACHE;
Go

-- Flush the plan cache for the entire instance and suppress the regular completion message
-- "DBCC execution completed. If DBCC printed error messages, contact your system administrator." 
-- WITH NO_INFOMSGS - Suppresses all informational messages. Informational messages are always suppressed on SQL Data Warehouse and Parallel Data Warehouse.
DBCC FREEPROCCACHE WITH NO_INFOMSGS;
Go

-- Remove the specific query plan from the cache using the plan handle from the above query 
-- Remove one query plan from the cache
USE master;
GO
-- Run a stored procedure or query
EXEC dbo.Alert_Blocking 12;

-- Find the plan handle for that query 
-- OPTION (RECOMPILE) keeps this query from going into the plan cache
-- OPTIon (RECOMPILE) tells SQL Server that this particular plan is a �single-use plan� that should not be reused for subsequent users
-- OPTION (RECOMPILE) to force SQL Server to get a new plan
SELECT  
qs.EXECUTION_COUNT, 
st.text,
query_plan,
sql_handle, 
plan_handle, 
DB_NAME(st.dbid) AS [DatabaseName],
cp.dbid, 
creation_time,
last_execution_time,
total_rows,
total_grant_kb,
total_worker_time,
total_logical_reads,
total_physical_reads,
cp.* , 
qs.*
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_sql_text(sql_handle) AS st
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS cp
--WHERE st.text like '%Alert_Blocking%'  OPTION (RECOMPILE);
WHERE OBJECT_NAME (st.objectid) LIKE N'Alert_Blocking' OPTION (RECOMPILE); 
GO
--
SELECT cp.plan_handle, 
cp.objtype, 
cp.usecounts, 
DB_NAME(st.dbid) AS [DatabaseName]
FROM sys.dm_exec_cached_plans AS cp 
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st 
WHERE OBJECT_NAME (st.objectid) LIKE N'%Alert_Blocking%' OPTION (RECOMPILE)
DBCC FREEPROCCACHE [ ( { plan_handle | sql_handle | pool_name } ) ] [ WITH NO_INFOMSGS ] 
DBCC FREEPROCCACHE (0x050011007A2CC30E204991F000000000000000000000000000000000000000);

-- Flush the entire plan cache for one resource pool
-- Get Resource Pool information
SELECT name AS [Resource Pool Name], 
cache_memory_kb/1024.0 AS [cache_memory (MB)], 
used_memory_kb/1024.0 AS [used_memory (MB)]
FROM sys.dm_resource_governor_resource_pools;

-- Flush the plan cache for one resource pool
DBCC FREEPROCCACHE ('LimitedIOPool');
GO







-- Example 2 ***********************
-- Flush the ad hoc and prepared plan cache for the entire instance
DBCC FREESYSTEMCACHE ('ALL') WITH MARK_IN_USE_FOR_REMOVAL--MARK_IN_USE_FOR_REMOVAL clause releases entries from all current caches once the entries become unused.
DBCC FREESYSTEMCACHE ('Temporary Tables & Table Variables')
DBCC FREESYSTEMCACHE ('userdatabase')
DBCC FREESYSTEMCACHE ('tempdb')

-- Flush the ad hoc and prepared plan cache for one resource pool
-- Get Resource Pool information
SELECT name AS [Resource Pool Name], 
cache_memory_kb/1024.0 AS [cache_memory (MB)], 
used_memory_kb/1024.0 AS [used_memory (MB)]
FROM sys.dm_resource_governor_resource_pools;

-- Flush the ad hoc and prepared plan cache for one resource pool
DBCC FREESYSTEMCACHE ('SQL Plans', 'Object Plans', 'LimitedIOPool');








-- Example 3 **********************
-- Remove all elements from the plan cache for one database (does not work in SQL Azure) 
-- Get DBID from one database name first
--decreases LOGICAL READS
Use Master; 
Declare @dbid int = db_ID() 
-- Flush the plan cache for one database only
DBCC FLUSHPROCINDB (@dbId)





-- Example 3 **********************
-- New in SQL Server 2016 and SQL Azure
USE Master;
GO
-- Clear plan cache for the current database
ALTER DATABASE SCOPED CONFIGURATION 
CLEAR PROCEDURE_CACHE;





-- Example 4 **********************
--Flushes the distributed query connection cache used by distributed queries against an instance of SQL Server
DBCC FREESESSIONCACHE WITH NO_INFOMSGS;
GO




-- Example 5 **********************
--DBCC FLUSHAUTHCACHE flushes the database authentication cache maintained information regarding login and firewall rules for the current user database.
--This command cannot run in the master database, because the master database maintains the physical storage information regarding login and firewall rules.
DBCC FLUSHAUTHCACHE [;]





-- Example 6 **********************
-- For specific objects that are cached, we can pass a procedure name, trigger, 
--table, view, function in the current database and it will be recompiled next time it is run
EXEC sp_recompile N'Object';
EXEC sp_recompile N'myprocedure';
EXEC sp_recompile N'myprocedure';
EXEC sp_recompile N'mytable';




-- Example 7 **********************
-- Clear Dirty Pages
Checkpoint
Go



-- Example 8  **********************
-- Clear Clean Pages
--WITH NO_INFOMSGS: Suppresses all informational messages. Informational messages are always suppressed on SQL Data Warehouse and Parallel Data Warehouse.
--COMPUTE: Purge the query plan cache from each Compute node.
--ALL: Purge the query plan cache from each Compute node and from the Control node. This is the default if you do not specify a value.
DBCC DropCleanBuffers()
DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS 
DBCC DROPCLEANBUFFERS ( COMPUTE | ALL ) [ WITH NO_INFOMSGS ]


