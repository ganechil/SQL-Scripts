SET IDENTITY_INSERT PersonSessionWebKey ON
INSERT INTO weyi.dbo.PersonSessionWebKey ( --21604597
	--[Id]
	[PersonSessionId]
	,[WebKey]
	,[WebKeyTypeCodeId]
	,[Expired]
	,[LastAccess]
	,[ExpirationSeconds]
	,[CreateDate]
	,[LastUpdate]
	)
SELECT top 10 --a.Id
	a.PersonSessionId
	,a.WebKey
	,a.WebKeyTypeCodeId
	,a.Expired
	,a.LastAccess
	,a.ExpirationSeconds
	,a.CreateDate
	,a.LastUpdate
FROM [VoyceReport].[dbo].[zzzPersonSessionWebKey] a(NOLOCK)
order by id desc
SET IDENTITY_INSERT PersonSessionWebKey Off


DECLARE @count INT 
SET @count = 1
Declare @RandomWebKeyTypeCodeId int
Declare @LowerLimitForWebKeyTypeCodeId int
Declare @UpperLimitForWebKeyTypeCodeId int
Set @LowerLimitForWebKeyTypeCodeId = 1
Set @UpperLimitForWebKeyTypeCodeId = 10
WHILE @count <= 100 
BEGIN
Select @RandomWebKeyTypeCodeId = Round(((@UpperLimitForWebKeyTypeCodeId - @LowerLimitForWebKeyTypeCodeId) * Rand()) + @LowerLimitForWebKeyTypeCodeId, 0)
INSERT INTO weyi.dbo.PersonSessionWebKey(      
	   [PersonSessionId]
      ,[WebKey]
      ,[WebKeyTypeCodeId]
      ,[Expired]
      ,[LastAccess]
      ,[ExpirationSeconds]
      ,[CreateDate]
      ,[LastUpdate])
	  Values(
        @count, 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97)  , 
			 @RandomWebKeyTypeCodeId ,
			CASE WHEN DATEPART(MILLISECOND, GETDATE()) >= 500 THEN 0 ELSE 1 END  ,
            DATEADD(MILLISECOND, (ABS(CHECKSUM(NEWID())) % 6000) * -1,
                DATEADD(MINUTE, (ABS(CHECKSUM(NEWID())) % 1000000) * -1, GETDATE())) , 
		9999999,
		
			DATEADD(MILLISECOND, (ABS(CHECKSUM(NEWID())) % 6000) * -1, 
                DATEADD(MINUTE, (ABS(CHECKSUM(NEWID())) % 1000000) * -1, GETDATE()))  , 
				DATEADD(MILLISECOND, (ABS(CHECKSUM(NEWID())) % 6000) * -1, 
                DATEADD(MINUTE, (ABS(CHECKSUM(NEWID())) % 1000000) * -1, GETDATE()))   )
    SET @count += 1
END










DECLARE @count INT 
SET @count = 1

declare @personid int 
set @personid = 115447395

Declare @RandomLanguageId int
Declare @LowerLimitForLanguageId int
Declare @UpperLimitForLanguageId int
Set @LowerLimitForLanguageId = 1
Set @UpperLimitForLanguageId = 999

WHILE @count <= 10
BEGIN

--SET IDENTITY_INSERT Request ON
INSERT INTO weyi.dbo.Request ( --21604597
	--[Id]
	 [PersonId]
      ,[LanguageId] --
      ,[SituationCodeId]
      ,[Note]
      ,[RequestStatusCodeId] --
      ,[ProviderId]
      ,[ProviderRate]
      ,[Amount]
      ,[TotalTime]
     -- ,[Version]
      ,[CreateDate]
      ,[LastUpdate]
	)
SELECT top 1 --a.Id
		 @personid  as [PersonId]
      , Round(((@UpperLimitForLanguageId - @LowerLimitForLanguageId) * Rand()) + @LowerLimitForLanguageId, 0) as [LanguageId] 
      ,[SituationCodeId]
      ,[Note]
      ,1 --
      ,[ProviderId]
      ,[ProviderRate]
      ,[Amount]
      ,[TotalTime]
     -- ,[Version]
      ,getdate()
      ,getdate()
FROM  weyi.dbo.Request a(NOLOCK)

SET @count += 1
set @personid +=1

end
--SET IDENTITY_INSERT Request Off













--  ALTER TABLE [dbo].[PersonSessionWebKey] Drop CONSTRAINT [FK_PersonSessionWebKey_PersonSession]   GO 

 --   ALTER TABLE [dbo].[PersonSessionWebKey] WITH NOCHECK 
	--ADD CONSTRAINT [FK_PersonSessionWebKey_PersonSession] 
	--FOREIGN KEY(PersonSessionId) 
	--REFERENCES [dbo].[PersonSession](Id)   
	
--	GO  ALTER TABLE [dbo].[PersonSessionWebKey] WITH NOCHECK CONSTRAINT [FK_PersonSessionWebKey_PersonSession]  GO


--	ALTER TABLE [dbo].[PersonSessionWebKey]  WITH CHECK 
--	ADD  CONSTRAINT [FK_PersonSessionWebKey_PersonSession] 
--	FOREIGN KEY([PersonSessionId])
--REFERENCES [dbo].[PersonSession] ([Id])
--GO

--ALTER TABLE [dbo].[PersonSessionWebKey] CHECK CONSTRAINT [FK_PersonSessionWebKey_PersonSession]
--GO



--  ALTER TABLE [dbo].[PersonSessionWebKey] NOCHECK CONSTRAINT FK_PersonSessionWebKey_PersonSession  Go 	 
  
--  ALTER TABLE [dbo].[PersonSessionWebKey] WITH CHECK CHECK CONSTRAINT FK_PersonSessionWebKey_PersonSession   GO 



				select SCOPE_IDENTITY()
				select @@IDENTITY