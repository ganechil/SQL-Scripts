 
----MODIFIED BY ME
----https://sqlstudies.com/2016/06/29/finding-disabling-and-enabling-foreign-keys/
--SELECT name AS ForeignKey_Name,
--    object_schema_name(referenced_object_id) Parent_Schema_Name,
--    object_name(referenced_object_id) Parent_Object_Name,
--    object_schema_name(parent_object_id) Child_Schema_Name,
--    object_name(parent_object_id) Child_Object_Name,
--    STUFF((SELECT ', ' + c.name
--                FROM sys.foreign_key_columns fkc
--                JOIN sys.columns c
--                    ON fkc.parent_object_id = c.object_id
--                    AND fkc.parent_column_id = c.column_id
--                WHERE fkc.constraint_object_id = sys.foreign_keys.object_id
--                ORDER BY constraint_column_id
--                FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)')
--            , 1, 2, '') AS ColumnList,
--    is_disabled, is_not_trusted,
--	DB_NAME() AS DataBaseName,
--	 '
--ALTER TABLE ' + quotename(object_schema_name(parent_object_id)) + '.' +
--               quotename(object_name(parent_object_id)) + ' NOCHECK CONSTRAINT ' + 
--               object_name(object_id) + '
--Go ' AS DisableConstrant,
--	 '
--ALTER TABLE ' + quotename(object_schema_name(parent_object_id)) + '.' +
--               quotename(object_name(parent_object_id)) + ' WITH CHECK CHECK CONSTRAINT ' + 
--               object_name(object_id) + ' 
--GO ' AS EnableConstrant,
--    '
--ALTER TABLE ' + quotename(object_schema_name(parent_object_id)) + '.' +
--               quotename(object_name(parent_object_id)) + ' Drop CONSTRAINT '  +
--               quotename(object_name(object_id)) + ' 
--GO ' AS DropConstratn,
--    '
--ALTER TABLE ' + quotename(object_schema_name(parent_object_id)) + '.' +
--               quotename(object_name(parent_object_id)) + ' WITH NOCHECK ADD CONSTRAINT ' + 
--               quotename(object_name(object_id)) + ' FOREIGN KEY' + 
--			    quotename(STUFF((SELECT ', ' + c.name
--                FROM sys.foreign_key_columns fkc
--                JOIN sys.columns c
--                    ON fkc.parent_object_id = c.object_id
--                    AND fkc.parent_column_id = c.column_id
--                WHERE fkc.constraint_object_id = sys.foreign_keys.object_id
--                ORDER BY constraint_column_id
--                FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)')
--            , 1, 2, ''), '()') +
--			' REFERENCES ' +
--			 quotename(object_schema_name(referenced_object_id)) + '.' +
--			 quotename(object_name(referenced_object_id)) + 
--			 quotename(STUFF((SELECT ', ' + c.name
--                FROM sys.foreign_key_columns fkc
--                JOIN sys.columns c
--                    ON fkc.parent_object_id = c.object_id
--                    AND fkc.parent_column_id = c.column_id
--                WHERE fkc.constraint_object_id = sys.foreign_keys.object_id
--                ORDER BY constraint_column_id
--                FOR XML PATH(''),TYPE).value('.','VARCHAR(MAX)')
--            , 1, 2, ''), '()') + ' 
--GO' +

--'
--ALTER TABLE ' + quotename(object_schema_name(parent_object_id)) + '.' +
--               quotename(object_name(parent_object_id)) + ' WITH NOCHECK CONSTRAINT ' + 
--               quotename(object_name(object_id)) + '
--GO'
--			 AS AddConstrant
----ALTER TABLE [MDE].[SampleLocation] WITH NOCHECK ADD CONSTRAINT [FacilityMaster_MDESampleLocation_FK1] FOREIGN KEY([FacilityID]) REFERENCES [dbo].[FacilityMaster] ([FacilityID])
--FROM sys.foreign_keys
----order by Parent_Object_Name
---- Include this WHERE clause to pull the foreign keys for a single table (parent & child).
--WHERE parent_object_id = object_id('dbo.PersonSessionWebKey ')
-- -- OR referenced_object_id = object_id('mde.MDEParameterEntry ')
-- -- or name = 'FacilityMaster_MDESampleLocation_FK1'
--  order by Parent_Object_Name 

--DBCC CHECKIDENT(PersonSessionWebKey, Reseed, 6011674)


 --SET IDENTITY_INSERT PersonSessionWebKey Off
DECLARE @count INT 
SET @count = 1
Declare @RandomWebKeyTypeCodeId int
Declare @LowerLimitForWebKeyTypeCodeId int
Declare @UpperLimitForWebKeyTypeCodeId int
Set @LowerLimitForWebKeyTypeCodeId = 1
Set @UpperLimitForWebKeyTypeCodeId = 10
Select @RandomWebKeyTypeCodeId = Round(((@UpperLimitForWebKeyTypeCodeId - @LowerLimitForWebKeyTypeCodeId) * Rand()) + @LowerLimitForWebKeyTypeCodeId, 0)
  INSERT INTO weyi.dbo.PersonSessionWebKey(   
  [PersonSessionId]
      ,[WebKey]
      ,[WebKeyTypeCodeId]
      ,[Expired]
      ,[LastAccess]
      ,[ExpirationSeconds]
      ,[CreateDate]
      ,[LastUpdate])
	  Values(
	  
	  5252185,
	  CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + 
            CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97) + CHAR((ABS(CHECKSUM(NEWID())) % 26) + 97)  ,
			@RandomWebKeyTypeCodeId ,
			CASE WHEN DATEPART(MILLISECOND, GETDATE()) >= 500 THEN 0 ELSE 1 END  ,
            DATEADD(MILLISECOND, (ABS(CHECKSUM(NEWID())) % 6000) * -1,
                DATEADD(MINUTE, (ABS(CHECKSUM(NEWID())) % 1000000) * -1, GETDATE())) , 
		9999999,
		
			DATEADD(MILLISECOND, (ABS(CHECKSUM(NEWID())) % 6000) * -1, 
                DATEADD(MINUTE, (ABS(CHECKSUM(NEWID())) % 1000000) * -1, GETDATE()))  , 
				DATEADD(MILLISECOND, (ABS(CHECKSUM(NEWID())) % 6000) * -1, 
                DATEADD(MINUTE, (ABS(CHECKSUM(NEWID())) % 1000000) * -1, GETDATE()))   )



				select SCOPE_IDENTITY()
				select @@IDENTITY
