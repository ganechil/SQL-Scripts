
SELECT database_name,
type = ( 
            CASE type
            when 'D' then 'FULL DB BACKUP'
            when 'I' then 'DIFFERENTIAL Backup'
            when 'L' then 'Log Backup'
	    when'F' then 'File or filegroup' 
	    when'G' then 'Differential file' 
	    when'P' then 'Partial' 
	    when'Q' then 'Differential partial' 
            END
		),
--backup_start_date,
backup_finish_date,
CAST((CAST(DATEDIFF(s, backup_start_date, backup_finish_date) AS int))/3600 AS varchar) + ' hours, ' 
+ CAST((CAST(DATEDIFF(s, backup_start_date, backup_finish_date) AS int))/60 AS varchar)+ ' minutes, '
+ CAST((CAST(DATEDIFF(s, backup_start_date, backup_finish_date) AS int))%60 AS varchar)+ ' seconds' 
AS [Total Time],
first_lsn,
last_lsn, 
checkpoint_lsn,
database_backup_lsn,
differential_base_lsn,
backup_size/1024/1024/1024 as backup_size_inGB,
compressed_backup_size/1024/1024/1024 as compressed_backup_inGB,
user_name,
physical_device_name
--from msdb..backupset bs, msdb..backupmediafamily bm
FROM msdb.dbo.backupset
  INNER JOIN msdb.dbo.backupmediaset ON backupset.media_set_id = backupmediaset.media_set_id
  INNER JOIN msdb.dbo.backupmediafamily ON backupset.media_set_id = backupmediafamily.media_set_id
WHERE backup_start_date>'2023-10-02 21:30:00.000'
and database_name='SolarWindsOrion' -- Optional, you can give a suitable time
and last_lsn = '263029000000449000001'
-- group by database_name
order by backup_finish_date desc, type





RESTORE DATABASE [SolarWindsOrion] 
--FROM DISK = 'S:\LSCopySolarWindsOrion\SolarWindsOrion-Differential Database Backup_201910050020001' 
--WITH  FILE = 1,  
--STANDBY = N'D:\Program Files\Microsoft SQL Server\MSSQL11.PRDMEDB\MSSQL\Backup\SolarWindsOrion_RollbackUndo_2019-10-05_01-16-56.bak',  
WITH STANDBY = N'S:\LSCopySolarWindsOrion\SolarWindsOrion-Differential Database Backup_201910050020001'

RESTORE DATABASE [SolarWindsOrion]  
FROM DISK = 'S:\LSCopySolarWindsOrion\SolarWindsOrion-Differential Database Backup_201910050020001' 
--WITH  FILE = 1, 
--STANDBY = N'D:\Program Files\Microsoft SQL Server\MSSQL11.PRDMEDB\MSSQL\Backup\SolarWindsOrion_RollbackUndo_2019-10-05_01-16-56.bak',  
WITH STANDBY = N'S:\LSCopySolarWindsOrion\SolarWindsOrion-Differential Database Backup_201910050020001'--,
/*
move 'SolarWindsOrion' to 'E:\SolarwindsDB_Part2\DATA\SolarWindsOrion.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\Cortex_documents1.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\Cortex_documents2.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\Cortex_documents3.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\Cortex_documents4.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\SolarWindsOrion_FG1.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\SolarWindsOrion_FG2.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\SolarWindsOrion_FG3.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\DATA\SolarWindsOrion_FG4.mdf',
move 'SolarWindsOrion' to 'U:\SolarwindsDB_Part2\LOG\SolarWindsOrion_log.ldf'
go
*/






SELECT 
   secondary_server,
   secondary_database,
   primary_server,
   primary_database,
   last_copied_file,
   last_copied_date,
   last_restored_file,
   last_restored_date
FROM msdb.dbo.log_shipping_monitor_secondary
order by last_restored_date desc



---Check the Current SQL Server Log Shipping Mode
--- If the restore_mode value is 1 then it is in Standby mode and if it is 0 then it is in Restoring mode.
SELECT 
   secondary_database,
   restore_mode,
   disconnect_users,
   last_restored_file
FROM msdb.dbo.log_shipping_secondary_databases


---Do Not use if not familarChange a SQL Server Log Shipping Database to Read-Only
EXEC sp_change_log_shipping_secondary_database
  @secondary_database = 'Collection',
  @restore_mode = 1,
  @disconnect_users = 1



---Using sys.database_recovery_status:
SELECT 
	last_log_backup_lsn
FROM sys.database_recovery_status
WHERE database_id = 5



---Using Restore with HeaderOnly option:
RESTORE HEADERONLY FROM DISK = 'C:\Temp\MyFull.bak'
RESTORE HEADERONLY FROM DISK = 'C:\Temp\MyTran01.trn'









REVERSE LOG SHIPPING
====================

1. Disable the Log Shipping Jobs on the Primary and Secondary Server.
2. Make sure all the log backups taken on the primary were copied on to the Network Folder and restored on to the Secondary. If not, apply them.
3. Backup the Tail log on the primary with no recovery. This will set the primary database in �restoring mode�.
4. Apply the tail log backup on the primary with recovery. This brings the secondary database online.
�To reverse the role��
5. Configure the New Secondary database as Primary Log Shipping Database just like Initial Log shipping configuration.
6. Instead of the creating the secondary database from scratch, select �No. 
The secondary database is initialized� while creating the secondary database and choose the secondary database from the drop down.
7. Choose the restoring as per your need either restoring or stand by. 
I prefer standby mode as users can connect to it but it purely depends on the purpose of doing Log Shipping , 
i.e. is it just for high availability or for both(HA + Offload the query distribution like reporting).