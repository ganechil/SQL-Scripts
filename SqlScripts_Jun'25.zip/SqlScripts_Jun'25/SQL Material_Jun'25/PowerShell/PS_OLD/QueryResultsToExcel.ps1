﻿# This PowerShell script runs query converts results to Excel spreadsheet
# Copy contents of this script or download this script & save it to F:\projects
# use sqlps.exe to run this script
# sqlps.exe F:\projects\QueryResultsToExcel.ps1

$query1 = "Select ServerProperty('ServerName') As ServerName, Name, CrDate from SysDatabases"

$csvFilePath = "F:\projects\QueryResultsToExcel.csv"
$excelFilePath = "F:\projects\QueryResultsToExcel.xls"

# Run Query against multiple Servers, combine results
# Replce "." with names of your SQL Server instances Example machineName\instance1
$instanceName = "GANESH\SQL14INST"
$results = Invoke-Sqlcmd -Query $query1 -ServerInstance $instanceName

# Output to CSV
Write-Host "Saving Query Results in CSV format..."

$results | Export-Csv $csvFilePath -NoTypeInformation

# Convert CSV file to Excel
# Refernce : http://gallery.technet.microsoft.com/
Write-Host "Converting CSV output to Excel...."
$excel = New-Object -ComObject excel.application
$excel.visible = $true
$excel.displayalerts = $fale
$workbook = $excel.Workbooks.Open($csvFilePath)

$workSheet = $workbook.worksheets.Item(1)
$resize = $workSheet.UsedRange
$resize.EntireColumn.AutoFit() | Out-Null
$xlExcel8 = 56
$workbook.SavesAs($excelFilePath,$xlExcel8)
$Sheet = $excel.WorkSheets.Item(1)
$workbook.Close()
$excel.quit()
$excel = $null

Write-Host "Results are savved in Excel file:" $excelFilePath

