﻿$query = "Select ServerProperty('ServerName') As ServerName, Name, CrDate from SysDatabases"

#Edit these peramters for the server this will be running on#
$smtpServer = "smtp.gmail.com";
$smtpFrom = "ganeshre.educomp@gmail.com";
$smtpTo = "ganeshre.educomp@gmail.com”
$messageSubject = "I3 Report";

#create anonymus loging for sending e-mail#
$User = "anonymous";
$PWord = ConvertTo-SecureString -String "anonymous" -AsPlainText -Force
$Creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user, $pword


$date = (Get-Date).AddDays(-1).ToString('yyyy-MM-dd')
$date = $date+"_I3Report.xls";

$csvFilePath = "F:\projects\queryresults.csv"
$excelFilePath = "F:\projects\$date"


$instanceName = "*server*"
Import-Module "sqlps"
$results = Invoke-Sqlcmd -QueryTimeout 7200 -Query $query -ServerInstance $instanceName

# Output to CSV
$results | export-csv  $csvFilePath -Delimiter "    " -NoTypeInformation
#this line will remove all the quotation marks from the csv file
(Get-Content $csvFilePath) | % {$_ -replace '"', ""} | out-file -FilePath $csvFilePath -Force 

# Convert CSV file to Excel


$excel = New-Object -ComObject excel.application 
$excel.visible = $False 
$excel.displayalerts=$False 
$workbook = $excel.Workbooks.Open($csvFilePath) #<-- Program fails here
$workSheet = $workbook.worksheets.Item(1) 
#$workSheet.cells.item(3,3) = "HOPLA"

#for freezing pane#
$workSheet.application.activewindow.splitcolumn = 0
$workSheet.application.activewindow.splitrow = 1
$workSheet.Range("A2").application.activewindow.freezepanes = $true
$resize = $workSheet.UsedRange 
$resize.EntireColumn.AutoFit() | Out-Null 
$xlExcel8 = 43
$workbook.SaveAs($excelFilePath, $xlExcel8)
$workbook.Close()
$excel.quit() 
$excel = $null

send-mailmessage -from $smtpFrom -to $smtpTo -subject "$messageSubject" -body "Attachment" -Attachments $excelFilePath -smtpServer $smtpServer -Credential $creds;
