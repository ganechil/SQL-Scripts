﻿ $service=get-service "SQLAgent*","SQLBrowser","MSSQL*","ReportServer*"
 $hostName=$env:computername
    if ($Service.Status -ne "Running") {
    $Body ="MS SQL Service(s) are not running on $hostName"
    }
    else {
      $Body = "MS SQL Service(s) is running on $hostName"
    }

    $From = "ganeshre.educomp@gmail.com"
    $To = "ganeshre.educomp@gmail.com"
    $SMTPServer = "smtp.gmail.com"
    $SMTPPort = "465"
    $Username = "ganeshre.educomp@gmail.com"
    $Password = "bc77ganesh1"
    $Body =$body
    $Subject = "$computer$ MS SQL Services Stopped"
    $smtp = New-Object System.Net.Mail.SmtpClient($SMTPServer, $SMTPPort);
    $smtp.EnableSSL = $false
    $smtp.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
    if ($Service.Status -ne "Running") {
    $smtp.Send($From, $To, $subject, $body);
    }
    $computer = $env:computername