
#some variables

$serverName = "GANESH\SQL14INST";

$databaseName = "PowerShell";




#the save location for the new Excel file
$filepath = "F:\projects\excelexport023.xls";

 





#create excel object

$excel = New-Object -ComObject Excel.Application

$workbook = $excel.Workbooks.add()

$worksheetA = $workbook.Worksheets.Add()





#create byUser worksheet
$sheet1 = $workbook.worksheets.Item(1)

$sheet1.name = "Sheet_Name"

 



#create a Dataset to store the DataTable 

$dataSet = new-object "System.Data.DataSet" "Sheet_Name"

 







#create a Connection to the SQL Server database

$cn = new-object System.Data.SqlClient.SqlConnection "server=$serverName;database=$databaseName;Integrated Security=sspi"

$query= "USE MASTER  
SELECT @@SERVERNAME Servername,  
CONVERT(VARCHAR(25), DB.name) AS dbName,  
CONVERT(VARCHAR(10), DATABASEPROPERTYEX(name, 'status')) AS [Status],  
(SELECT COUNT(1) FROM sysaltfiles WHERE DB_NAME(dbid) = DB.name AND groupid !=0 ) AS DataFiles,  
(SELECT SUM((size*8)/1024) FROM sysaltfiles WHERE DB_NAME(dbid) = DB.name AND groupid!=0) AS [Data MB],  
(SELECT COUNAT(1) FROM sysaltfiles WHERE DB_NAME(dbid) = DB.name AND groupid=0) AS LogFiles,  
(SELECT SUM((size*8)/1024) FROM sysaltfiles WHERE DB_NAME(dbid) = DB.name AND groupid=0) AS [Log MB],  
(SELECT SUM((size*8)/1024) FROM sysaltfiles WHERE DB_NAME(dbid) = DB.name AND groupid!=0)+(SELECT SUM((size*8)/1024) FROM sysaltfiles WHERE DB_NAME(dbid) = DB.name AND groupid=0) TotalSizeMB,  
convert(sysname,DatabasePropertyEx(name,'Updateability'))  Updateability,  
convert(sysname,DatabasePropertyEx(name,'UserAccess')) UserAccess ,  
convert(sysname,DatabasePropertyEx(name,'Recovery')) RecoveryModel ,  
convert(sysname,DatabasePropertyEx(name,'Version')) Version ,  
CASE cmptlevel  
WHEN 60 THEN '60 (SQL Server 6.0)'  
WHEN 65 THEN '65 (SQL Server 6.5)'  
WHEN 70 THEN '70 (SQL Server 7.0)'  
WHEN 80 THEN '80 (SQL Server 2000)'  
WHEN 90 THEN '90 (SQL Server 2005)'  
WHEN 100 THEN '100 (SQL Server 2008)'  
END AS [compatibility level],  
CONVERT(VARCHAR(20), crdate, 103) + ' ' + CONVERT(VARCHAR(20), crdate, 108) AS [Creation date],  
ISNULL((SELECT TOP 1  
CASE TYPE WHEN 'D' THEN 'Full' WHEN 'I' THEN 'Differential' WHEN 'L' THEN 'Transaction log' END + ' � ' +  
LTRIM(ISNULL(STR(ABS(DATEDIFF(DAY, GETDATE(),Backup_finish_date))) + ' days ago', 'NEVER')) + ' � ' +  
CONVERT(VARCHAR(20), backup_start_date, 103) + ' ' + CONVERT(VARCHAR(20), backup_start_date, 108) + ' � ' +  
CONVERT(VARCHAR(20), backup_finish_date, 103) + ' ' + CONVERT(VARCHAR(20), backup_finish_date, 108) +  
' (' + CAST(DATEDIFF(second, BK.backup_start_date,  
BK.backup_finish_date) AS VARCHAR(4)) + ' '+ 'seconds)'  
FROM msdb.dbo.backupset BK WHERE BK.database_name = DB.name ORDER BY backup_set_id DESC),'-') AS [Last backup]  
FROM sysdatabases DB  
ORDER BY dbName, [Last backup] DESC, NAME ;"












#Create a SQL Data Adapter to place the resultset into the DataSet

$dataAdapter = new-object "System.Data.SqlClient.SqlDataAdapter" ($query, $cn)

$dataAdapter.Fill($dataSet) | Out-Null






#close the connection

$cn.Close()

 

$dataTable = new-object "System.Data.DataTable" "Principals"

$dataTable = $dataSet.Tables[0]




 

#assign  column names

$sheet1.cells.item(1, 1) =  "Servername"

$sheet1.cells.item(1, 2) =   "dbName"

$sheet1.cells.item(1, 3) =  "Status"

$sheet1.cells.item(1, 4) =  "DataFiles"

$sheet1.cells.item(1, 5) =  "Data MB"

$sheet1.cells.item(1, 6) =  "LogFiles"

$sheet1.cells.item(1, 7) =  "Log MB"

$sheet1.cells.item(1, 8) =  "TotalSizeMB"

$sheet1.cells.item(1, 9) =  "Updateability"

$sheet1.cells.item(1, 10) =  "UserAccess"

$sheet1.cells.item(1, 11) =  "RecoveryModel"

$sheet1.cells.item(1, 12) =  "Version"

$sheet1.cells.item(1, 13) =  "compatibility level"

$sheet1.cells.item(1, 14) =  "Creation date"

$sheet1.cells.item(1, 15) =  "Last backup"
 




#iterate through every DataTable line item and insert to the Excel worksheet





##Note: starts at 2 as 1 is the column headers

$x=2

$dataTable | FOREACH-OBJECT{

 




$sheet1.cells.item($x, 1) =  $_.Servername

$sheet1.cells.item($x, 2) =  $_.dbName

$sheet1.cells.item($x, 3) =  $_.Status

$sheet1.cells.item($x, 4) =  $_.DataFiles

$sheet1.cells.item($x, 5) =  "$_.Data MB"

$sheet1.cells.item($x, 6) =  $_.LogFiles

$sheet1.cells.item($x, 7) =  "$_.Log MB"

$sheet1.cells.item($x, 8) =  $_.TotalSizeMB

$sheet1.cells.item($x, 9) =  $_.Updateability

$sheet1.cells.item($x, 10) =  $_.UserAccess

$sheet1.cells.item($x, 11) =  $_.RecoveryModel

$sheet1.cells.item($x, 12) =  $_.Version

$sheet1.cells.item($x, 13) =  "$_.compatibility level"

$sheet1.cells.item($x, 14) =  "$_.Creation date"

$sheet1.cells.item($x, 15) =  "$_.Last backup"
$x++

 

}

 

 

 

$range1 = $sheet1.UsedRange

$range1.EntireColumn.AutoFit()





 

#save excel worksbook

$excel.ActiveWorkbook.SaveAs("$filepath ")

$excel.quit()