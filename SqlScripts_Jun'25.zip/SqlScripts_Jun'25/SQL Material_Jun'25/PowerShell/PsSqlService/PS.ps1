 $service=Get-Service "SQL*"
 $hostName=$env:computername
    if ($Service.Status -ne "Running") {
    $Body ="Service(s) are not running on $hostName"
    }
    else {
      $Body = "Service(s) is running on $hostName"
    }

    $From = "sqlsupport@ncdex.com"
    $To = "sqlsupport@ncdex.com"
    $SMTPServer = "172.30.2.171"
    $SMTPPort = "25"
    $Username = "sqlsupport@ncdex.com"
    $Password = "get35@sql"
    $Body =$body
    $Subject = "$computer$ status"
    $smtp = New-Object System.Net.Mail.SmtpClient($SMTPServer, $SMTPPort);
    $smtp.EnableSSL = $false
    $smtp.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
    if ($Service.Status -ne "Running") {
    $smtp.Send($From, $To, $subject, $body);
    }
    $computer = $env:computername