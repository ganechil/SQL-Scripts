﻿#simple CSS Style
$style = 
@"
<style type='text/css'>
td {border:1px solid gray;}
.offline{background-color: #E01B1B;}
</style>
"@
 

#Import SQL Module
Import-Module SQLPS -DisableNameChecking
 

function Get-DBStatus {
   <# [CmdletBinding()]
    param (
        [Parameter(Mandatory=$True)][string]$Servername
    )#>
 
    $ServerList = Get-Content C:\PS\SQLServerHealthCheckScripts\Server1.txt
 
    Foreach ($serverName in $ServerList){
    
    #Create SMO Object
    $SQLServer = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $ServerName
 
   
 
    foreach ($db in $SQLServer.Databases){
     
     #Change text to read Online/Offline as opposed to "True" or "False"
    Switch ($db.IsAccessible) {
    "True" {$dbstatus = "Online"}
    "False" {$dbstatus = "Offline"}
    }
        #Properties of function
        $props = @{ 'Server' = $ServerName
                    'DbName' = $db.Name
                    'Status' = $dbstatus}
        New-Object -TypeName PSObject -Property $props
    }
 
 
    }
 
}
 
#let's get content from Get-Service and output this to styled HTML
Get-DBStatus | ConvertTo-Html -Property Server, DBName, Status -Title "Database Status" -PreContent "<h1>Database Status</h1>" -Head $style |
 
Foreach {
#if db is offline, use red background
if ($_ -like "*<td>Offline</td>*")
{
$_ -replace "<tr>", "<tr class='offline'>"
}
else
{
#display normally
$_
}
} |
Out-File "C:\PS\SQLServerHealthCheckScripts\db_status.html" -force
Set-Alias ie "$env:programfiles\Internet Explorer\iexplore.exe"
#ie "C:\PS\SQLServerHealthCheckScripts\Server.txt"
Send-MailMessage -to "sqlsupport@ncdex.com" -from "sqlsupport@ncdex.com" -Subject "DB Status" -SmtpServer "172.30.2.171" -Attachments "C:\PS\SQLServerHealthCheckScripts\Server.txt" -BodyAsHtml (Get-Content C:\PS\SQLServerHealthCheckScripts\Server.txt | Out-String)
 