﻿Function Get-ErrorLogPath 
{ 
  <# 
   .Synopsis 
    Returns the path to the SQL Error Log 
   .Description 
    This function returns the path to the SQL Error Log 
   .Example 
    Get-ErrorLogPath 
    Returns the path to the SQL Error Log on default instance of SQL on 
    local machine 
   .Example 
    Get-ErrorLogPath -SQLServer SQL1 
    Returns the path to the SQL Error Log on default instance of SQL on 
    a SQL server named SQL1 
   .Parameter SQLServer 
    The name and instance of SQL Server 
   .Notes 
    NAME:  Get-ErrorLogPath 
    AUTHOR: ed wilson, msft 
    LASTEDIT: 05/27/2011 11:34:59 
    KEYWORDS: Databases, SQL Server, Add-Type 
    HSG: HSG-5-31-11 
   .Link 
     Http://www.ScriptingGuys.com 
 #Requires -Version 2.0 
 #> 
 Param([string]$SQLServer = "(local)") 
 try { 
    add-type -AssemblyName "Microsoft.SqlServer.Smo,  
    Version=10.0.0.0, 
    Culture=neutral,  
    PublicKeyToken=89845dcd8080cc91" -EA Stop } 
 
 catch {add-type -AssemblyName "Microsoft.SqlServer.Smo"} 
 $server = new-object ("Microsoft.SqlServer.Management.Smo.Server") $SQLServer 
 $server.ErrorLogPath 
} #end function Get-ErrorLogPath

