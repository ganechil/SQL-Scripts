﻿# Drives to check: set to $null or empty to check all local (non-network) drives
# $drives = @("C","D");
$DiskDrives = $null;

# The minimum disk size to check for raising the warning
#$minSize = 48GB;
$minPct = 10;

# SMTP configuration: username, password & so on
$email_username = "sqlsupport@ncdex.com";
$email_password = "get35@sql";
$email_smtp_host = "172.30.2.171";
$email_smtp_port = 25;
$email_smtp_SSL = 0;
$email_from_address = "sqlsupport@ncdex.com";
$email_to_addressArray = @("sqlsupport@ncdex.com", "sysadmin@ncdex.com");



if ($DiskDrives -eq $null -Or $DiskDrives -lt 1) 
{
    $localVolumes = Get-WMIObject win32_volume;
    $DiskDrives = @();
    foreach ($vol in $localVolumes) 
    {
        if ($vol.DriveType -eq 3 -And $vol.DriveLetter -ne $null ) 
        {
            $DiskDrives += $vol.DriveLetter[0];
        }
    }
}


foreach ($Disk01 in $DiskDrives) 
{
    Write-Host ("`r`n");
    Write-Host ("Checking drive " + $Disk01 + " ...");
    $LocalDisk = Get-PSDrive $Disk01;

    #if ($LocalDisk.Free -lt $minSize) 
    if (((($LocalDisk.Free/1GB)/($LocalDisk.Used/1GB+$LocalDisk.Free/1GB))*100) -lt $minPct) 
    {
        Write-Host "  - [" -noNewLine
        Write-Host "Not Ok" -noNewLine -ForegroundColor Red
        Write-Host "] " -noNewLine
        Write-Host ("Drive " + $Disk01 + " has less than " + $minPct +"% free: sending e-mail... ");       
        $message = new-object Net.Mail.MailMessage;
        $message.From = $email_from_address;


        foreach ($to in $email_to_addressArray) 
        {
            $message.To.Add($to);
        }
        $message.Subject =  ("[WARNING]: " + $env:computername + " drive " + $Disk01);
        $message.Subject += (" has less than " + ($LocalDisk.Free/1GB).ToString(".00") +" GB");
        $message.Subject += ("(" + ((($LocalDisk.Free/1GB)/($LocalDisk.Used/1GB+$LocalDisk.Free/1GB))*100).ToString(".00") + "%)");
        $message.Body =     "Hello Team, `r`n`r`n";
        $message.Body +=    "This is an automatic e-mail message ";
        $message.Body +=    "sent by LowDiskSpaceMonitor_SendEmail_PS ";
        $message.Body +=    ("to inform you that " + $env:computername + " drive " + $Disk01 + " ");
        $message.Body +=    "is running low on free space.`r`n"
        $message.Body +=    "Please assign a medium priority ticket to the concern(App/DBA/SysAdmin) team for checking this drive. `r`n";
        $message.Body +=    "--------------------------------------------------------------";
        $message.Body +=    "`r`n";
        $message.Body +=    ("Machine HostName: " + $env:computername + " `r`n");
        $message.Body +=    "Machine IP Address(es): ";
        $ipAddresses = Get-NetIPAddress -AddressFamily IPv4;


        foreach ($ip in $ipAddresses) 
        {

            if ($ip.IPAddress -like "127.0.0.1") 
            {
                continue;
            }
            $message.Body += ($ip.IPAddress + " ");
        }
        $message.Body +=    "`r`n";
        $message.Body +=    ("Used_Space on drive " + $Disk01 + ": " + ($LocalDisk.Used/1GB).ToString(".00") +" GB `r`n");
        $message.Body +=    ("Free_Space on drive " + $Disk01 + ": " + ($LocalDisk.Free/1GB).ToString(".00") +" GB `r`n");
        $message.Body +=    ("Free Percent on drive " + $Disk01 + ": " + ((($LocalDisk.Free/1GB)/($LocalDisk.Used/1GB+$LocalDisk.Free/1GB))*100).ToString(".00") +"% `r`n");
        $message.Body +=    ("Total_Space on drive " + $Disk01 + ": " + ($LocalDisk.Used/1GB+$LocalDisk.Free/1GB).ToString(".00") +" GB `r`n");      
        $message.Body +=    "--------------------------------------------------------------";
        $message.Body +=    "`r`n`r`n";
        $message.Body +=    ("NOTE: This warning is fired from a Scheduled Task when the free space went below default threshold percent " + $minPct +"%, as described in the PS script. `r`n`r`n");
        $message.Body +=    "`r`n`r`n";
        $message.Body +=    "`r`n";
        $message.Body +=    "Sincerely, `r`n";
        $message.Body +=    "GaneshChilveri, `r`n";
        $message.Body +=    "SQLSupport`r`n";
        $message.Body +=     "NothingIsImpossible"
        $smtp = new-object Net.Mail.SmtpClient($email_smtp_host, $email_smtp_port);
        $smtp.EnableSSL = $email_smtp_SSL;
        $smtp.Credentials = New-Object System.Net.NetworkCredential($email_username, $email_password);
        $smtp.send($message);
        $message.Dispose();
        write-host "... E-Mail sent!" ; 
    }


    else 
    {
		Write-Host "  - [" -noNewLine
        Write-Host "Okay" -noNewLine -ForegroundColor Green
        Write-Host "] " -noNewLine
		Write-Host ("Drive " + $Disk01 + " has more than " + $minPct +"% free: nothing to do.")
    }
}