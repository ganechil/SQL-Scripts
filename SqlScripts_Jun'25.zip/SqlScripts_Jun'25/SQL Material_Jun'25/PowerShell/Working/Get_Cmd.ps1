﻿Get-Command | Select Name | Where-Object {$_.Name -like "*invoke*"} | Format-Table *
Get-Command | Select Name | Where-Object {$_.Name -eq "Get-SQLErrorLog"} | Format-List *
Get-Command | Select Name | Where-Object {$_.Name -eq "Export-Xls"} | Format-Table  *

Get-EventLog   -ComputerName @('VCSSQLDB01','abcd')  -LogName  Application   -EntryType  Error  -Source  '*sql*'  -After ((Get-Date).adddays(-1)) 
Get-EventLog   -ComputerName (Get-Content  'c:\temp\MyServers')  -LogName  Application   -EntryTpe  Error  -Source  '*sql*'  -After ((Get-Date).adddays(-1)) 

Get-SqlErrorLog  -sqlserver VCSSQLDB01\PRODSQL01

