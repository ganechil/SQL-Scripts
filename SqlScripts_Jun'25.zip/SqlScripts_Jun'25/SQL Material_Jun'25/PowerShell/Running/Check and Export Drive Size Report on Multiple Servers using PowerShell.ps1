﻿<#
https://morgantechspace.com/2014/12/powershell-script-to-get-disk-space-usage.html
#>
$DiskSizeReport = @()
#$computers = "pc1","hp-pc","svr1","svr2"
#$computers | ForEach {

Get-Content "C:\temp\computers.txt"  | ForEach-Object{
$os_name=$null
$os_version=$null
$errorMsg=''
Try
{
$os_name = (Get-WmiObject Win32_OperatingSystem -ComputerName $_ ).Caption
}
catch
{
$errorMsg=$_.Exception.Message
}

$Disks = Get-WmiObject win32_logicaldisk -ComputerName $_ -Filter "Drivetype=3" -ErrorAction SilentlyContinue |
Select-Object @{Label = "Server Name";Expression = {$_.SystemName}},
@{Label = "Drive Letter";Expression = {$_.DeviceID}},@{Label = "Total Capacity (GB)";Expression = {"{0:N1}" -f( $_.Size / 1GB)}},
@{Label = "Used Space (GB)";Expression = {(Round($_.Size /1GB,2)) - (Round($_.FreeSpace /1GB,2))}},
@{Label = "Free Space (GB)";Expression = {"{0:N1}" -f( $_.Freespace / 1GB ) }},@{Label = "Free Space (%)"; Expression = {"{0:P0}" -f ($_.freespace/$_.size) }}
$DiskSizeReport += $Disks
} 
$DiskSizeReport | Export-CSV "C:\temp\DiskSizeReport.csv" -NoTypeInformation -Encoding UTF8