--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--https://sqlworldwide.com/tsql-to-find-status-of-sql-server-statistics/
--https://sqlworldwide.com/tsql-to-find-status-of-sql-server-statistics/
IF Object_id('tempdb..#StatsInfo') IS NOT NULL
  DROP TABLE #statsinfo;
GO
IF Object_id('tempdb..#ColumnList') IS NOT NULL
  DROP TABLE #columnlist;
GO

DECLARE @object_id INT =NULL; 
--By default you get statistics status for whole database
--Uncomment below line if you are only looking at one table
--SET @object_id = OBJECT_ID(N'Sales.Invoices');
SELECT 
  ss.[name] AS SchemaName,
  obj.[name] AS TableName,
  DATEDIFF(d,STATS_DATE(stat.[object_id], stat.stats_id),getdate()) DaysOld,
  stat.[stats_id],
	stat.[name] AS StatisticsName,
  CASE
    WHEN stat.[auto_created] = 0
    AND stat.[user_created] = 0 THEN 'Index Statistic'
    WHEN stat.[auto_created] = 0
    AND stat.[user_created] = 1 THEN 'User Created'
    WHEN stat.[auto_created] = 1
    AND stat.[user_created] = 0  THEN 'Auto Created'
    WHEN stat.[auto_created] = 1
    AND stat.[user_created] = 1 THEN 'Updated stats available in Secondary'
  END AS StatisticType,
  CASE
    WHEN stat.[is_temporary] = 0 THEN 'Stats in DB'
    WHEN stat.[is_temporary] = 1 THEN 'Stats in Tempdb'
  END AS IsTemporary,
  CASE
    WHEN stat.[has_filter] = 1 THEN 'Filtered Index'
    WHEN stat.[has_filter] = 0 THEN 'No Filter'
  END AS IsFiltered,
  c.[name] AS ColumnName,
  stat.[filter_definition],
  sp.[last_updated],
  sp.[rows],
  sp.[rows_sampled],
  sp.[steps] AS HistorgramSteps,
  sp.[unfiltered_rows],
  sp.[modification_counter] AS RowsModified
INTO #statsinfo
FROM   
  sys.[objects] AS obj
  INNER JOIN sys.[schemas] ss
    ON obj.[schema_id] = ss.[schema_id]
  INNER JOIN sys.[stats] stat
    ON stat.[object_id] = obj.[object_id]
  JOIN sys.[stats_columns] sc
    ON sc.[object_id] = stat.[object_id]
    AND sc.[stats_id] = stat.[stats_id]
  JOIN sys.columns c
    ON c.[object_id] = sc.[object_id]
    AND c.[column_id] = sc.[column_id]
  CROSS apply sys.Dm_db_stats_properties(stat.object_id, stat.stats_id) AS sp
WHERE  
  ( obj.[is_ms_shipped] = 0
  AND obj.[object_id] = @object_id )
  OR ( obj.[is_ms_shipped] = 0 )
ORDER BY 
  ss.[name],
  obj.[name],
  stat.[name]; 

SELECT 
  t.[schemaname],
  t.[tablename],
  t.[stats_id],
  Stuff((SELECT ',' + s.[columnname]
FROM
  #statsinfo s
WHERE  
  s.[schemaname] = t.[schemaname]
  AND s.[tablename] = t.[tablename]
  AND s.stats_id = t.stats_id
FOR xml path('')), 1, 1, '') AS ColumnList
INTO   #columnlist
FROM   #statsinfo AS t
GROUP BY 
  t.[schemaname],
  t.[tablename],
  t.[stats_id]; 

SELECT DISTINCT 
  SI.[schemaname],
  SI.[tablename],
  SI.[DaysOld],
  SI.[stats_id],
  SI.[statisticsname],
  SI.[statistictype],
  SI.[istemporary],
  CL.[columnlist] AS ColumnName,
  SI.[isfiltered],
  SI.[filter_definition],
  SI.[rows],
  SI.[rows_sampled],
  SI.[historgramsteps],
  SI.[unfiltered_rows],
  SI.[last_updated],
  SI.[rowsmodified]
FROM   
	#statsinfo SI
  INNER JOIN #columnlist CL
  ON SI.[schemaname] = CL.[schemaname]
  AND SI.[tablename] = CL.[tablename]
  AND SI.[stats_id] = CL.[stats_id]
--where  SI.[tablename] = 'dimDistrictTargets'
ORDER BY 
  SI.[last_updated] desc, rowsmodified desc
GO





--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
-- Script - Find Details for Statistics of Whole Database
-- (c) Pinal Dave
-- Download Script from - https://blog.sqlauthority.com/contact-me/sign-up/
SELECT DISTINCT
OBJECT_NAME(s.[object_id]) AS TableName,
c.name AS ColumnName,
s.name AS StatName,
STATS_DATE(s.[object_id], s.stats_id) AS LastUpdated,
DATEDIFF(d,STATS_DATE(s.[object_id], s.stats_id),getdate()) DaysOld,
dsp.modification_counter,
s.auto_created,
s.user_created,
s.no_recompute,
s.[object_id],
s.stats_id,
sc.stats_column_id,
sc.column_id
FROM sys.stats s
JOIN sys.stats_columns sc
ON sc.[object_id] = s.[object_id] AND sc.stats_id = s.stats_id
JOIN sys.columns c ON c.[object_id] = sc.[object_id] AND c.column_id = sc.column_id
JOIN sys.partitions par ON par.[object_id] = s.[object_id]
JOIN sys.objects obj ON par.[object_id] = obj.[object_id]
CROSS APPLY sys.dm_db_stats_properties(sc.[object_id], s.stats_id) AS dsp
WHERE OBJECTPROPERTY(s.OBJECT_ID,'IsUserTable') = 1
AND (s.auto_created = 1 OR s.user_created = 1)
ORDER BY DaysOld Desc;






--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--New DMV For Statistics Info
SELECT [sch].[name] + '.' + [so].[name] AS [TableName] ,
[ss].[name] AS [Statistic],
[sp].[last_updated] AS [StatsLastUpdated] ,
[sp].[rows] AS [RowsInTable] ,
[sp].[rows_sampled] AS [RowsSampled] ,
[sp].[modification_counter] AS [RowModifications]
FROM [sys].[stats] [ss]
JOIN [sys].[objects] [so] ON [ss].[object_id] = [so].[object_id]
JOIN [sys].[schemas] [sch] ON [so].[schema_id] = [sch].[schema_id]
OUTER APPLY [sys].[dm_db_stats_properties]([so].[object_id],
[ss].[stats_id]) sp
WHERE [so].[type] = 'U'
AND [sp].[modification_counter] > 0--change accordingly
ORDER BY [sp].[last_updated] DESC;






--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
-- Script - Find Details for Statistics of Whole Database
-- (c) Pinal Dave
-- Download Script from - https://blog.sqlauthority.com/contact-me/sign-up/
SELECT DISTINCT
OBJECT_NAME(s.[object_id]) AS TableName,
c.name AS ColumnName,
s.name AS StatName,
STATS_DATE(s.[object_id], s.stats_id) AS LastUpdated,
DATEDIFF(d,STATS_DATE(s.[object_id], s.stats_id),getdate()) DaysOld,
dsp.modification_counter,
s.auto_created,
s.user_created,
s.no_recompute,
s.[object_id],
s.stats_id,
sc.stats_column_id,
sc.column_id
FROM sys.stats s
JOIN sys.stats_columns sc
ON sc.[object_id] = s.[object_id] AND sc.stats_id = s.stats_id
JOIN sys.columns c ON c.[object_id] = sc.[object_id] AND c.column_id = sc.column_id
JOIN sys.partitions par ON par.[object_id] = s.[object_id]
JOIN sys.objects obj ON par.[object_id] = obj.[object_id]
CROSS APPLY sys.dm_db_stats_properties(sc.[object_id], s.stats_id) AS dsp
WHERE OBJECTPROPERTY(s.OBJECT_ID,'IsUserTable') = 1
AND (s.auto_created = 1 OR s.user_created = 1)
ORDER BY DaysOld Desc;







--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--New DMV For Statistics Info
SELECT 
  st.object_id                          AS [Table ID]
, OBJECT_NAME(st.object_id)             AS [Table Name]
, st.name                               AS [Index Name]
, STATS_DATE(st.object_id, st.stats_id) AS [LastUpdated]
, modification_counter                  AS [Rows Modified]
FROM
sys.stats st 
CROSS APPLY
sys.dm_db_stats_properties(st.object_id, st.stats_id) AS sp 
WHERE
STATS_DATE(st.object_id, st.stats_id)<=DATEADD(DAY,-1,GETDATE())  
AND modification_counter > 0 
AND OBJECTPROPERTY(st.object_id,'IsUserTable')=1
GO



--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--DBA--*****Last Stats Updated Tme Or Index Rebuild Time
Select OBJECT_NAME(OBJECT_ID) as Table_Name,
name as 'Stats_Name/Index_Name',
STATS_DATE(object_id, stats_id) as Last_Update
From sys.stats
WHERE name NOT LIKE '_WA%'
And OBJECTPROPERTY(OBJECT_ID, 'IsUserTable') = 1
--Where OBJECTPROPERTY(OBJECT_ID, 'IsUserTable') = 1
Order By Last_Update Desc




--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--This script is compatible with SQL Server 2005 and above.
SELECT
  id                    AS [Table ID]
, OBJECT_NAME(id)       AS [Table Name]
, name                  AS [Index Name]
, STATS_DATE(id, indid) AS [LastUpdated]
, rowmodctr             AS [Rows Modified]
FROM sys.sysindexes 
WHERE STATS_DATE(id, indid)<=DATEADD(DAY,-1,GETDATE()) 
AND rowmodctr>0 AND (OBJECTPROPERTY(id,'IsUserTable'))=1
GO





--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
SELECT 
object_name(si.[object_id]) 
AS [TableName]
, CASE 
WHEN si.[index_id] = 0 then 'Heap'
WHEN si.[index_id] = 1 then 'CL'
WHEN si.[index_id] BETWEEN 2 AND 250 THEN 'NC ' + RIGHT('00' + convert(varchar, si.[index_id]), 3)
ELSE ''
 END AS [IndexType]
, si.[name] AS [IndexName]
, si.[index_id]
AS [IndexID]
, CASE
WHEN si.[index_id] BETWEEN 1 AND 250 AND STATS_DATE (si.[object_id], si.[index_id]) < DATEADD(m, -1, getdate()) 
THEN '!! More than a month OLD !!'
WHEN si.[index_id] BETWEEN 1 AND 250 AND STATS_DATE (si.[object_id], si.[index_id]) < DATEADD(wk, -1, getdate()) 
THEN '! Within the past month !'
WHEN si.[index_id] BETWEEN 1 AND 250 THEN 'Stats recent'
ELSE ''
 END AS [Warning]
, STATS_DATE (si.[object_id], si.[index_id]) AS [Last Stats Update]
FROM sys.indexes AS si
WHERE OBJECTPROPERTY(si.[object_id], 'IsUserTable') = 1
ORDER BY [TableName], si.[index_id]
go





--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
Select OBJECT_NAME(OBJECT_ID) as Table_Name,
name as Stats_Name,
STATS_DATE(object_id, stats_id) as Last_Update
From sys.stats
Where OBJECTPROPERTY(OBJECT_ID, 'IsUserTable') = 1 
Order By Last_Update desc




--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
SELECT name AS index_name,
STATS_DATE(OBJECT_ID, index_id) AS StatsUpdated
FROM sys.indexes
WHERE OBJECT_ID = OBJECT_ID('[xradm].[hrm_new_user_request_details]')
GO



--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--DBA--*****Last Stats Updated Tme For The Particular Name
Select name as Index_Name, 
STATS_DATE(object_id, index_id) as Stats_Updated
From sys.indexes
Where name ='NonClusteredIndex-20190517-171922'





select * from sys.indexes

Select * from Sys.SysIndexes

select * from sys.stats

Update Statistics [dbo].[aa] [ClusteredIndex-20190517-170625]

Select RowModCtr from Sys.SysIndexes Where name ='ClusteredIndex-20190517-170625'

SP_UpdateStats

Update Statistics [dbo].[aa] [ClusteredIndex-20190517-170625]
With NoRecompute

Exec SP_HelpIndex 'dbo.aa'

Exec SP_Helpstat 'dbo.aa' 'All'

DBCC Show_Statistics('aa', 'ClusteredIndex-20190517-170625')
 

