--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--https://www.mssqltips.com/sqlservertip/2979/querying-sql-server-index-statistics/
IF OBJECT_ID('IndexDetails_ByChil') IS NOT NULL 
DROP TABLE dbo.IndexDetails_ByChil;

SELECT
     GETDATE() AS [CurrentDate],
     DB_NAME() AS [DatabaseName],
     SCHEMA_NAME([sObj].[schema_id]) AS [SchemaName],
     [sObj].[name] AS [ObjectName],
     CASE
         WHEN [sObj].[type] = 'U' THEN 'Table'
         WHEN [sObj].[type] = 'V' THEN 'View'
     END AS [ObjectType],
	 ISNULL([sIdx].[name], 'N/A') AS [IndexName],
     CASE
         WHEN [sIdx].[type] = 0 THEN 'Heap'
         WHEN [sIdx].[type] = 1 THEN 'Clustered'
         WHEN [sIdx].[type] = 2 THEN 'Nonclustered'
         WHEN [sIdx].[type] = 3 THEN 'XML'
         WHEN [sIdx].[type] = 4 THEN 'Spatial'
         WHEN [sIdx].[type] = 5 THEN 'Reserved for future use'
         WHEN [sIdx].[type] = 6 THEN 'Nonclustered columnstore index'
     END AS [IndexType],
     [sPtn].rows AS RowCounts,
	 [IdxSizeDetails].[TotalPages],
     [IdxSizeDetails].[Unused_MB]/1024 AS [Unused_GB],
	 [IdxSizeDetails].[IndexSizeInMB]/1024 AS [IndexSizeInGB],
    -- [IdxSizeDetails].[Total_MB]/1024 AS [Total_GB],
     --ISNULL([sPtn].[partition_number], 1) AS [PartitionNumber],
     --[sIdx].[index_id] AS [IndexID],
     --[sdmfIPS].[page_count],
     [sIdx].[fill_factor] AS [FillFactor],
     [IdxSizeDetails].[UnusedPages],
     CAST([sdmfIPS].[avg_fragmentation_in_percent] AS NUMERIC(5,2)) AS [AvgPctFrag],
     [IdxSizeDetails].[rowmodctr],
     STATS_DATE(sidx.object_id, sidx.index_id) AS [StatsUpdate]
     --[sdmvIUS].[user_seeks] AS [TotalUserSeeks],
     --[sdmvIUS].[user_scans] AS [TotalUserScans],
     --[sdmvIUS].[user_lookups] AS [TotalUserLookups],
     --[sdmvIUS].[user_updates] AS [TotalUserUpdates],
     --[sdmvIUS].[last_user_seek] AS [LastUserSeek],
     --[sdmvIUS].[last_user_scan] AS [LastUserScan],
     --[sdmvIUS].[last_user_lookup] AS [LastUserLookup],
     --[sdmvIUS].[last_user_update] AS [LastUserUpdate],
     --[sdmfIOPS].[leaf_insert_count] AS [LeafLevelInsertCount],
     --[sdmfIOPS].[leaf_update_count] AS [LeafLevelUpdateCount],
     --[sdmfIOPS].[leaf_delete_count] AS [LeafLevelDeleteCount],
     --STATS_DATE(sIdx.object_id, sIdx.index_id) AS [IndexCreatedDate]
INTO [master].[dbo].[IndexDetails_ByChil]
FROM 
   [sys].[indexes] AS [sIdx]
   INNER JOIN [sys].[objects] AS [sObj]
      ON [sIdx].[object_id] = [sObj].[object_id]
   LEFT JOIN  [sys].[partitions] AS [sPtn]
      ON [sIdx].[object_id] = [sPtn].[object_id]
      AND [sIdx].[index_id] = [sPtn].[index_id]
   LEFT JOIN [sys].[dm_db_index_usage_stats] AS [sdmvIUS]
      ON [sIdx].[object_id] = [sdmvIUS].[object_id]
      AND [sIdx].[index_id] = [sdmvIUS].[index_id]
      AND [sdmvIUS].[database_id] = DB_ID()
   LEFT JOIN [sys].[dm_db_index_operational_stats] (DB_ID(),NULL,NULL,NULL) AS [sdmfIOPS]
      ON [sIdx].[object_id] = [sdmfIOPS].[object_id]
      AND [sIdx].[index_id] = [sdmfIOPS].[index_id]
   LEFT JOIN (
            SELECT
                 [sIdx].[object_id],
                 [sIdx].[index_id],
                 SUM([sAU].[used_pages]) / 1024.0 AS [IndexSizeInMB],
                 CAST(ROUND((SUM([sAU].[used_pages]) / 128.00), 2) AS NUMERIC(36, 2)) AS [Used_MB],
                 CAST(ROUND((SUM(sAU.total_pages) - SUM(sAU.used_pages)) / 128.00, 2) AS NUMERIC(36, 2)) AS [Unused_MB],
                 CAST(ROUND((SUM(sAU.total_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS [Total_MB],
                 SUM(sAU.total_pages) AS [TotalPages], 
                 SUM(sAU.used_pages) AS [UsedPages], 
                 (SUM(sAU.total_pages) - SUM(sAU.used_pages)) AS [UnusedPages],
                 [sSIdx].[rowmodctr],
                 [sSIdx].[name],
                 [sSIdx].[id], 
                 [sSIdx].[indid]
            FROM 
               [sys].[indexes] AS [sIdx]
               INNER JOIN [sys].[partitions] AS [sPtn]
                  ON [sIdx].[object_id] = [sPtn].[object_id]
                  AND [sIdx].[index_id] = [sPtn].[index_id]
               INNER JOIN [sys].[allocation_units] AS [sAU]
                  ON [sPtn].[partition_id] = [sAU].[container_id]				
               INNER JOIN [sys].[sysindexes] AS [sSIdx]
                  ON [sIdx].[object_id] = [sSIdx].[id] 
                  AND [sIdx].[name] = [sSIdx].[name] 
            GROUP BY [sIdx].[object_id], [sIdx].[index_id], [sSIdx].[rowmodctr], 
                     [sSIdx].[name], [sSIdx].[id], [sSIdx].[indid]
   ) [IdxSizeDetails]
      ON [sIdx].[object_id] = [IdxSizeDetails].[object_id]
      AND [sIdx].[index_id] = [IdxSizeDetails].[index_id]
   LEFT JOIN [sys].[dm_db_index_physical_stats] (DB_ID(),NULL,NULL,NULL,'LIMITED') [sdmfIPS]
      ON [sIdx].[object_id] = [sdmfIPS].[object_id]
      AND [sIdx].[index_id] = [sdmfIPS].[index_id]
      AND [sdmfIPS].[database_id] = DB_ID()	       
WHERE
     [sObj].[type] IN ('U','V')         -- Look in Tables & Views
     AND [sObj].[is_ms_shipped] = 0x0   -- Exclude System Generated Objects
     AND [sIdx].[is_disabled] = 0x0     -- Exclude Disabled Indexes
ORDER BY  [AvgPctFrag] DESC;

SELECT * FROM IndexDetails_ByChil;




	 
--DBA--#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----#####-----
--https://dba.stackexchange.com/questions/164880/find-index-size-in-sql-server
;WITH agg AS
(   -- Get info for Tables, Indexed Views, etc
    SELECT  ps.[object_id] AS [ObjectID],
            ps.index_id AS [IndexID],
            NULL AS [ParentIndexID],
            NULL AS [PassThroughIndexName],
            NULL AS [PassThroughIndexType],
            SUM(ps.in_row_data_page_count) AS [InRowDataPageCount],
            SUM(ps.used_page_count) AS [UsedPageCount],
            SUM(ps.reserved_page_count) AS [ReservedPageCount],
            SUM(ps.row_count) AS [RowCount],
            SUM(ps.lob_used_page_count + ps.row_overflow_used_page_count)
                    AS [LobAndRowOverflowUsedPageCount]
    FROM    sys.dm_db_partition_stats ps
    GROUP BY    ps.[object_id],
                ps.[index_id]
    UNION ALL
    -- Get info for FullText indexes, XML indexes, Spatial indexes, etc
    SELECT  sit.[parent_id] AS [ObjectID],
            sit.[object_id] AS [IndexID],
            sit.[parent_minor_id] AS [ParentIndexID],
            sit.[name] AS [PassThroughIndexName],
            sit.[internal_type_desc] AS [PassThroughIndexType],
            0 AS [InRowDataPageCount],
            SUM(ps.used_page_count) AS [UsedPageCount],
            SUM(ps.reserved_page_count) AS [ReservedPageCount],
            0 AS [RowCount],
            0 AS [LobAndRowOverflowUsedPageCount]
    FROM    sys.dm_db_partition_stats ps
    INNER JOIN  sys.internal_tables sit
            ON  sit.[object_id] = ps.[object_id]
    WHERE   sit.internal_type IN
               (202, 204, 207, 211, 212, 213, 214, 215, 216, 221, 222, 236)
    GROUP BY    sit.[parent_id],
                sit.[object_id],
                sit.[parent_minor_id],
                sit.[name],
                sit.[internal_type_desc]
), spaceused AS
(
SELECT  agg.[ObjectID],
        agg.[IndexID],
        agg.[ParentIndexID],
        agg.[PassThroughIndexName],
        agg.[PassThroughIndexType],
        OBJECT_SCHEMA_NAME(agg.[ObjectID]) AS [SchemaName],
        OBJECT_NAME(agg.[ObjectID]) AS [TableName],
        SUM(CASE
                WHEN (agg.IndexID < 2) THEN agg.[RowCount]
                ELSE 0
            END) AS [Rows],
        SUM(agg.ReservedPageCount) * 8 AS [ReservedKB],
        SUM(agg.LobAndRowOverflowUsedPageCount +
            CASE
                WHEN (agg.IndexID < 2) THEN (agg.InRowDataPageCount)
                ELSE 0
            END) * 8 AS [DataKB],
        SUM(agg.UsedPageCount - agg.LobAndRowOverflowUsedPageCount -
            CASE
                WHEN (agg.IndexID < 2) THEN agg.InRowDataPageCount
                ELSE 0
            END) * 8 AS [IndexKB],
        SUM(agg.ReservedPageCount - agg.UsedPageCount) * 8 AS [UnusedKB],
        SUM(agg.UsedPageCount) * 8 AS [UsedKB]
FROM    agg
GROUP BY    agg.[ObjectID],
            agg.[IndexID],
            agg.[ParentIndexID],
            agg.[PassThroughIndexName],
            agg.[PassThroughIndexType],
            OBJECT_SCHEMA_NAME(agg.[ObjectID]),
            OBJECT_NAME(agg.[ObjectID])
)
SELECT sp.SchemaName,
       sp.TableName,
       sp.IndexID,
       IIF(sp.IndexID > 0, COALESCE(si.[name], sp.[PassThroughIndexName]), N'<Heap>')
             AS [IndexName],
       sp.[PassThroughIndexName] AS [InternalTableName],
       sp.[Rows],
       sp.ReservedKB,
       (sp.ReservedKB / 1024.0 / 1024.0) AS [ReservedGB],
       sp.DataKB,
       (sp.DataKB / 1024.0 / 1024.0) AS [DataGB],
       sp.IndexKB,
       (sp.IndexKB / 1024.0 / 1024.0) AS [IndexGB],
       sp.UsedKB AS [UsedKB],
       (sp.UsedKB / 1024.0 / 1024.0) AS [UsedGB],
       sp.UnusedKB,
       (sp.UnusedKB / 1024.0 / 1024.0) AS [UnusedGB],
       so.[type_desc] AS [ObjectType],
       COALESCE(si.type_desc, sp.[PassThroughIndexType]) AS [IndexPrimaryType],
       sp.[PassThroughIndexType] AS [IndexSecondaryType],
       SCHEMA_ID(sp.[SchemaName]) AS [SchemaID],
       sp.ObjectID
       --,sp.ParentIndexID
FROM   spaceused sp
INNER JOIN sys.objects so
        ON so.[object_id] = sp.ObjectID
LEFT JOIN  sys.indexes si
       ON  si.[object_id] = sp.ObjectID
      AND  (si.[index_id] = sp.IndexID
         OR si.[index_id] = sp.[ParentIndexID])
WHERE so.is_ms_shipped = 0
--so.[name] LIKE N''  -- optional name filter
ORDER BY [UsedKB] desc






















--Table & Index Size
SELECT
    a2.name AS TableName,
    a1.rows as [RowCount],
    --(a1.reserved + ISNULL(a4.reserved,0)) * 8 AS ReservedSize_KB,
    --a1.data * 8 AS DataSize_KB,
    --(CASE WHEN (a1.used + ISNULL(a4.used,0)) > a1.data THEN (a1.used + ISNULL(a4.used,0)) - a1.data ELSE 0 END) * 8 AS IndexSize_KB,
    --(CASE WHEN (a1.reserved + ISNULL(a4.reserved,0)) > a1.used THEN (a1.reserved + ISNULL(a4.reserved,0)) - a1.used ELSE 0 END) * 8 AS UnusedSize_KB,
    CAST(ROUND(((a1.reserved + ISNULL(a4.reserved,0)) * 8) / 1024.00, 2) AS NUMERIC(36, 2)) AS ReservedSize_MB,
    CAST(ROUND(a1.data * 8 / 1024.00, 2) AS NUMERIC(36, 2)) AS DataSize_MB,
    CAST(ROUND((CASE WHEN (a1.used + ISNULL(a4.used,0)) > a1.data THEN (a1.used + ISNULL(a4.used,0)) - a1.data ELSE 0 END) * 8 / 1024.00, 2) AS NUMERIC(36, 2)) AS IndexSize_MB,
    CAST(ROUND((CASE WHEN (a1.reserved + ISNULL(a4.reserved,0)) > a1.used THEN (a1.reserved + ISNULL(a4.reserved,0)) - a1.used ELSE 0 END) * 8 / 1024.00, 2) AS NUMERIC(36, 2)) AS UnusedSize_MB,
    --'| |' Separator_MB_GB,
    CAST(ROUND(((a1.reserved + ISNULL(a4.reserved,0)) * 8) / 1024.00 / 1024.00, 2) AS NUMERIC(36, 2)) AS ReservedSize_GB,
    CAST(ROUND(a1.data * 8 / 1024.00 / 1024.00, 2) AS NUMERIC(36, 2)) AS DataSize_GB,
    CAST(ROUND((CASE WHEN (a1.used + ISNULL(a4.used,0)) > a1.data THEN (a1.used + ISNULL(a4.used,0)) - a1.data ELSE 0 END) * 8 / 1024.00 / 1024.00, 2) AS NUMERIC(36, 2)) AS IndexSize_GB,
    CAST(ROUND((CASE WHEN (a1.reserved + ISNULL(a4.reserved,0)) > a1.used THEN (a1.reserved + ISNULL(a4.reserved,0)) - a1.used ELSE 0 END) * 8 / 1024.00 / 1024.00, 2) AS NUMERIC(36, 2)) AS UnusedSize_GB
FROM
    (SELECT 
        ps.object_id,
        SUM (CASE WHEN (ps.index_id < 2) THEN row_count ELSE 0 END) AS [rows],
        SUM (ps.reserved_page_count) AS reserved,
        SUM (CASE
                WHEN (ps.index_id < 2) THEN (ps.in_row_data_page_count + ps.lob_used_page_count + ps.row_overflow_used_page_count)
                ELSE (ps.lob_used_page_count + ps.row_overflow_used_page_count)
            END
            ) AS data,
        SUM (ps.used_page_count) AS used
    FROM sys.dm_db_partition_stats ps
        --===Remove the following comment for SQL Server 2014+
        --WHERE ps.object_id NOT IN (SELECT object_id FROM sys.tables WHERE is_memory_optimized = 1)
    GROUP BY ps.object_id) AS a1
LEFT OUTER JOIN 
    (SELECT 
        it.parent_id,
        SUM(ps.reserved_page_count) AS reserved,
        SUM(ps.used_page_count) AS used
     FROM sys.dm_db_partition_stats ps
     INNER JOIN sys.internal_tables it ON (it.object_id = ps.object_id)
     WHERE it.internal_type IN (202,204)
     GROUP BY it.parent_id) AS a4 ON (a4.parent_id = a1.object_id)
INNER JOIN sys.all_objects a2  ON ( a1.object_id = a2.object_id ) 
INNER JOIN sys.schemas a3 ON (a2.schema_id = a3.schema_id)
WHERE a2.type <> N'S' and a2.type <> N'IT'
--AND a2.name = 'MyTable'       --Filter for specific table
--ORDER BY a3.name, a2.name
ORDER BY ReservedSize_MB DESC
--table size--
-- Total # of pages, used_pages, and data_pages for a given heap/clustered index
SELECT 
	schema_name(o.schema_id) AS SchemaName,
    t.NAME AS TableName,
    p.rows AS RowCounts,
	CAST(ROUND((SUM(a.used_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS Used_MB,
	CAST(ROUND((SUM(a.total_pages) - SUM(a.used_pages)) / 128.00, 2) AS NUMERIC(36, 2)) AS Unused_MB,
	CAST(ROUND((SUM(a.total_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS Total_MB,
    SUM(a.total_pages) AS TotalPages, 
    SUM(a.used_pages) AS UsedPages, 
    (SUM(a.total_pages) - SUM(a.used_pages)) AS UnusedPages,
	i.name AS IndexName
FROM  sys.tables t
INNER JOIN sys.indexes i ON t.OBJECT_ID = i.object_id
INNER JOIN sys.objects o ON i.OBJECT_ID = o.object_id
INNER JOIN sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
WHERE 
    t.NAME NOT LIKE 'dt%' 
    AND t.is_ms_shipped = 0
    AND i.OBJECT_ID > 255 
GROUP BY schema_name(o.schema_id), t.Name, p.Rows, i.name
ORDER BY Total_MB desc








--DBA--#####--Fragmentation Percentage--
SELECT  dbschemas.[name] as 'Schema',
OBJECT_NAME(IDX.OBJECT_ID) AS Table_Name, 
IDX.name AS Index_Name, 
IDXPS.index_type_desc AS Index_Type, 
IDXPS.avg_fragmentation_in_percent  Fragmentation_Percentage,
IDXPS.page_count,
(IDXPS.page_count) / 1024.0 IndexSizeMB,
STATS_DATE (IDX.object_id , IDX.index_id ) as IndexCreatedDate
--STATS_DATE(stats.object_id, stats_id) as Last_Update
--stats.name AS [StatisticName]
--stats_date (sysind.id,sysind.indid) as stats_last_updated_time,
--sysind.rowmodctr as rowmodctr
FROM sys.dm_db_index_physical_stats(DB_ID(), NULL, NULL, NULL, NULL) As IDXPS 
INNER JOIN sys.indexes IDX  ON IDX.object_id = IDXPS.object_id
--INNER JOIN sys.sysindexes sysind  ON sysind.id = IDXPS.object_id
--INNER JOIN sys.stats stats  ON stats.object_id = IDXPS.object_id  
INNER JOIN sys.tables dbtables on dbtables.[object_id] = IDXPS.[object_id]
INNER JOIN sys.schemas dbschemas on dbtables.[schema_id] = dbschemas.[schema_id]
AND IDX.index_id = IDXPS.index_id 
--WHERE stats.name NOT LIKE '_WA%'
ORDER BY Fragmentation_Percentage desc





Use BRNET
 -----
 IF OBJECT_ID('master.dbo.IndexDetails_ByChil') IS NOT NULL 
DROP TABLE master.dbo.IndexDetails_ByChil;

SELECT
     GETDATE() AS [CurrentDate],
     DB_NAME() AS [DatabaseName],
     SCHEMA_NAME([sObj].[schema_id]) AS [SchemaName],
     [sObj].[name] AS [ObjectName],
     CASE
         WHEN [sObj].[type] = 'U' THEN 'Table'
         WHEN [sObj].[type] = 'V' THEN 'View'
     END AS [ObjectType],
	 ISNULL([sIdx].[name], 'N/A') AS [IndexName],
     CASE
         WHEN [sIdx].[type] = 0 THEN 'Heap'
         WHEN [sIdx].[type] = 1 THEN 'Clustered'
         WHEN [sIdx].[type] = 2 THEN 'Nonclustered'
         WHEN [sIdx].[type] = 3 THEN 'XML'
         WHEN [sIdx].[type] = 4 THEN 'Spatial'
         WHEN [sIdx].[type] = 5 THEN 'Reserved for future use'
         WHEN [sIdx].[type] = 6 THEN 'Nonclustered columnstore index'
     END AS [IndexType],
     [sPtn].rows AS RowCounts,
	 [IdxSizeDetails].[TotalPages],
     [IdxSizeDetails].[Unused_MB]/1024 AS [Unused_GB],
	 [IdxSizeDetails].[IndexSizeInMB]/1024 AS [IndexSizeInGB],
    -- [IdxSizeDetails].[Total_MB]/1024 AS [Total_GB],
     --ISNULL([sPtn].[partition_number], 1) AS [PartitionNumber],
     --[sIdx].[index_id] AS [IndexID],
     --[sdmfIPS].[page_count],
     [sIdx].[fill_factor] AS [FillFactor],
     [IdxSizeDetails].[UnusedPages],
     CAST([sdmfIPS].[avg_fragmentation_in_percent] AS NUMERIC(5,2)) AS [AvgPctFrag],
     [IdxSizeDetails].[rowmodctr],
     STATS_DATE(sidx.object_id, sidx.index_id) AS [StatsUpdate]
     --[sdmvIUS].[user_seeks] AS [TotalUserSeeks],
     --[sdmvIUS].[user_scans] AS [TotalUserScans],
     --[sdmvIUS].[user_lookups] AS [TotalUserLookups],
     --[sdmvIUS].[user_updates] AS [TotalUserUpdates],
     --[sdmvIUS].[last_user_seek] AS [LastUserSeek],
     --[sdmvIUS].[last_user_scan] AS [LastUserScan],
     --[sdmvIUS].[last_user_lookup] AS [LastUserLookup],
     --[sdmvIUS].[last_user_update] AS [LastUserUpdate],
     --[sdmfIOPS].[leaf_insert_count] AS [LeafLevelInsertCount],
     --[sdmfIOPS].[leaf_update_count] AS [LeafLevelUpdateCount],
     --[sdmfIOPS].[leaf_delete_count] AS [LeafLevelDeleteCount],
     --STATS_DATE(sIdx.object_id, sIdx.index_id) AS [IndexCreatedDate]
INTO [master].[dbo].[IndexDetails_ByChil]
FROM 
   [sys].[indexes] AS [sIdx]
   INNER JOIN [sys].[objects] AS [sObj]
      ON [sIdx].[object_id] = [sObj].[object_id]
   LEFT JOIN  [sys].[partitions] AS [sPtn]
      ON [sIdx].[object_id] = [sPtn].[object_id]
      AND [sIdx].[index_id] = [sPtn].[index_id]
   LEFT JOIN [sys].[dm_db_index_usage_stats] AS [sdmvIUS]
      ON [sIdx].[object_id] = [sdmvIUS].[object_id]
      AND [sIdx].[index_id] = [sdmvIUS].[index_id]
      AND [sdmvIUS].[database_id] = DB_ID()
   LEFT JOIN [sys].[dm_db_index_operational_stats] (DB_ID(),NULL,NULL,NULL) AS [sdmfIOPS]
      ON [sIdx].[object_id] = [sdmfIOPS].[object_id]
      AND [sIdx].[index_id] = [sdmfIOPS].[index_id]
   LEFT JOIN (
            SELECT
                 [sIdx].[object_id],
                 [sIdx].[index_id],
                 SUM([sAU].[used_pages]) / 1024.0 AS [IndexSizeInMB],
                 CAST(ROUND((SUM([sAU].[used_pages]) / 128.00), 2) AS NUMERIC(36, 2)) AS [Used_MB],
                 CAST(ROUND((SUM(sAU.total_pages) - SUM(sAU.used_pages)) / 128.00, 2) AS NUMERIC(36, 2)) AS [Unused_MB],
                 CAST(ROUND((SUM(sAU.total_pages) / 128.00), 2) AS NUMERIC(36, 2)) AS [Total_MB],
                 SUM(sAU.total_pages) AS [TotalPages], 
                 SUM(sAU.used_pages) AS [UsedPages], 
                 (SUM(sAU.total_pages) - SUM(sAU.used_pages)) AS [UnusedPages],
                 [sSIdx].[rowmodctr],
                 [sSIdx].[name],
                 [sSIdx].[id], 
                 [sSIdx].[indid]
            FROM 
               [sys].[indexes] AS [sIdx]
               INNER JOIN [sys].[partitions] AS [sPtn]
                  ON [sIdx].[object_id] = [sPtn].[object_id]
                  AND [sIdx].[index_id] = [sPtn].[index_id]
               INNER JOIN [sys].[allocation_units] AS [sAU]
                  ON [sPtn].[partition_id] = [sAU].[container_id]				
               INNER JOIN [sys].[sysindexes] AS [sSIdx]
                  ON [sIdx].[object_id] = [sSIdx].[id] 
                  AND [sIdx].[name] = [sSIdx].[name] 
            GROUP BY [sIdx].[object_id], [sIdx].[index_id], [sSIdx].[rowmodctr], 
                     [sSIdx].[name], [sSIdx].[id], [sSIdx].[indid]
   ) [IdxSizeDetails]
      ON [sIdx].[object_id] = [IdxSizeDetails].[object_id]
      AND [sIdx].[index_id] = [IdxSizeDetails].[index_id]
   LEFT JOIN [sys].[dm_db_index_physical_stats] (DB_ID(),NULL,NULL,NULL,'LIMITED') [sdmfIPS]
      ON [sIdx].[object_id] = [sdmfIPS].[object_id]
      AND [sIdx].[index_id] = [sdmfIPS].[index_id]
      AND [sdmfIPS].[database_id] = DB_ID()	       
WHERE
     [sObj].[type] IN ('U','V')         -- Look in Tables & Views
     AND [sObj].[is_ms_shipped] = 0x0   -- Exclude System Generated Objects
     AND [sIdx].[is_disabled] = 0x0     -- Exclude Disabled Indexes
ORDER BY  [AvgPctFrag] DESC;

SELECT * FROM IndexDetails_ByChil;